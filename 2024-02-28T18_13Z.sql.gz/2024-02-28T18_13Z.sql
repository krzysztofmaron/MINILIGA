--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6 (Debian 15.6-1.pgdg110+2)
-- Dumped by pg_dump version 15.6 (Debian 15.6-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY "public"."main_team" DROP CONSTRAINT IF EXISTS "main_team_league_id_5b04d9d8_fk_main_league_id";
ALTER TABLE IF EXISTS ONLY "public"."main_player" DROP CONSTRAINT IF EXISTS "main_player_team_id_7c700b6f_fk_main_team_id";
ALTER TABLE IF EXISTS ONLY "public"."main_participation" DROP CONSTRAINT IF EXISTS "main_participation_player_id_eec4aa8b_fk_main_player_id";
ALTER TABLE IF EXISTS ONLY "public"."main_participation" DROP CONSTRAINT IF EXISTS "main_participation_match_id_8c82cef9_fk_main_match_id";
ALTER TABLE IF EXISTS ONLY "public"."main_match" DROP CONSTRAINT IF EXISTS "main_match_team2_id_dac54b6b_fk_main_team_id";
ALTER TABLE IF EXISTS ONLY "public"."main_match" DROP CONSTRAINT IF EXISTS "main_match_team1_id_7c806ec6_fk_main_team_id";
ALTER TABLE IF EXISTS ONLY "public"."django_admin_log" DROP CONSTRAINT IF EXISTS "django_admin_log_user_id_c564eba6_fk_auth_user_id";
ALTER TABLE IF EXISTS ONLY "public"."django_admin_log" DROP CONSTRAINT IF EXISTS "django_admin_log_content_type_id_c4bce8eb_fk_django_co";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_user_permissions" DROP CONSTRAINT IF EXISTS "auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_user_permissions" DROP CONSTRAINT IF EXISTS "auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_groups" DROP CONSTRAINT IF EXISTS "auth_user_groups_user_id_6a12ed8b_fk_auth_user_id";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_groups" DROP CONSTRAINT IF EXISTS "auth_user_groups_group_id_97559544_fk_auth_group_id";
ALTER TABLE IF EXISTS ONLY "public"."auth_permission" DROP CONSTRAINT IF EXISTS "auth_permission_content_type_id_2f476e4b_fk_django_co";
ALTER TABLE IF EXISTS ONLY "public"."auth_group_permissions" DROP CONSTRAINT IF EXISTS "auth_group_permissions_group_id_b120cbf9_fk_auth_group_id";
ALTER TABLE IF EXISTS ONLY "public"."auth_group_permissions" DROP CONSTRAINT IF EXISTS "auth_group_permissio_permission_id_84c5c92e_fk_auth_perm";
DROP INDEX IF EXISTS "public"."main_team_league_id_5b04d9d8";
DROP INDEX IF EXISTS "public"."main_player_team_id_7c700b6f";
DROP INDEX IF EXISTS "public"."main_participation_player_id_eec4aa8b";
DROP INDEX IF EXISTS "public"."main_participation_match_id_8c82cef9";
DROP INDEX IF EXISTS "public"."main_match_team2_id_dac54b6b";
DROP INDEX IF EXISTS "public"."main_match_team1_id_7c806ec6";
DROP INDEX IF EXISTS "public"."django_session_session_key_c0390e0f_like";
DROP INDEX IF EXISTS "public"."django_session_expire_date_a5c62663";
DROP INDEX IF EXISTS "public"."django_admin_log_user_id_c564eba6";
DROP INDEX IF EXISTS "public"."django_admin_log_content_type_id_c4bce8eb";
DROP INDEX IF EXISTS "public"."auth_user_username_6821ab7c_like";
DROP INDEX IF EXISTS "public"."auth_user_user_permissions_user_id_a95ead1b";
DROP INDEX IF EXISTS "public"."auth_user_user_permissions_permission_id_1fbb5f2c";
DROP INDEX IF EXISTS "public"."auth_user_groups_user_id_6a12ed8b";
DROP INDEX IF EXISTS "public"."auth_user_groups_group_id_97559544";
DROP INDEX IF EXISTS "public"."auth_permission_content_type_id_2f476e4b";
DROP INDEX IF EXISTS "public"."auth_group_permissions_permission_id_84c5c92e";
DROP INDEX IF EXISTS "public"."auth_group_permissions_group_id_b120cbf9";
DROP INDEX IF EXISTS "public"."auth_group_name_a6ea08ec_like";
ALTER TABLE IF EXISTS ONLY "public"."main_team" DROP CONSTRAINT IF EXISTS "main_team_pkey";
ALTER TABLE IF EXISTS ONLY "public"."main_player" DROP CONSTRAINT IF EXISTS "main_player_pkey";
ALTER TABLE IF EXISTS ONLY "public"."main_participation" DROP CONSTRAINT IF EXISTS "main_participation_pkey";
ALTER TABLE IF EXISTS ONLY "public"."main_match" DROP CONSTRAINT IF EXISTS "main_match_pkey";
ALTER TABLE IF EXISTS ONLY "public"."main_league" DROP CONSTRAINT IF EXISTS "main_league_pkey";
ALTER TABLE IF EXISTS ONLY "public"."django_session" DROP CONSTRAINT IF EXISTS "django_session_pkey";
ALTER TABLE IF EXISTS ONLY "public"."django_migrations" DROP CONSTRAINT IF EXISTS "django_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."django_content_type" DROP CONSTRAINT IF EXISTS "django_content_type_pkey";
ALTER TABLE IF EXISTS ONLY "public"."django_content_type" DROP CONSTRAINT IF EXISTS "django_content_type_app_label_model_76bd3d3b_uniq";
ALTER TABLE IF EXISTS ONLY "public"."django_admin_log" DROP CONSTRAINT IF EXISTS "django_admin_log_pkey";
ALTER TABLE IF EXISTS ONLY "public"."auth_user" DROP CONSTRAINT IF EXISTS "auth_user_username_key";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_user_permissions" DROP CONSTRAINT IF EXISTS "auth_user_user_permissions_user_id_permission_id_14a6b632_uniq";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_user_permissions" DROP CONSTRAINT IF EXISTS "auth_user_user_permissions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."auth_user" DROP CONSTRAINT IF EXISTS "auth_user_pkey";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_groups" DROP CONSTRAINT IF EXISTS "auth_user_groups_user_id_group_id_94350c0c_uniq";
ALTER TABLE IF EXISTS ONLY "public"."auth_user_groups" DROP CONSTRAINT IF EXISTS "auth_user_groups_pkey";
ALTER TABLE IF EXISTS ONLY "public"."auth_permission" DROP CONSTRAINT IF EXISTS "auth_permission_pkey";
ALTER TABLE IF EXISTS ONLY "public"."auth_permission" DROP CONSTRAINT IF EXISTS "auth_permission_content_type_id_codename_01ab375a_uniq";
ALTER TABLE IF EXISTS ONLY "public"."auth_group" DROP CONSTRAINT IF EXISTS "auth_group_pkey";
ALTER TABLE IF EXISTS ONLY "public"."auth_group_permissions" DROP CONSTRAINT IF EXISTS "auth_group_permissions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."auth_group_permissions" DROP CONSTRAINT IF EXISTS "auth_group_permissions_group_id_permission_id_0cd325b0_uniq";
ALTER TABLE IF EXISTS ONLY "public"."auth_group" DROP CONSTRAINT IF EXISTS "auth_group_name_key";
DROP TABLE IF EXISTS "public"."main_team";
DROP TABLE IF EXISTS "public"."main_player";
DROP TABLE IF EXISTS "public"."main_participation";
DROP TABLE IF EXISTS "public"."main_match";
DROP TABLE IF EXISTS "public"."main_league";
DROP TABLE IF EXISTS "public"."django_session";
DROP TABLE IF EXISTS "public"."django_migrations";
DROP TABLE IF EXISTS "public"."django_content_type";
DROP TABLE IF EXISTS "public"."django_admin_log";
DROP TABLE IF EXISTS "public"."auth_user_user_permissions";
DROP TABLE IF EXISTS "public"."auth_user_groups";
DROP TABLE IF EXISTS "public"."auth_user";
DROP TABLE IF EXISTS "public"."auth_permission";
DROP TABLE IF EXISTS "public"."auth_group_permissions";
DROP TABLE IF EXISTS "public"."auth_group";
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."auth_group" (
    "id" integer NOT NULL,
    "name" character varying(150) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."auth_group" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."auth_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."auth_group_permissions" (
    "id" bigint NOT NULL,
    "group_id" integer NOT NULL,
    "permission_id" integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."auth_group_permissions" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."auth_group_permissions_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."auth_permission" (
    "id" integer NOT NULL,
    "name" character varying(255) NOT NULL,
    "content_type_id" integer NOT NULL,
    "codename" character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."auth_permission" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."auth_permission_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."auth_user" (
    "id" integer NOT NULL,
    "password" character varying(128) NOT NULL,
    "last_login" timestamp with time zone,
    "is_superuser" boolean NOT NULL,
    "username" character varying(150) NOT NULL,
    "first_name" character varying(150) NOT NULL,
    "last_name" character varying(150) NOT NULL,
    "email" character varying(254) NOT NULL,
    "is_staff" boolean NOT NULL,
    "is_active" boolean NOT NULL,
    "date_joined" timestamp with time zone NOT NULL
);


--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."auth_user_groups" (
    "id" bigint NOT NULL,
    "user_id" integer NOT NULL,
    "group_id" integer NOT NULL
);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."auth_user_groups" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."auth_user_groups_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."auth_user" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."auth_user_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."auth_user_user_permissions" (
    "id" bigint NOT NULL,
    "user_id" integer NOT NULL,
    "permission_id" integer NOT NULL
);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."auth_user_user_permissions" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."auth_user_user_permissions_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."django_admin_log" (
    "id" integer NOT NULL,
    "action_time" timestamp with time zone NOT NULL,
    "object_id" "text",
    "object_repr" character varying(200) NOT NULL,
    "action_flag" smallint NOT NULL,
    "change_message" "text" NOT NULL,
    "content_type_id" integer,
    "user_id" integer NOT NULL,
    CONSTRAINT "django_admin_log_action_flag_check" CHECK (("action_flag" >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."django_admin_log" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."django_admin_log_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."django_content_type" (
    "id" integer NOT NULL,
    "app_label" character varying(100) NOT NULL,
    "model" character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."django_content_type" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."django_content_type_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."django_migrations" (
    "id" bigint NOT NULL,
    "app" character varying(255) NOT NULL,
    "name" character varying(255) NOT NULL,
    "applied" timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."django_migrations" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."django_migrations_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."django_session" (
    "session_key" character varying(40) NOT NULL,
    "session_data" "text" NOT NULL,
    "expire_date" timestamp with time zone NOT NULL
);


--
-- Name: main_league; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."main_league" (
    "id" bigint NOT NULL,
    "leagueID" integer NOT NULL
);


--
-- Name: main_league_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."main_league" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."main_league_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: main_match; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."main_match" (
    "id" bigint NOT NULL,
    "team1score" integer NOT NULL,
    "team2score" integer NOT NULL,
    "matchdate" "date" NOT NULL,
    "team1_id" bigint NOT NULL,
    "team2_id" bigint NOT NULL,
    "accepted" boolean NOT NULL
);


--
-- Name: main_match_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."main_match" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."main_match_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: main_participation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."main_participation" (
    "id" bigint NOT NULL,
    "mvpPoints" integer NOT NULL,
    "goalsScored" integer NOT NULL,
    "keeperPoints" integer NOT NULL,
    "matches" integer NOT NULL,
    "match_id" bigint NOT NULL,
    "player_id" bigint NOT NULL
);


--
-- Name: main_participation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."main_participation" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."main_participation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: main_player; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."main_player" (
    "id" bigint NOT NULL,
    "name" character varying(200) NOT NULL,
    "surname" character varying(200) NOT NULL,
    "role" character varying(200) NOT NULL,
    "goalsScored" integer NOT NULL,
    "mvpPoints" integer NOT NULL,
    "matches" integer NOT NULL,
    "keeperPoints" double precision NOT NULL,
    "team_id" bigint NOT NULL
);


--
-- Name: main_player_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."main_player" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."main_player_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: main_team; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."main_team" (
    "id" bigint NOT NULL,
    "name" character varying(200) NOT NULL,
    "points" integer NOT NULL,
    "goalsScored" integer NOT NULL,
    "goalsLost" integer NOT NULL,
    "matches" integer NOT NULL,
    "league_id" bigint NOT NULL
);


--
-- Name: main_team_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."main_team" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."main_team_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."auth_group" ("id", "name") FROM stdin;
1	captain
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."auth_group_permissions" ("id", "group_id", "permission_id") FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."auth_permission" ("id", "name", "content_type_id", "codename") FROM stdin;
1	Can add league	1	add_league
2	Can change league	1	change_league
3	Can delete league	1	delete_league
4	Can view league	1	view_league
5	Can add team	2	add_team
6	Can change team	2	change_team
7	Can delete team	2	delete_team
8	Can view team	2	view_team
9	Can add player	3	add_player
10	Can change player	3	change_player
11	Can delete player	3	delete_player
12	Can view player	3	view_player
13	Can add match	4	add_match
14	Can change match	4	change_match
15	Can delete match	4	delete_match
16	Can view match	4	view_match
17	Can add log entry	5	add_logentry
18	Can change log entry	5	change_logentry
19	Can delete log entry	5	delete_logentry
20	Can view log entry	5	view_logentry
21	Can add permission	6	add_permission
22	Can change permission	6	change_permission
23	Can delete permission	6	delete_permission
24	Can view permission	6	view_permission
25	Can add group	7	add_group
26	Can change group	7	change_group
27	Can delete group	7	delete_group
28	Can view group	7	view_group
29	Can add user	8	add_user
30	Can change user	8	change_user
31	Can delete user	8	delete_user
32	Can view user	8	view_user
33	Can add content type	9	add_contenttype
34	Can change content type	9	change_contenttype
35	Can delete content type	9	delete_contenttype
36	Can view content type	9	view_contenttype
37	Can add session	10	add_session
38	Can change session	10	change_session
39	Can delete session	10	delete_session
40	Can view session	10	view_session
41	Can add match queue	11	add_matchqueue
42	Can change match queue	11	change_matchqueue
43	Can delete match queue	11	delete_matchqueue
44	Can view match queue	11	view_matchqueue
45	Can add player queue	12	add_playerqueue
46	Can change player queue	12	change_playerqueue
47	Can delete player queue	12	delete_playerqueue
48	Can view player queue	12	view_playerqueue
49	Can add team queue	13	add_teamqueue
50	Can change team queue	13	change_teamqueue
51	Can delete team queue	13	delete_teamqueue
52	Can view team queue	13	view_teamqueue
53	Can add participation	14	add_participation
54	Can change participation	14	change_participation
55	Can delete participation	14	delete_participation
56	Can view participation	14	view_participation
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."auth_user" ("id", "password", "last_login", "is_superuser", "username", "first_name", "last_name", "email", "is_staff", "is_active", "date_joined") FROM stdin;
1	pbkdf2_sha256$390000$7vuonZpL6y3KTovChs1hEv$Emq0ofpSgF9n03pzlr7bSy3zVk/w9HnEfeHNUWOPPGI=	2023-10-08 21:09:25.688535+00	t	admin				t	t	2023-09-15 19:32:26.191755+00
2	pbkdf2_sha256$390000$0ZoV1DmavTCIC14aSDzYGa$DZ4Qqv9AjeBsi8SJquW/9NYQamFAgKP9QTlhRFGRzR4=	2024-02-13 10:33:44.968314+00	f	kapitan				f	t	2023-09-19 13:41:02+00
4	pbkdf2_sha256$390000$51wc5UgjTAHmj2E3Gurp5i$88+P0fcBZIB4YYKq1Pg0L6muRxpoPFQctVOSkupQG8E=	2024-02-14 14:52:10.920876+00	t	miniligastaff				t	t	2023-09-19 14:07:11+00
7	pbkdf2_sha256$390000$fFdgtGlQkgeRoIht9JzC8G$KvEDo9qVrXZo3gPByB5++oBmzjCBft16KxrN72Qkc00=	2023-09-25 18:09:28.594125+00	t	miniliga			miniliga@gmail.com	t	t	2023-09-25 15:59:57.347292+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."auth_user_groups" ("id", "user_id", "group_id") FROM stdin;
1	2	1
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."auth_user_user_permissions" ("id", "user_id", "permission_id") FROM stdin;
1	4	1
2	4	2
3	4	3
4	4	4
5	4	5
6	4	6
7	4	7
8	4	8
9	4	9
10	4	10
11	4	11
12	4	12
13	4	13
14	4	14
15	4	15
16	4	16
17	4	17
18	4	18
19	4	19
20	4	20
21	4	25
22	4	26
23	4	27
24	4	28
25	4	29
26	4	30
27	4	31
28	4	32
29	4	53
30	4	54
31	4	55
32	4	56
33	4	21
34	4	22
35	4	23
36	4	24
37	4	33
38	4	34
39	4	35
40	4	36
41	4	37
42	4	38
43	4	39
44	4	40
45	4	41
46	4	42
47	4	43
48	4	44
49	4	45
50	4	46
51	4	47
52	4	48
53	4	49
54	4	50
55	4	51
56	4	52
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."django_admin_log" ("id", "action_time", "object_id", "object_repr", "action_flag", "change_message", "content_type_id", "user_id") FROM stdin;
1	2023-09-15 19:47:13.163107+00	1	1	1	[{"added": {}}]	1	1
2	2023-09-15 19:47:15.185235+00	2	2	1	[{"added": {}}]	1	1
3	2023-09-15 19:47:17.796177+00	3	3	1	[{"added": {}}]	1	1
4	2023-09-15 19:47:21.009337+00	4	4	1	[{"added": {}}]	1	1
5	2023-09-15 19:47:41.326266+00	1	TeamSample1	1	[{"added": {}}]	2	1
6	2023-09-15 19:47:46.452368+00	2	TeamSample2	1	[{"added": {}}]	2	1
7	2023-09-16 12:38:52.46962+00	1	Karol Pośmieciuszko	1	[{"added": {}}]	3	1
8	2023-09-16 12:39:09.872429+00	2	Patryk Jemiołuszko	1	[{"added": {}}]	3	1
9	2023-09-16 12:39:25.377388+00	3	Kuba Śmierdziuszko	1	[{"added": {}}]	3	1
10	2023-09-16 12:39:39.39436+00	4	Jeremiasz Padlinuszko	1	[{"added": {}}]	3	1
11	2023-09-16 12:39:59.893856+00	1	TeamSample1 vs TeamSample2	3		11	1
12	2023-09-16 12:59:09.372261+00	3	QUEUE  |  TeamSample1 vs TeamSample2	3		11	1
13	2023-09-16 12:59:13.444824+00	2	QUEUE  |  TeamSample1 vs TeamSample2	3		11	1
14	2023-09-17 08:45:03.515384+00	3	Participation object (3)	3		14	1
15	2023-09-17 08:45:03.583626+00	2	Participation object (2)	3		14	1
16	2023-09-17 08:45:03.61896+00	1	Participation object (1)	3		14	1
17	2023-09-17 08:45:27.935574+00	15	TeamSample2 vs TeamSample1	3		4	1
18	2023-09-17 08:45:27.964503+00	14	TeamSample2 vs TeamSample1	3		4	1
19	2023-09-17 08:45:27.995127+00	13	TeamSample2 vs TeamSample1	3		4	1
20	2023-09-17 08:45:28.025586+00	12	TeamSample1 vs TeamSample2	3		4	1
21	2023-09-17 08:45:28.05496+00	11	TeamSample1 vs TeamSample2	3		4	1
22	2023-09-17 08:45:28.086021+00	10	TeamSample1 vs TeamSample2	3		4	1
23	2023-09-17 08:45:28.115528+00	9	TeamSample1 vs TeamSample2	3		4	1
24	2023-09-17 08:45:28.145488+00	8	TeamSample1 vs TeamSample2	3		4	1
25	2023-09-17 08:45:28.175778+00	7	TeamSample1 vs TeamSample2	3		4	1
26	2023-09-17 08:45:28.205961+00	6	TeamSample2 vs TeamSample1	3		4	1
27	2023-09-17 08:45:28.235222+00	5	TeamSample2 vs TeamSample1	3		4	1
28	2023-09-17 08:45:28.268013+00	4	TeamSample1 vs TeamSample2	3		4	1
29	2023-09-17 08:45:28.315624+00	3	TeamSample2 vs TeamSample1	3		4	1
30	2023-09-17 08:45:28.363294+00	2	TeamSample1 vs TeamSample2	3		4	1
31	2023-09-17 08:45:28.393474+00	1	TeamSample1 vs TeamSample2	3		4	1
32	2023-09-17 08:48:53.688248+00	19	TeamSample2 vs TeamSample1	3		4	1
33	2023-09-17 08:48:53.73831+00	18	TeamSample2 vs TeamSample1	3		4	1
34	2023-09-17 08:48:53.774256+00	17	TeamSample2 vs TeamSample1	3		4	1
35	2023-09-17 08:49:09.727429+00	5	Participation object (5)	3		14	1
36	2023-09-17 08:49:09.758151+00	4	Participation object (4)	3		14	1
37	2023-09-17 08:49:15.065339+00	20	TeamSample2 vs TeamSample1	3		4	1
38	2023-09-17 10:11:32.795732+00	7	Participation object (7)	3		14	1
39	2023-09-17 10:11:37.448506+00	6	Participation object (6)	3		14	1
40	2023-09-17 10:11:45.478448+00	21	TeamSample2 vs TeamSample1	3		4	1
41	2023-09-17 10:12:58.450704+00	16	TeamSample1 vs TeamSample2	3		4	1
42	2023-09-17 13:30:00.6367+00	31	TeamSample2 vs TeamSample1	3		4	1
43	2023-09-17 13:30:00.639078+00	27	TeamSample2 vs TeamSample1	3		4	1
44	2023-09-17 13:30:00.64073+00	26	TeamSample2 vs TeamSample1	3		4	1
45	2023-09-17 13:30:00.64238+00	25	TeamSample2 vs TeamSample1	3		4	1
46	2023-09-17 13:30:00.661579+00	24	TeamSample2 vs TeamSample1	3		4	1
47	2023-09-17 13:30:00.663291+00	23	TeamSample1 vs TeamSample2	3		4	1
48	2023-09-17 13:30:00.6647+00	22	TeamSample2 vs TeamSample1	3		4	1
49	2023-09-17 13:30:08.754415+00	4	Jeremiasz Padlinuszko	3		3	1
50	2023-09-17 13:30:08.756128+00	3	Kuba Śmierdziuszko	3		3	1
51	2023-09-17 13:30:08.75762+00	2	Patryk Jemiołuszko	3		3	1
52	2023-09-17 13:30:08.758926+00	1	Karol Pośmieciuszko	3		3	1
53	2023-09-17 13:30:14.33433+00	2	TeamSample2	3		2	1
54	2023-09-17 13:30:14.336907+00	1	TeamSample1	3		2	1
55	2023-09-17 13:33:24.751977+00	3	12124	1	[{"added": {}}]	2	1
56	2023-09-17 13:33:28.969006+00	4	1251	1	[{"added": {}}]	2	1
57	2023-09-17 13:34:31.655742+00	5	kurwik wdole	1	[{"added": {}}]	3	1
58	2023-09-17 13:34:42.777682+00	6	smietnik wmasle	1	[{"added": {}}]	3	1
59	2023-09-17 13:40:45.250225+00	33	1251 vs 12124	1	[{"added": {}}]	4	1
60	2023-09-17 13:40:50.548435+00	34	12124 vs 1251	1	[{"added": {}}]	4	1
61	2023-09-17 13:40:54.695212+00	35	1251 vs 12124	1	[{"added": {}}]	4	1
62	2023-09-17 13:41:00.232951+00	36	12124 vs 12124	1	[{"added": {}}]	4	1
63	2023-09-17 13:41:04.820233+00	37	1251 vs 12124	1	[{"added": {}}]	4	1
64	2023-09-17 13:41:10.328951+00	38	1251 vs 12124	1	[{"added": {}}]	4	1
65	2023-09-17 13:41:17.822348+00	39	12124 vs 12124	1	[{"added": {}}]	4	1
66	2023-09-17 13:41:21.803339+00	40	1251 vs 1251	1	[{"added": {}}]	4	1
67	2023-09-17 13:41:25.636323+00	41	1251 vs 12124	1	[{"added": {}}]	4	1
68	2023-09-17 13:41:31.697707+00	42	12124 vs 1251	1	[{"added": {}}]	4	1
69	2023-09-17 13:44:09.180478+00	43	1251 vs 1251	1	[{"added": {}}]	4	1
70	2023-09-17 13:44:15.100734+00	44	1251 vs 12124	1	[{"added": {}}]	4	1
71	2023-09-17 13:44:19.585768+00	45	12124 vs 12124	1	[{"added": {}}]	4	1
72	2023-09-17 13:44:23.524711+00	46	1251 vs 12124	1	[{"added": {}}]	4	1
73	2023-09-17 15:12:23.862573+00	47	1251 vs 12124	1	[{"added": {}}]	4	1
74	2023-09-17 15:12:28.58158+00	48	1251 vs 12124	1	[{"added": {}}]	4	1
75	2023-09-17 15:12:33.269531+00	49	1251 vs 12124	1	[{"added": {}}]	4	1
76	2023-09-17 15:12:37.225975+00	50	12124 vs 1251	1	[{"added": {}}]	4	1
77	2023-09-17 15:12:40.614517+00	51	12124 vs 1251	1	[{"added": {}}]	4	1
78	2023-09-17 15:12:45.941832+00	52	1251 vs 1251	1	[{"added": {}}]	4	1
79	2023-09-18 10:44:44.757307+00	5	Orzeł BTS	1	[{"added": {}}]	2	1
80	2023-09-18 10:45:03.625846+00	4	1251	3		2	1
81	2023-09-18 10:45:09.218741+00	3	12124	3		2	1
82	2023-09-18 10:45:44.211967+00	6	Deeks United	1	[{"added": {}}]	2	1
83	2023-09-18 10:45:57.978633+00	7	Odwiert	1	[{"added": {}}]	2	1
84	2023-09-18 10:46:13.227737+00	8	The Gunners Nowa Huta	1	[{"added": {}}]	2	1
85	2023-09-18 10:46:29.404648+00	9	ELECTROSMART	1	[{"added": {}}]	2	1
86	2023-09-18 10:46:40.760095+00	10	Zwyrole	1	[{"added": {}}]	2	1
87	2023-09-18 10:46:53.857503+00	11	Sportowcy Nałogowcy	1	[{"added": {}}]	2	1
88	2023-09-18 10:47:08.138921+00	12	AKS Wolni Strzelcy	1	[{"added": {}}]	2	1
89	2023-09-18 10:47:25.576578+00	13	Strassenbande	1	[{"added": {}}]	2	1
90	2023-09-18 10:47:38.178893+00	14	Hellas Ivvona	1	[{"added": {}}]	2	1
91	2023-09-18 10:47:58.203724+00	15	Diablo Kraków	1	[{"added": {}}]	2	1
92	2023-09-18 10:48:08.828598+00	16	Rosso Negri FC	1	[{"added": {}}]	2	1
93	2023-09-18 10:48:22.514962+00	17	FC Promil Kraków	1	[{"added": {}}]	2	1
94	2023-09-18 10:48:43.439291+00	18	Rozbójnicy Pabiana	1	[{"added": {}}]	2	1
95	2023-09-18 10:51:25.299132+00	19	KS Kondycja	1	[{"added": {}}]	2	1
96	2023-09-18 11:06:57.346903+00	20	IKS Łucznik Kraków 1	1	[{"added": {}}]	2	1
97	2023-09-18 11:07:09.920633+00	21	Iskra Kraków	1	[{"added": {}}]	2	1
98	2023-09-18 11:07:22.925391+00	22	Issa Sport	1	[{"added": {}}]	2	1
99	2023-09-18 11:07:35.284585+00	23	Super Strikes	1	[{"added": {}}]	2	1
100	2023-09-18 11:07:48.472877+00	24	KS Kremerowianka	1	[{"added": {}}]	2	1
101	2023-09-18 11:08:06.028759+00	25	TS Żelbeton Płaszów	1	[{"added": {}}]	2	1
102	2023-09-18 11:08:21.408447+00	26	Perła Sport	1	[{"added": {}}]	2	1
103	2023-09-18 11:08:38.0113+00	27	FC Sołtyse	1	[{"added": {}}]	2	1
104	2023-09-18 11:08:53.528161+00	28	FC Obywatele	1	[{"added": {}}]	2	1
105	2023-09-18 11:09:06.460201+00	29	WKS Wawel	1	[{"added": {}}]	2	1
106	2023-09-18 11:09:32.220502+00	30	Sneak Peak	1	[{"added": {}}]	2	1
107	2023-09-18 11:09:50.172737+00	31	Rozbójnicy Rumcajsa	1	[{"added": {}}]	2	1
108	2023-09-18 11:10:04.48926+00	32	NieNajMłodsi	1	[{"added": {}}]	2	1
109	2023-09-18 11:10:21.384361+00	33	Błękitne Kasztany	1	[{"added": {}}]	2	1
110	2023-09-18 11:10:37.514005+00	34	Najlepsi w Mieście	1	[{"added": {}}]	2	1
111	2023-09-18 11:10:53.348135+00	35	FC Braziliana	1	[{"added": {}}]	2	1
112	2023-09-18 11:16:16.732958+00	36	FC 2+2	1	[{"added": {}}]	2	1
113	2023-09-19 11:31:41.191123+00	53	Orzeł BTS vs Deeks United	1	[{"added": {}}]	4	1
114	2023-09-19 11:31:46.40608+00	54	AKS Wolni Strzelcy vs Deeks United	1	[{"added": {}}]	4	1
115	2023-09-19 12:00:21.436211+00	7	2 3	1	[{"added": {}}]	3	1
116	2023-09-19 12:00:29.005028+00	8	15 16	1	[{"added": {}}]	3	1
117	2023-09-19 12:00:37.053686+00	9	125 1567	1	[{"added": {}}]	3	1
118	2023-09-19 12:02:01.198977+00	9	Kamil Świerszczyk	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	1
119	2023-09-19 12:02:08.005103+00	8	Piotr Połomski	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	1
120	2023-09-19 12:02:15.571355+00	7	Stanisław Kot	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	1
121	2023-09-19 12:03:58.917135+00	55	Deeks United vs Orzeł BTS	1	[{"added": {}}]	4	1
122	2023-09-19 12:19:17.802875+00	55	Deeks United vs Orzeł BTS	3		4	1
123	2023-09-19 12:19:17.834008+00	54	AKS Wolni Strzelcy vs Deeks United	3		4	1
124	2023-09-19 12:19:17.864299+00	53	Orzeł BTS vs Deeks United	3		4	1
125	2023-09-19 12:19:23.973696+00	9	Kamil Świerszczyk	3		3	1
126	2023-09-19 12:19:24.006958+00	8	Piotr Połomski	3		3	1
127	2023-09-19 12:19:24.037423+00	7	Stanisław Kot	3		3	1
128	2023-09-19 13:18:57.70217+00	37	U-Diablo	1	[{"added": {}}]	2	1
129	2023-09-19 13:19:08.719559+00	38	Pogoń Kraków	1	[{"added": {}}]	2	1
130	2023-09-19 13:19:21.02792+00	39	Laga FC	1	[{"added": {}}]	2	1
131	2023-09-19 13:19:32.024476+00	40	Cracov Elite	1	[{"added": {}}]	2	1
132	2023-09-19 13:19:42.8348+00	41	OG Libertów	1	[{"added": {}}]	2	1
133	2023-09-19 13:19:55.439143+00	42	FC Jesiotry	1	[{"added": {}}]	2	1
134	2023-09-19 13:20:09.647121+00	43	FC Kalecy	1	[{"added": {}}]	2	1
135	2023-09-19 13:20:21.528555+00	44	Gruzik Wieliczka	1	[{"added": {}}]	2	1
136	2023-09-19 13:20:33.121732+00	45	Sztywni Nieugięci	1	[{"added": {}}]	2	1
137	2023-09-19 13:20:44.158285+00	46	Alibaba FC	1	[{"added": {}}]	2	1
138	2023-09-19 13:20:58.196609+00	47	Huragan Koniowały	1	[{"added": {}}]	2	1
139	2023-09-19 13:21:10.591988+00	48	Małopolskie ZHR	1	[{"added": {}}]	2	1
140	2023-09-19 13:21:24.867556+00	49	III LO Hooligans	1	[{"added": {}}]	2	1
141	2023-09-19 13:21:37.379414+00	50	Kac Kraków	1	[{"added": {}}]	2	1
142	2023-09-19 13:21:47.957975+00	51	FC Anony	1	[{"added": {}}]	2	1
143	2023-09-19 13:22:03.743419+00	52	FootCanser	1	[{"added": {}}]	2	1
144	2023-09-19 13:22:13.236519+00	53	AP Galaxy	1	[{"added": {}}]	2	1
145	2023-09-19 13:22:26.04819+00	54	TEAM Salvator	1	[{"added": {}}]	2	1
146	2023-09-19 13:22:49.104665+00	55	Biuro Ochrony Stonoga	1	[{"added": {}}]	2	1
147	2023-09-19 13:23:00.056052+00	56	FC Cytadela	1	[{"added": {}}]	2	1
148	2023-09-19 13:23:14.754972+00	57	Grzenkowianka Ego Topy	1	[{"added": {}}]	2	1
149	2023-09-19 13:23:26.965233+00	58	FC Imigranci	1	[{"added": {}}]	2	1
150	2023-09-19 13:23:37.965572+00	59	MKS Mistrzejowice	1	[{"added": {}}]	2	1
151	2023-09-19 13:23:50.914155+00	60	FC Agenci	1	[{"added": {}}]	2	1
152	2023-09-19 13:24:16.835679+00	61	FC Curra Kieciurra	1	[{"added": {}}]	2	1
153	2023-09-19 13:24:31.065863+00	62	FC Szpytu	1	[{"added": {}}]	2	1
154	2023-09-19 13:24:45.93616+00	63	IKS Łucznik Kraków 2	1	[{"added": {}}]	2	1
155	2023-09-19 13:24:57.849402+00	64	FC Pacynki	1	[{"added": {}}]	2	1
156	2023-09-19 13:25:09.026438+00	65	Galacticos Kraków 2023	1	[{"added": {}}]	2	1
157	2023-09-19 13:25:20.432262+00	66	Partyzant Nowa Huta	1	[{"added": {}}]	2	1
158	2023-09-19 13:25:34.292486+00	67	FF Sao Paulo	1	[{"added": {}}]	2	1
159	2023-09-19 13:25:41.943974+00	68	OIOM	1	[{"added": {}}]	2	1
160	2023-09-19 13:25:51.725994+00	69	Lużne Grajki	1	[{"added": {}}]	2	1
161	2023-09-19 13:26:02.141895+00	70	RB Karpiów	1	[{"added": {}}]	2	1
162	2023-09-19 13:26:15.090221+00	71	AL-Kohol FC	1	[{"added": {}}]	2	1
163	2023-09-19 13:26:28.105137+00	72	Alimenciarze	1	[{"added": {}}]	2	1
164	2023-09-19 13:39:46.552087+00	1	captain	1	[{"added": {}}]	7	1
165	2023-09-19 13:41:02.338009+00	2	kapitan	1	[{"added": {}}]	8	1
166	2023-09-19 13:41:13.016047+00	2	kapitan	2	[{"changed": {"fields": ["Groups"]}}]	8	1
167	2023-09-19 14:01:09.517345+00	3	Kalifikini	1	[{"added": {}}]	8	1
168	2023-09-19 14:06:58.382727+00	4	miniligastaff	1	[{"added": {}}]	8	1
169	2023-09-19 14:07:13.314901+00	4	miniligastaff	2	[{"changed": {"fields": ["Staff status", "Date joined"]}}]	8	1
170	2023-09-19 14:07:20.051595+00	3	Kalifikini	3		8	1
171	2023-09-19 14:09:15.151832+00	4	miniligastaff	2	[{"changed": {"fields": ["User permissions"]}}]	8	1
172	2023-09-19 14:09:51.860595+00	5	Kolamaryny	1	[{"added": {}}]	8	4
173	2023-09-19 14:10:57.307657+00	5	Kolamaryny	3		8	4
174	2023-09-19 14:12:00.472487+00	2	kapitan	2	[{"changed": {"fields": ["password"]}}]	8	4
175	2023-09-19 14:24:12.281664+00	1	admin	2	[{"changed": {"fields": ["password"]}}]	8	1
176	2023-09-20 12:20:53.731494+00	10	Krystian Percik	1	[{"added": {}}]	3	4
177	2023-09-20 12:21:42.128517+00	11	Jekub Kleczar	1	[{"added": {}}]	3	4
178	2023-09-20 12:22:03.31737+00	12	Filip Kreczmer	1	[{"added": {}}]	3	4
179	2023-09-20 12:22:19.582143+00	13	Stanisław Boczarski	1	[{"added": {}}]	3	4
180	2023-09-20 12:22:38.710701+00	14	Karol Sapiński	1	[{"added": {}}]	3	4
181	2023-09-20 12:22:54.736186+00	15	Dawid Czechowicz	1	[{"added": {}}]	3	4
182	2023-09-20 12:23:13.129487+00	16	Karol Kozuba	1	[{"added": {}}]	3	4
183	2023-09-20 12:23:27.224306+00	17	Wiktor Karcz	1	[{"added": {}}]	3	4
184	2023-09-20 12:23:48.923553+00	18	Filip Grzonka	1	[{"added": {}}]	3	4
185	2023-09-20 12:24:03.825643+00	19	Karol Kustal	1	[{"added": {}}]	3	4
186	2023-09-20 12:24:28.815156+00	20	Łukasz Różycki	1	[{"added": {}}]	3	4
187	2023-09-20 12:24:47.077476+00	21	Tomek Tychoniak	1	[{"added": {}}]	3	4
188	2023-09-20 12:27:41.805701+00	22	Aleksander Gregoraszczuk	1	[{"added": {}}]	3	4
189	2023-09-20 12:27:50.871271+00	22	Aleksander Gregoraszczuk	2	[{"changed": {"fields": ["Role"]}}]	3	4
190	2023-09-20 12:28:16.023937+00	23	Jasiek Jablonka	1	[{"added": {}}]	3	4
191	2023-09-20 12:28:40.733352+00	24	Kacper Galek	1	[{"added": {}}]	3	4
192	2023-09-20 12:29:04.023121+00	25	Karol Luźyński	1	[{"added": {}}]	3	4
193	2023-09-20 12:29:20.433609+00	26	Karol Walczak	1	[{"added": {}}]	3	4
194	2023-09-20 12:29:43.869436+00	27	Konrad Kukułka	1	[{"added": {}}]	3	4
195	2023-09-20 12:30:02.32592+00	28	Marcin Dud	1	[{"added": {}}]	3	4
196	2023-09-20 12:30:19.773645+00	29	Mateusz Ostrowski	1	[{"added": {}}]	3	4
197	2023-09-20 12:30:47.023281+00	30	Maurycy Jakubiec	1	[{"added": {}}]	3	4
198	2023-09-20 12:31:11.063194+00	31	Michał Kobierzynski	1	[{"added": {}}]	3	4
199	2023-09-20 12:31:26.021264+00	32	Piotr Pyka	1	[{"added": {}}]	3	4
200	2023-09-20 12:31:45.55797+00	33	Stanisław Kosch	1	[{"added": {}}]	3	4
201	2023-09-20 12:32:06.186992+00	34	Stanisław Tynor	1	[{"added": {}}]	3	4
202	2023-09-20 12:32:25.736247+00	35	Szymon Olajossy	1	[{"added": {}}]	3	4
203	2023-09-20 12:32:48.234878+00	36	Tadeusz Pieczarkowski	1	[{"added": {}}]	3	4
204	2023-09-20 12:33:04.396754+00	37	Tadeusz Pitera	1	[{"added": {}}]	3	4
205	2023-09-20 12:33:20.447332+00	38	Tomasz Strach	1	[{"added": {}}]	3	4
206	2023-09-20 12:34:41.32648+00	39	Eryk Wesołowski	1	[{"added": {}}]	3	4
207	2023-09-20 12:35:00.356258+00	40	Daniel Tabor	1	[{"added": {}}]	3	4
208	2023-09-20 12:35:24.963021+00	41	Szymon Everard	1	[{"added": {}}]	3	4
209	2023-09-20 12:35:39.168304+00	42	Bartek Everard	1	[{"added": {}}]	3	4
210	2023-09-20 12:35:52.927178+00	43	Kuba Michalik	1	[{"added": {}}]	3	4
211	2023-09-20 12:36:09.629029+00	44	Jakub Poręba	1	[{"added": {}}]	3	4
212	2023-09-20 12:36:24.040879+00	45	Filip Poręba	1	[{"added": {}}]	3	4
213	2023-09-20 12:36:48.115141+00	46	Filip Poręba	1	[{"added": {}}]	3	4
214	2023-09-20 12:37:06.601332+00	47	Grzegorz Monsurek	1	[{"added": {}}]	3	4
215	2023-09-20 12:37:26.795937+00	48	Kewin Cięciała	1	[{"added": {}}]	3	4
216	2023-09-20 12:37:44.381374+00	49	Karol Mętel	1	[{"added": {}}]	3	4
217	2023-09-20 12:38:02.212358+00	50	Patryk Michalik	1	[{"added": {}}]	3	4
218	2023-09-20 12:38:16.419117+00	51	Patryk Rakoczy	1	[{"added": {}}]	3	4
219	2023-09-20 12:40:26.066156+00	52	Łukasz Litwin	1	[{"added": {}}]	3	4
220	2023-09-20 12:40:51.86471+00	53	Adrian Kołodziejczyk	1	[{"added": {}}]	3	4
221	2023-09-20 12:41:09.415119+00	54	Amadeusz Bufnal	1	[{"added": {}}]	3	4
222	2023-09-20 12:41:24.424976+00	55	Bartek Buczak	1	[{"added": {}}]	3	4
223	2023-09-20 12:42:01.765125+00	56	Maurycy Tokajuk	1	[{"added": {}}]	3	4
224	2023-09-20 12:42:16.417854+00	57	Dariusz Barcik	1	[{"added": {}}]	3	4
225	2023-09-20 12:42:38.567462+00	58	Jan Zawaliński	1	[{"added": {}}]	3	4
226	2023-09-20 12:42:38.916836+00	59	Jan Zawaliński	1	[{"added": {}}]	3	4
227	2023-09-20 12:42:48.283729+00	59	Jan Zawaliński	3		3	4
228	2023-09-20 12:43:05.295316+00	60	Kacper Kasprzyk	1	[{"added": {}}]	3	4
229	2023-09-20 12:43:19.187105+00	61	Karol Kitliński	1	[{"added": {}}]	3	4
230	2023-09-20 12:43:37.070968+00	62	Maciej Postek	1	[{"added": {}}]	3	4
231	2023-09-20 12:43:55.140076+00	63	Michał Nowak	1	[{"added": {}}]	3	4
232	2023-09-20 12:44:13.671266+00	64	Patryk Kustosz	1	[{"added": {}}]	3	4
233	2023-09-20 12:44:31.756271+00	65	Paweł Cerazy	1	[{"added": {}}]	3	4
234	2023-09-20 12:44:52.54894+00	66	Przemysław Wojdak	1	[{"added": {}}]	3	4
235	2023-09-20 12:45:06.757512+00	67	Robert Smyrak	1	[{"added": {}}]	3	4
236	2023-09-20 12:45:25.963875+00	68	Szymon Rączka	1	[{"added": {}}]	3	4
237	2023-09-20 12:45:42.51495+00	69	Wojciech Łojszczyk	1	[{"added": {}}]	3	4
238	2023-09-20 12:46:00.062308+00	70	Bartek Kasztelewicz	1	[{"added": {}}]	3	4
239	2023-09-20 12:46:15.233853+00	71	Andrzej Szaroń	1	[{"added": {}}]	3	4
240	2023-09-20 12:46:31.806241+00	72	Dominik Kurzępa	1	[{"added": {}}]	3	4
241	2023-09-20 12:46:49.907532+00	73	Tomasz Błoński	1	[{"added": {}}]	3	4
242	2023-09-20 12:49:23.759467+00	74	Antoni Adamczyk	1	[{"added": {}}]	3	4
243	2023-09-20 12:49:49.485758+00	75	Krzysztof Boryczko	1	[{"added": {}}]	3	4
244	2023-09-20 12:50:10.218937+00	76	Maciek Dynia	1	[{"added": {}}]	3	4
245	2023-09-20 12:50:43.638803+00	77	Michał Dutkowski	1	[{"added": {}}]	3	4
246	2023-09-20 12:51:13.813893+00	78	Tomasz Jesionek	1	[{"added": {}}]	3	4
247	2023-09-20 12:51:37.501617+00	79	Wojtek Fenc	1	[{"added": {}}]	3	4
248	2023-09-20 12:51:57.338002+00	80	Bartosz Urbańczyk	1	[{"added": {}}]	3	4
249	2023-09-20 12:52:19.727011+00	81	Jakub Roś	1	[{"added": {}}]	3	4
250	2023-09-20 12:52:36.846373+00	82	Jan Kelpka	1	[{"added": {}}]	3	4
251	2023-09-20 12:52:54.097742+00	83	Jan Robak	1	[{"added": {}}]	3	4
252	2023-09-20 12:53:21.001482+00	84	Jan Van Der Brug	1	[{"added": {}}]	3	4
253	2023-09-20 12:53:46.13121+00	85	Wiktor Filipczyk	1	[{"added": {}}]	3	4
254	2023-09-20 12:54:35.148154+00	86	Mateusz Sikora	1	[{"added": {}}]	3	4
255	2023-09-20 12:54:51.159187+00	87	Dawid Staśko	1	[{"added": {}}]	3	4
256	2023-09-20 12:55:10.862301+00	88	Jasiek Suberlak	1	[{"added": {}}]	3	4
257	2023-09-20 12:55:38.667978+00	89	Franek Rokowski	1	[{"added": {}}]	3	4
258	2023-09-20 12:56:06.007743+00	90	Ignacy Bujak	1	[{"added": {}}]	3	4
259	2023-09-20 12:56:22.916178+00	91	Jan Kaniowski	1	[{"added": {}}]	3	4
260	2023-09-20 12:57:00.753426+00	92	Dawid Marzec	1	[{"added": {}}]	3	4
261	2023-09-20 12:57:17.145386+00	93	Filip Majka	1	[{"added": {}}]	3	4
262	2023-09-20 12:57:32.709304+00	94	Hubert Waś	1	[{"added": {}}]	3	4
263	2023-09-20 12:57:45.93826+00	95	Iwo Szlachetko	1	[{"added": {}}]	3	4
264	2023-09-20 12:58:01.338486+00	96	Kacper Matwijewski	1	[{"added": {}}]	3	4
265	2023-09-20 12:58:19.707239+00	97	Kacper Suchowski	1	[{"added": {}}]	3	4
266	2023-09-20 12:58:31.934361+00	98	Kamil Bieńko	1	[{"added": {}}]	3	4
267	2023-09-20 12:58:50.076378+00	99	Kamil Klimas	1	[{"added": {}}]	3	4
268	2023-09-20 12:59:08.921572+00	100	Konrad Kasperczyk	1	[{"added": {}}]	3	4
269	2023-09-20 12:59:22.330709+00	101	Konrad Strzałka	1	[{"added": {}}]	3	4
270	2023-09-20 12:59:37.707418+00	102	Maciek Pohl	1	[{"added": {}}]	3	4
271	2023-09-20 12:59:55.771522+00	103	Maks Krawczyk	1	[{"added": {}}]	3	4
272	2023-09-20 13:00:17.814389+00	104	Marcin Szuberla	1	[{"added": {}}]	3	4
273	2023-09-20 13:00:30.41477+00	105	Michał Dykacz	1	[{"added": {}}]	3	4
274	2023-09-20 13:00:46.035522+00	106	Michał Sodo	1	[{"added": {}}]	3	4
275	2023-09-20 13:01:00.215335+00	107	Oskar Bodek	1	[{"added": {}}]	3	4
276	2023-09-20 13:01:14.446533+00	108	Tomek Słupski	1	[{"added": {}}]	3	4
277	2023-09-20 13:01:59.485842+00	109	Arkadiusz Górecki	1	[{"added": {}}]	3	4
278	2023-09-20 13:03:35.474537+00	110	Dawid Pindel	1	[{"added": {}}]	3	4
279	2023-09-20 13:03:53.117414+00	111	Dymitr Krawczuk	1	[{"added": {}}]	3	4
280	2023-09-20 13:04:06.476637+00	112	Krystian Opach	1	[{"added": {}}]	3	4
281	2023-09-20 13:04:23.758569+00	113	Kuba Kopeć	1	[{"added": {}}]	3	4
282	2023-09-20 13:04:46.761449+00	114	Łukasz Dziuba	1	[{"added": {}}]	3	4
283	2023-09-20 13:05:04.053143+00	115	Maciej Bryg	1	[{"added": {}}]	3	4
284	2023-09-20 13:05:16.95685+00	116	Mateusz Gajda	1	[{"added": {}}]	3	4
285	2023-09-20 13:05:35.18044+00	117	Michał Bryg	1	[{"added": {}}]	3	4
286	2023-09-20 13:05:54.27161+00	118	Michał Kękuś	1	[{"added": {}}]	3	4
287	2023-09-20 13:06:13.107503+00	119	Michał Mucha	1	[{"added": {}}]	3	4
288	2023-09-20 13:06:27.81455+00	120	Oskar Stoczek	1	[{"added": {}}]	3	4
289	2023-09-20 13:06:44.921061+00	121	Mateusz Woźniak	1	[{"added": {}}]	3	4
290	2023-09-20 13:06:59.234637+00	122	Wiktor Giętka	1	[{"added": {}}]	3	4
291	2023-09-20 13:07:18.962397+00	123	Krzysztof Zachwieja	1	[{"added": {}}]	3	4
292	2023-09-20 13:07:36.505915+00	124	Marek Górecki	1	[{"added": {}}]	3	4
293	2023-09-20 13:07:47.329754+00	125	Wojciech Piwko	1	[{"added": {}}]	3	4
294	2023-09-20 13:08:03.325882+00	126	Mateusz Łabuś	1	[{"added": {}}]	3	4
295	2023-09-20 13:08:17.773417+00	127	Szymon Bończyk	1	[{"added": {}}]	3	4
296	2023-09-20 13:08:38.851234+00	128	Łukasz Sumara	1	[{"added": {}}]	3	4
297	2023-09-20 13:08:51.84139+00	129	Mateusz Kuś	1	[{"added": {}}]	3	4
298	2023-09-20 13:09:05.23515+00	130	Benedykt Krawczuk	1	[{"added": {}}]	3	4
299	2023-09-20 13:09:23.412641+00	131	Krzysztof Baran	1	[{"added": {}}]	3	4
300	2023-09-20 13:09:37.07547+00	132	Krystian Nowak	1	[{"added": {}}]	3	4
301	2023-09-20 13:09:53.211157+00	133	Bartłomiej Tokarz	1	[{"added": {}}]	3	4
302	2023-09-20 13:10:08.547625+00	134	Filip Puchała	1	[{"added": {}}]	3	4
303	2023-09-20 13:10:28.125843+00	135	Dominik Powierża	1	[{"added": {}}]	3	4
304	2023-09-20 13:15:53.0153+00	136	Oskar Adamczyk	1	[{"added": {}}]	3	4
305	2023-09-20 13:16:14.731251+00	137	Kuba Kobylarczyk	1	[{"added": {}}]	3	4
306	2023-09-20 13:16:35.06438+00	138	Krzysztof Jaszcz	1	[{"added": {}}]	3	4
307	2023-09-20 13:16:47.285975+00	139	Antek Ochalik	1	[{"added": {}}]	3	4
308	2023-09-20 13:16:59.530618+00	140	Adrian Ochalik	1	[{"added": {}}]	3	4
309	2023-09-20 13:17:10.497029+00	141	Michał Jasik	1	[{"added": {}}]	3	4
310	2023-09-20 13:17:29.498704+00	142	Mikołaj Wójcik	1	[{"added": {}}]	3	4
311	2023-09-20 13:17:50.01519+00	143	Szymon Sikora	1	[{"added": {}}]	3	4
312	2023-09-20 13:18:04.667807+00	144	Gabriel Zawałkiewicz	1	[{"added": {}}]	3	4
313	2023-09-20 13:18:24.652661+00	145	Kacper Grudziński	1	[{"added": {}}]	3	4
314	2023-09-20 13:18:56.34228+00	146	Kacper Grudziński	1	[{"added": {}}]	3	4
315	2023-09-20 13:19:15.806205+00	147	Maciek Wiszniewski	1	[{"added": {}}]	3	4
316	2023-09-20 13:19:34.627184+00	148	Daniel Wojtaszkiewicz	1	[{"added": {}}]	3	4
317	2023-09-20 13:19:55.027536+00	149	Mateusz Kasprzyk	1	[{"added": {}}]	3	4
318	2023-09-20 13:20:07.337522+00	150	Jakub Kotyza	1	[{"added": {}}]	3	4
319	2023-09-20 13:20:22.934678+00	151	Wojtek Jaszcz	1	[{"added": {}}]	3	4
320	2023-09-20 13:20:36.107927+00	152	Bartek Bogusz	1	[{"added": {}}]	3	4
321	2023-09-20 13:21:52.638654+00	153	Maciej Pala	1	[{"added": {}}]	3	4
322	2023-09-20 13:22:17.769713+00	154	Sebastian Zięba	1	[{"added": {}}]	3	4
323	2023-09-20 13:22:33.039713+00	155	Łukasz Pieczara	1	[{"added": {}}]	3	4
324	2023-09-20 13:22:50.185134+00	156	Paweł Cichoń	1	[{"added": {}}]	3	4
325	2023-09-20 13:23:04.324966+00	157	Marek Żukowski	1	[{"added": {}}]	3	4
326	2023-09-20 13:23:17.513334+00	158	Paweł CHałubek	1	[{"added": {}}]	3	4
327	2023-09-20 13:23:32.438545+00	159	Łukasz Matyjasz	1	[{"added": {}}]	3	4
328	2023-09-20 13:23:49.752317+00	160	Mateusz Długosz	1	[{"added": {}}]	3	4
329	2023-09-20 13:24:05.448366+00	161	Dawid Porwański	1	[{"added": {}}]	3	4
330	2023-09-20 13:24:17.407808+00	162	Paweł Żak	1	[{"added": {}}]	3	4
331	2023-09-20 13:24:29.994054+00	163	Jacek Kogut	1	[{"added": {}}]	3	4
332	2023-09-20 13:24:51.198416+00	164	Mariusz Klejdysz	1	[{"added": {}}]	3	4
333	2023-09-20 13:25:07.377838+00	165	Marcin Ligas	1	[{"added": {}}]	3	4
334	2023-09-20 13:25:31.323637+00	166	Daniel Walenciak	1	[{"added": {}}]	3	4
335	2023-09-20 13:25:47.119133+00	167	Paweł Kozieł	1	[{"added": {}}]	3	4
336	2023-09-20 13:26:03.028681+00	168	Emanuel Wściubiak	1	[{"added": {}}]	3	4
337	2023-09-20 13:26:20.418217+00	169	Wojciech Żuk	1	[{"added": {}}]	3	4
338	2023-09-20 13:26:34.124264+00	170	Krystian Filipek	1	[{"added": {}}]	3	4
339	2023-09-21 10:29:58.687011+00	171	Dmitrij Malczik	1	[{"added": {}}]	3	4
340	2023-09-21 10:30:17.016419+00	172	Konstantin Runets	1	[{"added": {}}]	3	4
341	2023-09-21 10:30:36.115262+00	173	Yauhen Kavalueski	1	[{"added": {}}]	3	4
342	2023-09-21 10:30:53.730999+00	174	Alex Grasievich	1	[{"added": {}}]	3	4
343	2023-09-21 10:31:10.140113+00	175	Anton Pashkevich	1	[{"added": {}}]	3	4
344	2023-09-21 10:31:33.88568+00	176	Roman Ledak	1	[{"added": {}}]	3	4
345	2023-09-21 10:31:55.173878+00	177	Aliaksei Shydlouski	1	[{"added": {}}]	3	4
346	2023-09-21 10:32:13.012345+00	178	Aliaksei Mandryk	1	[{"added": {}}]	3	4
347	2023-09-21 10:32:29.833408+00	179	Pawel Mandryk	1	[{"added": {}}]	3	4
348	2023-09-21 10:32:47.851244+00	180	Alexander Tatulchankau	1	[{"added": {}}]	3	4
349	2023-09-21 10:33:02.947417+00	181	Ivan Dantsevich	1	[{"added": {}}]	3	4
350	2023-09-21 10:33:19.790073+00	182	Renis Hodo	1	[{"added": {}}]	3	4
351	2023-09-21 10:33:36.964587+00	183	Zmicier Ramancou	1	[{"added": {}}]	3	4
352	2023-09-21 10:33:55.4521+00	184	Yaroslav Myroniuk	1	[{"added": {}}]	3	4
353	2023-09-21 10:34:20.875103+00	185	Illia Pigusov	1	[{"added": {}}]	3	4
354	2023-09-21 10:35:56.329329+00	186	Adam Doniec	1	[{"added": {}}]	3	4
355	2023-09-21 10:36:13.327261+00	187	Andrzej Dorobisz	1	[{"added": {}}]	3	4
356	2023-09-21 10:36:39.735876+00	188	Andrzej Dumanowski	1	[{"added": {}}]	3	4
357	2023-09-21 10:36:57.528777+00	189	Arkadiusz Micek	1	[{"added": {}}]	3	4
358	2023-09-21 10:37:18.764915+00	190	Arkadiusz Wójcik	1	[{"added": {}}]	3	4
359	2023-09-21 10:37:38.995878+00	191	Augustyn Moskal	1	[{"added": {}}]	3	4
360	2023-09-21 10:38:08.314926+00	192	Bohdan Sobiecki	1	[{"added": {}}]	3	4
361	2023-09-21 10:38:42.926442+00	193	Damian Świerk	1	[{"added": {}}]	3	4
362	2023-09-21 10:39:09.980301+00	194	Dominik Baran	1	[{"added": {}}]	3	4
363	2023-09-21 10:39:25.358019+00	195	Filip Kowalewski	1	[{"added": {}}]	3	4
364	2023-09-21 10:39:40.70394+00	196	Franek Rychlak	1	[{"added": {}}]	3	4
365	2023-09-21 10:39:58.99187+00	197	Hubert Dziadzio	1	[{"added": {}}]	3	4
366	2023-09-21 10:40:16.795317+00	198	Jacek Bazan	1	[{"added": {}}]	3	4
367	2023-09-21 10:41:01.064269+00	199	Jacek Kulakowski	1	[{"added": {}}]	3	4
368	2023-09-21 10:41:16.547845+00	200	Jacek Niemiec	1	[{"added": {}}]	3	4
369	2023-09-21 10:41:36.421419+00	201	Jakub Deląg	1	[{"added": {}}]	3	4
370	2023-09-21 10:42:13.633384+00	202	Jakub Gocał	1	[{"added": {}}]	3	4
371	2023-09-21 10:42:34.738137+00	203	Jakub Miazga	1	[{"added": {}}]	3	4
372	2023-09-21 10:42:52.726186+00	204	Jakub Palczewski	1	[{"added": {}}]	3	4
373	2023-09-21 10:43:20.277444+00	205	Jakub Wolski	1	[{"added": {}}]	3	4
374	2023-09-21 10:43:37.860777+00	206	Kamil Cisło	1	[{"added": {}}]	3	4
375	2023-09-21 10:43:55.657253+00	207	Krzysztof Baran	1	[{"added": {}}]	3	4
376	2023-09-21 10:44:14.058859+00	208	Maksymilina Wojczuk	1	[{"added": {}}]	3	4
377	2023-09-21 10:44:32.616248+00	209	Marcin Fabisiewicz	1	[{"added": {}}]	3	4
378	2023-09-21 10:44:47.389982+00	210	Mateusz Baran	1	[{"added": {}}]	3	4
379	2023-09-21 10:45:05.505091+00	211	Mateusz Różkowski	1	[{"added": {}}]	3	4
380	2023-09-21 10:45:19.057912+00	212	Michał Bielawski	1	[{"added": {}}]	3	4
381	2023-09-21 10:45:32.937373+00	213	Michał Drzewiej	1	[{"added": {}}]	3	4
382	2023-09-21 10:45:47.617127+00	214	Michał Kruk	1	[{"added": {}}]	3	4
383	2023-09-21 10:45:59.952407+00	215	Michał Mróz	1	[{"added": {}}]	3	4
384	2023-09-21 10:46:18.346348+00	216	Miłosz Rzyczniak	1	[{"added": {}}]	3	4
385	2023-09-21 10:46:33.637993+00	217	Paweł Pelczar	1	[{"added": {}}]	3	4
386	2023-09-21 10:46:58.508248+00	218	Piotr Badura	1	[{"added": {}}]	3	4
387	2023-09-21 10:47:12.425431+00	219	Piotr Karola	1	[{"added": {}}]	3	4
388	2023-09-21 10:47:22.921116+00	220	Piotr Kulis	1	[{"added": {}}]	3	4
389	2023-09-21 10:47:38.346754+00	221	Piotr Mróz	1	[{"added": {}}]	3	4
390	2023-09-21 10:47:53.643012+00	222	Piotr Słowakiewicz	1	[{"added": {}}]	3	4
391	2023-09-21 10:48:36.29475+00	223	Stanisław Czubek	1	[{"added": {}}]	3	4
392	2023-09-21 10:49:05.833807+00	224	Stanisław Zieliński	1	[{"added": {}}]	3	4
393	2023-09-21 10:49:18.381241+00	225	Szymon Pyzik	1	[{"added": {}}]	3	4
394	2023-09-21 10:49:38.292204+00	226	Szymon Spiradek	1	[{"added": {}}]	3	4
395	2023-09-21 10:49:54.027543+00	227	Tadeusz Zalewski	1	[{"added": {}}]	3	4
396	2023-09-21 10:50:17.834407+00	228	Tom Tom	1	[{"added": {}}]	3	4
397	2023-09-21 10:50:39.007182+00	229	Wojciech Palczewski	1	[{"added": {}}]	3	4
398	2023-09-21 10:50:49.409116+00	230	Wojtek Popławski	1	[{"added": {}}]	3	4
399	2023-09-21 10:51:03.640513+00	231	Wojtek Zalewski	1	[{"added": {}}]	3	4
400	2023-09-21 10:51:16.228356+00	232	Tomasz Smołka	1	[{"added": {}}]	3	4
401	2023-09-21 10:51:29.778532+00	233	Jakub Podsiadło	1	[{"added": {}}]	3	4
402	2023-09-21 10:51:48.818871+00	234	Filip Derda	1	[{"added": {}}]	3	4
403	2023-09-21 10:54:47.630554+00	235	Kuba Kobylarczyk	1	[{"added": {}}]	3	4
404	2023-09-21 10:55:11.135077+00	236	Ivan Milenin	1	[{"added": {}}]	3	4
405	2023-09-21 10:55:48.739158+00	237	Kamil Turski	1	[{"added": {}}]	3	4
406	2023-09-21 10:56:16.995165+00	238	Maciek Dzięgiel	1	[{"added": {}}]	3	4
407	2023-09-21 10:56:35.542698+00	239	Izu Mara	1	[{"added": {}}]	3	4
408	2023-09-21 10:56:57.368704+00	240	Maciek Kazimierczak	1	[{"added": {}}]	3	4
409	2023-09-21 10:57:19.09225+00	241	Adam Krzywonos	1	[{"added": {}}]	3	4
410	2023-09-21 10:57:34.187611+00	242	Jan Gruszczyk	1	[{"added": {}}]	3	4
411	2023-09-21 10:57:52.010141+00	243	Andrzej Kończyk	1	[{"added": {}}]	3	4
412	2023-09-21 10:58:05.438905+00	244	Konrad Kopyś	1	[{"added": {}}]	3	4
413	2023-09-21 10:58:32.624055+00	245	Michał Wiącek	1	[{"added": {}}]	3	4
414	2023-09-21 10:58:58.07518+00	246	Bernard Kowal	1	[{"added": {}}]	3	4
415	2023-09-21 10:59:16.551552+00	247	Paweł Lejczak	1	[{"added": {}}]	3	4
416	2023-09-21 10:59:31.934067+00	248	Kuba Grot	1	[{"added": {}}]	3	4
417	2023-09-21 10:59:45.606829+00	249	Adrian Pol	1	[{"added": {}}]	3	4
418	2023-09-21 10:59:58.884683+00	250	Mateusz Czułowski	1	[{"added": {}}]	3	4
419	2023-09-21 11:00:17.36507+00	251	Marcin Kanigowski	1	[{"added": {}}]	3	4
420	2023-09-21 11:00:39.99673+00	252	Piotr Kazimierczak	1	[{"added": {}}]	3	4
421	2023-09-21 11:00:59.514691+00	253	Mikołaj Życiński	1	[{"added": {}}]	3	4
422	2023-09-21 11:01:21.892828+00	254	Kamil Sosenko	1	[{"added": {}}]	3	4
423	2023-09-21 11:01:49.129882+00	255	Wiesław Kazimierczak	1	[{"added": {}}]	3	4
424	2023-09-21 11:02:13.820951+00	256	Łukasz Bardaliński	1	[{"added": {}}]	3	4
425	2023-09-21 11:02:29.26834+00	257	Kamil Makówka	1	[{"added": {}}]	3	4
426	2023-09-21 11:02:42.814424+00	258	Krzysiek Jaszcz	1	[{"added": {}}]	3	4
427	2023-09-21 11:03:36.799297+00	259	Rafał Pomykała	1	[{"added": {}}]	3	4
428	2023-09-21 11:03:48.210763+00	260	Roman Klimas	1	[{"added": {}}]	3	4
429	2023-09-21 11:04:00.049183+00	261	Michał Stawowski	1	[{"added": {}}]	3	4
430	2023-09-21 11:04:16.955406+00	262	Adrian Klimas	1	[{"added": {}}]	3	4
431	2023-09-21 11:04:28.572001+00	263	Dominik Kasznik	1	[{"added": {}}]	3	4
432	2023-09-21 11:04:39.002096+00	264	Jakub Bednar	1	[{"added": {}}]	3	4
433	2023-09-21 11:04:59.661829+00	265	Josef --------	1	[{"added": {}}]	3	4
434	2023-09-21 11:05:14.666618+00	266	Arek Pol	1	[{"added": {}}]	3	4
435	2023-09-21 11:05:29.470853+00	267	Karol Malinowski	1	[{"added": {}}]	3	4
436	2023-09-21 11:05:39.863625+00	268	Patryk Przęczek	1	[{"added": {}}]	3	4
437	2023-09-21 11:05:52.43285+00	269	Maciek Musiał	1	[{"added": {}}]	3	4
438	2023-09-21 11:06:07.098075+00	270	Michał Kardasz	1	[{"added": {}}]	3	4
439	2023-09-21 11:06:19.599708+00	271	Mateusz Hendzel	1	[{"added": {}}]	3	4
440	2023-09-21 11:06:39.635575+00	272	Mateusz Kużdżal	1	[{"added": {}}]	3	4
441	2023-09-21 11:06:50.669671+00	273	Janek Gręda	1	[{"added": {}}]	3	4
442	2023-09-21 11:07:08.040752+00	274	Marian Rybak	1	[{"added": {}}]	3	4
443	2023-09-21 11:10:29.962644+00	275	Jakub Bąkowski	1	[{"added": {}}]	3	4
444	2023-09-21 11:10:46.884835+00	276	Łukasz Arłamowski	1	[{"added": {}}]	3	4
445	2023-09-21 11:11:01.632808+00	277	Jakub Kukla	1	[{"added": {}}]	3	4
446	2023-09-21 11:11:27.309963+00	278	Marcin Pulnar	1	[{"added": {}}]	3	4
447	2023-09-21 11:11:43.719303+00	279	Dariusz Skalski	1	[{"added": {}}]	3	4
448	2023-09-21 11:12:01.870969+00	280	Kacper Szydło	1	[{"added": {}}]	3	4
449	2023-09-21 11:12:14.236016+00	281	Łukasz Nowak	1	[{"added": {}}]	3	4
450	2023-09-21 11:12:37.063475+00	282	Szymon Celejewski	1	[{"added": {}}]	3	4
451	2023-09-21 11:12:51.423024+00	283	Kamil Gołębiowski	1	[{"added": {}}]	3	4
452	2023-09-21 11:13:05.988356+00	284	Jakub Maj	1	[{"added": {}}]	3	4
453	2023-09-21 11:13:24.142817+00	285	Badgo Santana	1	[{"added": {}}]	3	4
454	2023-09-21 11:14:04.303453+00	286	Tomasz Lipieta	1	[{"added": {}}]	3	4
455	2023-09-21 11:14:24.580812+00	287	Patryk Jackowicz	1	[{"added": {}}]	3	4
456	2023-09-21 11:14:43.012182+00	288	Szymon Wcisło	1	[{"added": {}}]	3	4
457	2023-09-21 11:14:59.552396+00	289	Przemysław Rychlik	1	[{"added": {}}]	3	4
458	2023-09-21 11:15:26.646971+00	290	Mateusz Nasuto	1	[{"added": {}}]	3	4
459	2023-09-21 11:16:38.0702+00	291	Jakub Bugaj	1	[{"added": {}}]	3	4
460	2023-09-21 11:16:49.264883+00	292	Tomasz Gola	1	[{"added": {}}]	3	4
461	2023-09-21 11:17:05.637061+00	293	Szymon Muniak	1	[{"added": {}}]	3	4
462	2023-09-21 11:17:23.720125+00	294	Patryk Daniec	1	[{"added": {}}]	3	4
463	2023-09-21 11:17:46.85822+00	295	Adam Tran Thi Thu	1	[{"added": {}}]	3	4
464	2023-09-21 11:17:58.803886+00	296	Szymon Wesołowski	1	[{"added": {}}]	3	4
465	2023-09-21 11:18:14.21756+00	297	Kacper Matwijewski	1	[{"added": {}}]	3	4
466	2023-09-21 11:18:37.582913+00	298	Jakub Markiewicz	1	[{"added": {}}]	3	4
467	2023-09-21 11:18:48.745167+00	299	Dawid Ciuba	1	[{"added": {}}]	3	4
468	2023-09-21 11:19:08.430459+00	300	Maks Ślusarczyk	1	[{"added": {}}]	3	4
469	2023-09-21 11:19:20.436022+00	301	Krystian Opach	1	[{"added": {}}]	3	4
470	2023-09-21 11:19:36.517889+00	302	Patryk Bąk	1	[{"added": {}}]	3	4
471	2023-09-21 11:19:49.938994+00	303	Michał Dykacz	1	[{"added": {}}]	3	4
472	2023-09-21 11:20:05.357723+00	304	Adrian Maślanka	1	[{"added": {}}]	3	4
473	2023-09-21 11:20:16.086095+00	305	Jakub Warchał	1	[{"added": {}}]	3	4
474	2023-09-21 11:20:26.741322+00	306	Kacper Zacharski	1	[{"added": {}}]	3	4
475	2023-09-21 11:20:36.916505+00	307	Karol Gzyl	1	[{"added": {}}]	3	4
476	2023-09-21 11:20:50.353045+00	308	Miłosz Karnia	1	[{"added": {}}]	3	4
477	2023-09-21 11:21:05.168965+00	309	Jakub Wierzchowski	1	[{"added": {}}]	3	4
478	2023-09-21 11:21:59.333803+00	310	Mateusz Śmiech	1	[{"added": {}}]	3	4
479	2023-09-21 11:22:14.374496+00	311	Kacper Piszczek	1	[{"added": {}}]	3	4
480	2023-09-21 11:22:24.885225+00	312	Mateusz Torba	1	[{"added": {}}]	3	4
481	2023-09-21 11:22:36.63742+00	313	Adam Wątor	1	[{"added": {}}]	3	4
482	2023-09-21 11:22:48.001322+00	314	Aleksander Dziekański	1	[{"added": {}}]	3	4
483	2023-09-21 11:23:03.61196+00	315	Bartek Gąsior	1	[{"added": {}}]	3	4
484	2023-09-21 11:23:18.992766+00	316	Damian Świca	1	[{"added": {}}]	3	4
485	2023-09-21 11:23:45.203556+00	317	Hubert Gąsior	1	[{"added": {}}]	3	4
486	2023-09-21 11:24:00.748779+00	318	Jędrzej Ściegienny	1	[{"added": {}}]	3	4
487	2023-09-21 11:24:13.24019+00	319	Mateusz Stawik	1	[{"added": {}}]	3	4
488	2023-09-21 11:24:22.913731+00	320	Kacper Górecki	1	[{"added": {}}]	3	4
489	2023-09-21 11:24:31.555152+00	321	Kacper Kalita	1	[{"added": {}}]	3	4
490	2023-09-21 11:24:43.109129+00	322	Kuba Barber	1	[{"added": {}}]	3	4
491	2023-09-21 11:24:52.527092+00	323	Kuba Uchacz	1	[{"added": {}}]	3	4
492	2023-09-21 11:25:04.280784+00	324	Maciej Dworakowski	1	[{"added": {}}]	3	4
493	2023-09-21 11:25:15.511257+00	325	Maks Kruszec	1	[{"added": {}}]	3	4
494	2023-09-21 11:25:30.547159+00	326	Mateusz Rożek	1	[{"added": {}}]	3	4
495	2023-09-21 11:25:42.628987+00	327	Michał Najder	1	[{"added": {}}]	3	4
496	2023-09-21 11:25:54.032033+00	328	Michał Pardygał	1	[{"added": {}}]	3	4
497	2023-09-21 11:26:07.339266+00	329	Mikołaj Wnuk	1	[{"added": {}}]	3	4
498	2023-09-21 11:26:19.963215+00	330	Patryk Torba	1	[{"added": {}}]	3	4
499	2023-09-21 11:26:35.996089+00	331	Piotr Broda	1	[{"added": {}}]	3	4
500	2023-09-21 11:31:27.431317+00	332	Shun Ishikawa	1	[{"added": {}}]	3	4
501	2023-09-21 11:31:48.178858+00	333	Mateusz Niżnik	1	[{"added": {}}]	3	4
502	2023-09-21 11:32:02.119211+00	334	Michał Hajdo	1	[{"added": {}}]	3	4
503	2023-09-21 11:32:14.727031+00	335	Szymon Pyrcz	1	[{"added": {}}]	3	4
504	2023-09-21 11:32:28.326215+00	336	Olaf Nowak	1	[{"added": {}}]	3	4
505	2023-09-21 11:32:48.828853+00	337	Staszek Szajding	1	[{"added": {}}]	3	4
506	2023-09-21 11:32:59.695028+00	338	Daniel Kruk	1	[{"added": {}}]	3	4
507	2023-09-21 11:33:15.238896+00	339	Olek Czop	1	[{"added": {}}]	3	4
508	2023-09-21 11:33:40.765712+00	340	Szymon Żukrowski	1	[{"added": {}}]	3	4
509	2023-09-21 11:33:56.684271+00	341	Franek Wiehle	1	[{"added": {}}]	3	4
510	2023-09-21 11:34:09.213653+00	342	Jeremi Kowalski	1	[{"added": {}}]	3	4
511	2023-09-21 11:34:21.632559+00	343	Jan Drochliński	1	[{"added": {}}]	3	4
512	2023-09-21 11:34:41.852593+00	344	Mateusz Pulchny	1	[{"added": {}}]	3	4
513	2023-09-21 11:35:00.554067+00	345	Mateusz Marszałek	1	[{"added": {}}]	3	4
514	2023-09-21 11:35:15.379301+00	346	Maciek Sawicki	1	[{"added": {}}]	3	4
515	2023-09-21 11:35:28.205032+00	347	Filip Kucharczyk	1	[{"added": {}}]	3	4
516	2023-09-21 11:35:42.820026+00	348	Maks Kawiorski	1	[{"added": {}}]	3	4
517	2023-09-21 11:36:01.36118+00	349	Marcel Zając	1	[{"added": {}}]	3	4
518	2023-09-21 11:40:32.619344+00	350	Igor Gajda	1	[{"added": {}}]	3	4
519	2023-09-21 11:40:57.105281+00	351	Igor Stadnicki	1	[{"added": {}}]	3	4
520	2023-09-21 11:41:08.635917+00	352	Damian Pstruś	1	[{"added": {}}]	3	4
521	2023-09-21 11:41:23.120524+00	353	Szymon Barasz	1	[{"added": {}}]	3	4
522	2023-09-21 11:41:34.172291+00	354	Maciek Sitarski	1	[{"added": {}}]	3	4
523	2023-09-21 11:41:46.684133+00	355	Hubert Szewczyk	1	[{"added": {}}]	3	4
524	2023-09-21 11:41:57.857576+00	356	Kacper Podlewski	1	[{"added": {}}]	3	4
525	2023-09-21 11:42:07.722361+00	357	Kerim Jemaaoui	1	[{"added": {}}]	3	4
526	2023-09-21 11:42:19.853903+00	358	Mateusz Iwaniec	1	[{"added": {}}]	3	4
527	2023-09-21 11:42:30.66381+00	359	Oskar Midera	1	[{"added": {}}]	3	4
528	2023-09-21 11:42:44.952663+00	360	Staszek Boczarski	1	[{"added": {}}]	3	4
529	2023-09-21 11:42:56.895515+00	361	Jakub Prostak	1	[{"added": {}}]	3	4
530	2023-09-21 11:43:06.062566+00	362	Karol Sapiński	1	[{"added": {}}]	3	4
531	2023-09-21 11:43:16.89203+00	363	Jakub Kleczar	1	[{"added": {}}]	3	4
532	2023-09-21 11:43:30.140629+00	364	Filip Kreczmer	1	[{"added": {}}]	3	4
533	2023-09-21 12:11:45.282824+00	365	Mateusz Psica	1	[{"added": {}}]	3	4
534	2023-09-21 12:12:30.327173+00	366	Miłosz Śmiały	1	[{"added": {}}]	3	4
535	2023-09-21 12:12:56.32502+00	367	Dawid Nowicki	1	[{"added": {}}]	3	4
536	2023-09-21 12:13:18.886231+00	368	Nataniel Borek	1	[{"added": {}}]	3	4
537	2023-09-21 12:13:33.428549+00	369	Karol Waz	1	[{"added": {}}]	3	4
538	2023-09-21 12:13:48.602238+00	370	Mateusz Bajak	1	[{"added": {}}]	3	4
539	2023-09-21 12:14:05.558503+00	371	Arkadiusz Baran	1	[{"added": {}}]	3	4
540	2023-09-21 12:14:20.81611+00	372	Michał Capik	1	[{"added": {}}]	3	4
541	2023-09-21 12:14:40.339156+00	373	Michał Kurowski	1	[{"added": {}}]	3	4
542	2023-09-21 12:14:56.946103+00	374	Eryk Nowicki	1	[{"added": {}}]	3	4
543	2023-09-21 12:16:10.226891+00	375	Patryk Jackowicz	1	[{"added": {}}]	3	4
544	2023-09-21 12:16:23.434811+00	376	Szymon Wcisło	1	[{"added": {}}]	3	4
545	2023-09-21 12:16:35.652934+00	377	Piotr Hanusiak	1	[{"added": {}}]	3	4
546	2023-09-21 12:16:54.424701+00	378	Kamil Gołębiowski	1	[{"added": {}}]	3	4
547	2023-09-21 12:17:08.083069+00	379	Mikołaj Batko	1	[{"added": {}}]	3	4
548	2023-09-21 12:17:22.543483+00	380	Adrian Poźniak	1	[{"added": {}}]	3	4
549	2023-09-21 12:17:40.14226+00	381	Mateusz Nasuto	1	[{"added": {}}]	3	4
550	2023-09-21 12:17:57.087089+00	382	Wojciech Furgała	1	[{"added": {}}]	3	4
551	2023-09-21 12:18:11.515367+00	383	Bartłomiej Sitek	1	[{"added": {}}]	3	4
552	2023-09-21 12:18:24.431879+00	384	Łukasz Krawczyk	1	[{"added": {}}]	3	4
553	2023-09-21 12:18:38.70131+00	385	Jan Kępa	1	[{"added": {}}]	3	4
554	2023-09-21 12:18:50.644163+00	386	Michał Dudek	1	[{"added": {}}]	3	4
555	2023-09-21 12:19:04.075333+00	387	Kacper Okulski	1	[{"added": {}}]	3	4
556	2023-09-21 12:19:17.378791+00	388	Wojciech Gucwa	1	[{"added": {}}]	3	4
557	2023-09-21 12:19:28.614286+00	389	Marcel Mazur	1	[{"added": {}}]	3	4
558	2023-09-21 12:19:46.865002+00	390	Arkadiusz Nosal	1	[{"added": {}}]	3	4
559	2023-09-21 12:19:58.37807+00	391	Damian Serafin	1	[{"added": {}}]	3	4
560	2023-09-21 12:20:10.453295+00	392	Maciej Federowicz	1	[{"added": {}}]	3	4
561	2023-09-21 12:20:22.716238+00	393	Oskar Świątek	1	[{"added": {}}]	3	4
562	2023-09-21 12:20:36.29591+00	394	Szymon Synowiecki	1	[{"added": {}}]	3	4
563	2023-09-21 12:20:48.33637+00	395	Darek Nowak	1	[{"added": {}}]	3	4
564	2023-09-21 12:21:01.127403+00	396	Norbert Uchacz	1	[{"added": {}}]	3	4
565	2023-09-21 12:21:12.034416+00	397	Dawid Wasserman	1	[{"added": {}}]	3	4
566	2023-09-21 12:21:27.106969+00	398	Tomasz Lipieta	1	[{"added": {}}]	3	4
567	2023-09-21 12:21:41.902697+00	399	Michał Szarlej	1	[{"added": {}}]	3	4
568	2023-09-21 12:22:43.014949+00	400	Radosław Dachowski	1	[{"added": {}}]	3	4
569	2023-09-21 12:23:00.500733+00	401	Kamil Wypartowicz	1	[{"added": {}}]	3	4
570	2023-09-21 12:23:11.264431+00	402	Daniel Wypartowicz	1	[{"added": {}}]	3	4
571	2023-09-21 12:23:22.270091+00	403	Jacek Wypartowicz	1	[{"added": {}}]	3	4
572	2023-09-21 12:23:38.824718+00	404	Bartek Wypartowicz	1	[{"added": {}}]	3	4
573	2023-09-21 12:23:50.844466+00	405	Kamil Tyczyński	1	[{"added": {}}]	3	4
574	2023-09-21 12:24:08.549439+00	406	Tomek Piąstka	1	[{"added": {}}]	3	4
575	2023-09-21 12:24:19.344914+00	407	Damian Piąstka	1	[{"added": {}}]	3	4
576	2023-09-21 12:24:36.390496+00	408	Michał Mitoński	1	[{"added": {}}]	3	4
577	2023-09-21 12:24:47.739852+00	409	Mateusz Grochowski	1	[{"added": {}}]	3	4
578	2023-09-21 12:25:00.091881+00	410	Łukasz Hojol	1	[{"added": {}}]	3	4
579	2023-09-21 12:26:22.036075+00	411	Sylewster Koza	1	[{"added": {}}]	3	4
580	2023-09-21 12:26:37.380084+00	412	Kamil Gawęda	1	[{"added": {}}]	3	4
581	2023-09-21 12:26:49.11897+00	413	Sebastian Firlej	1	[{"added": {}}]	3	4
582	2023-09-21 12:27:02.656706+00	414	Tomasz Gola	1	[{"added": {}}]	3	4
583	2023-09-21 12:27:18.425061+00	415	Łukasz Janiszewski	1	[{"added": {}}]	3	4
584	2023-09-21 12:27:36.319351+00	416	Patryk Daniec	1	[{"added": {}}]	3	4
585	2023-09-21 12:27:51.642338+00	417	Jakub Tabor	1	[{"added": {}}]	3	4
586	2023-09-21 12:28:08.00061+00	418	Mateusz Niedopytalski	1	[{"added": {}}]	3	4
587	2023-09-21 12:28:23.887366+00	419	Piotr Sucharski	1	[{"added": {}}]	3	4
588	2023-09-21 12:28:36.955728+00	420	Paweł Juszczyk	1	[{"added": {}}]	3	4
589	2023-09-21 12:28:55.56171+00	421	Szymon Wojtaszek	1	[{"added": {}}]	3	4
590	2023-09-21 12:29:11.126223+00	422	Dominik Tomaszewski	1	[{"added": {}}]	3	4
591	2023-09-21 12:29:29.184417+00	423	Maciek Boguta	1	[{"added": {}}]	3	4
592	2023-09-21 12:29:45.585812+00	424	Adrian Żurowicz	1	[{"added": {}}]	3	4
593	2023-09-21 12:30:01.144268+00	425	Igor Włodarz	1	[{"added": {}}]	3	4
594	2023-09-21 12:30:13.631061+00	426	Jacek Brzegowy	1	[{"added": {}}]	3	4
595	2023-09-21 12:30:29.425578+00	427	Łukasz Pawlik	1	[{"added": {}}]	3	4
596	2023-09-21 12:30:45.752708+00	428	Rafał Roczniak	1	[{"added": {}}]	3	4
597	2023-09-21 12:30:56.463073+00	429	Maciej Stuhr	1	[{"added": {}}]	3	4
598	2023-09-21 12:34:26.867341+00	430	Bartłomiej Bugaj	1	[{"added": {}}]	3	4
599	2023-09-21 12:34:45.06539+00	431	Jakub Swatowski	1	[{"added": {}}]	3	4
600	2023-09-21 12:34:57.792067+00	432	Kacper Kruczek	1	[{"added": {}}]	3	4
601	2023-09-21 12:35:15.234694+00	433	Bartosz Woźniak	1	[{"added": {}}]	3	4
602	2023-09-21 12:35:31.63524+00	434	Maciek Markiewicz	1	[{"added": {}}]	3	4
603	2023-09-21 12:35:47.906308+00	435	Fabian Kiepura	1	[{"added": {}}]	3	4
604	2023-09-21 12:36:03.453965+00	436	Adrian Włodarski	1	[{"added": {}}]	3	4
605	2023-09-21 12:36:17.43851+00	437	Kamil Włodarski	1	[{"added": {}}]	3	4
606	2023-09-21 12:36:41.328797+00	438	Kacper Federowicz	1	[{"added": {}}]	3	4
607	2023-09-21 12:37:03.321359+00	439	Patryk Gawin	1	[{"added": {}}]	3	4
608	2023-09-21 12:37:20.338532+00	440	Oskar Kiepura	1	[{"added": {}}]	3	4
609	2023-09-21 12:37:36.540565+00	441	Adam Gierasiński	1	[{"added": {}}]	3	4
610	2023-09-21 12:38:01.050715+00	442	Franciszek Godfrajów	1	[{"added": {}}]	3	4
611	2023-09-21 12:38:19.245682+00	443	Andrzej Bugaj	1	[{"added": {}}]	3	4
612	2023-09-21 12:38:35.503595+00	444	Kuba Nowak	1	[{"added": {}}]	3	4
613	2023-09-21 12:38:50.857578+00	445	Wiktor Pompka	1	[{"added": {}}]	3	4
614	2023-09-21 12:39:08.201972+00	446	Daniel Morozewicz	1	[{"added": {}}]	3	4
615	2023-09-21 12:39:24.313573+00	447	Tymek Leśniak	1	[{"added": {}}]	3	4
616	2023-09-21 12:39:39.24846+00	448	Kacper Windak	1	[{"added": {}}]	3	4
617	2023-09-21 12:42:32.711023+00	449	Jakub Brzozowski	1	[{"added": {}}]	3	4
618	2023-09-21 12:42:51.485321+00	450	Mateusz Łabuś	1	[{"added": {}}]	3	4
619	2023-09-21 12:43:18.439665+00	451	Theodore Townsend	1	[{"added": {}}]	3	4
620	2023-09-21 12:43:35.126488+00	452	Igor Maślej	1	[{"added": {}}]	3	4
621	2023-09-21 12:43:55.437132+00	453	Filip Kowalski	1	[{"added": {}}]	3	4
622	2023-09-21 12:44:10.89378+00	454	Aron Król	1	[{"added": {}}]	3	4
623	2023-09-21 12:44:30.739881+00	455	Krzysztof Malina	1	[{"added": {}}]	3	4
624	2023-09-21 12:44:48.160154+00	456	Jakub Chruszcz	1	[{"added": {}}]	3	4
625	2023-09-21 12:45:01.467782+00	457	Tymoteusz Policha	1	[{"added": {}}]	3	4
626	2023-09-21 12:45:18.249363+00	458	Piotr Sucharski	1	[{"added": {}}]	3	4
627	2023-09-21 12:45:33.975272+00	459	Piotr Sucharski	1	[{"added": {}}]	3	4
628	2023-09-21 12:45:49.59479+00	460	Damian Głogowski	1	[{"added": {}}]	3	4
629	2023-09-21 12:46:06.748475+00	461	Daniel Tkaczuk	1	[{"added": {}}]	3	4
630	2023-09-21 12:46:25.79086+00	462	Mateusz Krzak	1	[{"added": {}}]	3	4
631	2023-09-21 12:46:40.353229+00	463	Kacper Sirko	1	[{"added": {}}]	3	4
632	2023-09-21 12:47:49.597171+00	464	Konrad Rudziński	1	[{"added": {}}]	3	4
633	2023-09-21 12:48:03.52616+00	465	Grzegorz Kulesza	1	[{"added": {}}]	3	4
634	2023-09-21 12:48:17.598375+00	466	Adam Nowak	1	[{"added": {}}]	3	4
635	2023-09-21 12:48:33.507017+00	467	Adam Nowak	1	[{"added": {}}]	3	4
636	2023-09-21 12:48:49.363781+00	468	Artur Nowak	1	[{"added": {}}]	3	4
637	2023-09-21 12:49:00.826843+00	469	Patryk Drobniak	1	[{"added": {}}]	3	4
638	2023-09-21 12:49:17.350552+00	470	Tomasz Poradzisz	1	[{"added": {}}]	3	4
639	2023-09-21 12:49:37.288585+00	471	Jan Nowacki	1	[{"added": {}}]	3	4
640	2023-09-21 12:49:50.141796+00	472	Filip Kolasa	1	[{"added": {}}]	3	4
641	2023-09-21 12:50:05.77036+00	473	Arkadiusz Rudziński	1	[{"added": {}}]	3	4
642	2023-09-21 12:50:23.429052+00	474	Oskar Zaręba	1	[{"added": {}}]	3	4
643	2023-09-21 12:50:41.365515+00	475	Jan Cybulski	1	[{"added": {}}]	3	4
644	2023-09-21 12:50:51.95365+00	476	Antek Sędzimir	1	[{"added": {}}]	3	4
645	2023-09-21 12:51:48.091915+00	477	Michał Derdaś	1	[{"added": {}}]	3	4
646	2023-09-21 12:52:12.62281+00	478	Grzegorz Rybicki	1	[{"added": {}}]	3	4
647	2023-09-21 12:52:28.039894+00	479	Jakub Polus	1	[{"added": {}}]	3	4
648	2023-09-21 12:52:43.64238+00	480	Krzysztof Goldman	1	[{"added": {}}]	3	4
649	2023-09-21 12:52:58.032379+00	481	Witek Łuszcz	1	[{"added": {}}]	3	4
650	2023-09-21 12:53:10.932916+00	482	Sebastian Kaczor	1	[{"added": {}}]	3	4
651	2023-09-21 12:53:22.161016+00	483	Radek Kubacki	1	[{"added": {}}]	3	4
652	2023-09-21 12:53:39.173383+00	484	Jacek Hessel	1	[{"added": {}}]	3	4
653	2023-09-21 12:53:50.098365+00	485	Marek Hessel	1	[{"added": {}}]	3	4
654	2023-09-21 12:54:02.334714+00	486	Konrad Śmietana	1	[{"added": {}}]	3	4
655	2023-09-21 12:54:16.113848+00	487	Łukasz Wojtal	1	[{"added": {}}]	3	4
656	2023-09-21 12:54:30.24902+00	488	Jakub Ptak	1	[{"added": {}}]	3	4
657	2023-09-21 12:54:42.827595+00	489	Mateusz Rybicki	1	[{"added": {}}]	3	4
658	2023-09-21 12:56:07.378385+00	490	Olek Dziedzic	1	[{"added": {}}]	3	4
659	2023-09-21 12:56:27.596292+00	491	Karol Strączyński	1	[{"added": {}}]	3	4
660	2023-09-21 12:59:55.54558+00	492	Paweł Cichoń	1	[{"added": {}}]	3	4
661	2023-09-21 13:00:43.220851+00	493	Janek Lepak	1	[{"added": {}}]	3	4
662	2023-09-21 13:00:53.857265+00	494	Marcin Dudek	1	[{"added": {}}]	3	4
663	2023-09-21 13:01:11.359236+00	495	Kuba Badowski	1	[{"added": {}}]	3	4
664	2023-09-21 13:01:23.893786+00	496	Jan Puchała	1	[{"added": {}}]	3	4
665	2023-09-21 13:01:39.657207+00	497	Leon Hołda	1	[{"added": {}}]	3	4
666	2023-09-21 13:01:53.623798+00	498	Wiktor Banachowicz	1	[{"added": {}}]	3	4
667	2023-09-21 13:02:07.978546+00	499	Tymon Budyń	1	[{"added": {}}]	3	4
668	2023-09-21 13:02:20.552159+00	500	Eryk Gucio	1	[{"added": {}}]	3	4
669	2023-09-21 13:02:34.049903+00	501	Patryk Bobak	1	[{"added": {}}]	3	4
670	2023-09-21 13:02:47.817223+00	502	Tadeusz Mularczyk	1	[{"added": {}}]	3	4
671	2023-09-21 13:03:03.929653+00	503	Oliwier Kłys	1	[{"added": {}}]	3	4
672	2023-09-21 13:03:16.820641+00	504	Patryk Gałas	1	[{"added": {}}]	3	4
673	2023-09-21 13:03:30.757931+00	505	Filip Adamczyk	1	[{"added": {}}]	3	4
674	2023-09-21 13:03:48.806428+00	506	Jan Jodłowski	1	[{"added": {}}]	3	4
675	2023-09-21 13:04:02.727781+00	507	Stefek Barylski	1	[{"added": {}}]	3	4
676	2023-09-21 13:04:22.936114+00	508	Mateusz Ponczek	1	[{"added": {}}]	3	4
677	2023-09-21 13:04:37.584645+00	509	Maksymilian Sobociński	1	[{"added": {}}]	3	4
678	2023-09-21 13:06:01.278789+00	510	Tomasz Zwoliński	1	[{"added": {}}]	3	4
679	2023-09-21 13:06:14.966898+00	511	Łukasz Zwoliński	1	[{"added": {}}]	3	4
680	2023-09-21 13:06:26.606293+00	512	Kamil Calik	1	[{"added": {}}]	3	4
681	2023-09-21 13:06:38.047919+00	513	Maciej Woś	1	[{"added": {}}]	3	4
682	2023-09-21 13:06:52.000821+00	514	Krystian Grabowski	1	[{"added": {}}]	3	4
683	2023-09-21 13:07:04.533188+00	515	Paweł Kulczak	1	[{"added": {}}]	3	4
684	2023-09-21 13:07:22.129139+00	516	Paweł Kulczak	1	[{"added": {}}]	3	4
685	2023-09-21 13:07:53.122919+00	516	Adrian Juraś	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	4
686	2023-09-21 13:08:11.046469+00	517	Krzysiek Giba	1	[{"added": {}}]	3	4
687	2023-09-21 13:08:11.429023+00	518	Krzysiek Giba	1	[{"added": {}}]	3	4
688	2023-09-21 13:08:29.352761+00	518	Adam Koprowski	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	4
689	2023-09-21 13:08:42.826393+00	519	Paweł Cieśl	1	[{"added": {}}]	3	4
690	2023-09-21 13:08:57.164877+00	520	Renan Primo	1	[{"added": {}}]	3	4
691	2023-09-21 13:10:01.757003+00	521	Józef Adamczyk	1	[{"added": {}}]	3	4
692	2023-09-21 13:10:17.754958+00	522	Szymon Antończyk	1	[{"added": {}}]	3	4
693	2023-09-21 13:10:32.095535+00	523	Natalia Bania	1	[{"added": {}}]	3	4
694	2023-09-21 13:10:35.58717+00	524	Natalia Bania	1	[{"added": {}}]	3	4
695	2023-09-21 13:10:47.597749+00	524	Jakub Biernacki	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	4
696	2023-09-21 13:11:04.676545+00	525	Bartłomiej Bogadewicz	1	[{"added": {}}]	3	4
697	2023-09-21 13:11:16.825598+00	526	Miłosz Hańczyk	1	[{"added": {}}]	3	4
698	2023-09-21 13:11:29.03539+00	527	Jan Jędrusiak	1	[{"added": {}}]	3	4
699	2023-09-21 13:11:43.71866+00	528	Jan Kotyła	1	[{"added": {}}]	3	4
700	2023-09-21 13:11:56.144659+00	529	Franciszek Kwinta	1	[{"added": {}}]	3	4
701	2023-09-21 13:12:13.524203+00	530	Adam Odrzywiołek	1	[{"added": {}}]	3	4
702	2023-09-21 13:12:32.834668+00	531	Grzegorz Odrzywiłek	1	[{"added": {}}]	3	4
703	2023-09-21 13:12:58.973442+00	532	Hubert Salawach	1	[{"added": {}}]	3	4
704	2023-09-21 13:13:15.550749+00	533	Kacper Śliwa	1	[{"added": {}}]	3	4
705	2023-09-21 13:13:27.742548+00	534	Bartłomiej Świtalski	1	[{"added": {}}]	3	4
706	2023-09-21 13:13:39.502075+00	535	Szymon Zimny	1	[{"added": {}}]	3	4
707	2023-09-21 13:16:11.877249+00	536	Patryk Hajduk	1	[{"added": {}}]	3	4
708	2023-09-21 13:16:24.739382+00	537	Mateusz Cierpik	1	[{"added": {}}]	3	4
709	2023-09-21 13:16:38.747878+00	538	Wiktor Pietrzykowski	1	[{"added": {}}]	3	4
710	2023-09-21 13:16:54.716416+00	539	Paweł Ptaśnik	1	[{"added": {}}]	3	4
711	2023-09-21 13:17:21.443444+00	540	Rafał Kościółek	1	[{"added": {}}]	3	4
712	2023-09-21 13:17:33.222559+00	541	Jakub Puto	1	[{"added": {}}]	3	4
713	2023-09-21 13:17:45.23087+00	542	Tomasz Kozak	1	[{"added": {}}]	3	4
714	2023-09-21 13:17:58.124332+00	543	Mateusz Filipek	1	[{"added": {}}]	3	4
715	2023-09-21 13:18:25.660392+00	544	Filip Gwiźdź	1	[{"added": {}}]	3	4
716	2023-09-21 13:18:36.450419+00	545	Oskar Adamczyk	1	[{"added": {}}]	3	4
717	2023-09-21 13:18:49.914434+00	546	Mateusz Gajewski	1	[{"added": {}}]	3	4
718	2023-09-21 13:19:05.388991+00	547	Oleksii Soldatenko	1	[{"added": {}}]	3	4
719	2023-09-21 13:19:17.500935+00	548	Grzegorz Synowiec	1	[{"added": {}}]	3	4
720	2023-09-21 13:19:36.512917+00	549	Grzegorz Jabłoński	1	[{"added": {}}]	3	4
721	2023-09-21 13:19:54.397668+00	550	Gabriel Kruba	1	[{"added": {}}]	3	4
722	2023-09-21 13:20:18.328965+00	551	Eryk Iwaszko	1	[{"added": {}}]	3	4
723	2023-09-21 13:20:35.73664+00	552	Mateusz Hrones	1	[{"added": {}}]	3	4
724	2023-09-21 13:20:46.567589+00	553	Damian Leśniak	1	[{"added": {}}]	3	4
725	2023-09-21 13:21:01.503826+00	554	Marcin Zagórny	1	[{"added": {}}]	3	4
726	2023-09-21 13:21:14.666513+00	555	Hubert Wasilewski	1	[{"added": {}}]	3	4
727	2023-09-21 13:21:38.050118+00	556	Adrian Kruba	1	[{"added": {}}]	3	4
728	2023-09-21 13:21:56.47307+00	557	Damian Horosin	1	[{"added": {}}]	3	4
729	2023-09-21 13:22:30.574225+00	558	Mateusz Studziżba	1	[{"added": {}}]	3	4
730	2023-09-21 13:22:52.145991+00	559	Hubert Biedermann	1	[{"added": {}}]	3	4
731	2023-09-21 13:23:05.974715+00	560	Łukasz Janeczko	1	[{"added": {}}]	3	4
732	2023-09-21 13:23:19.176818+00	561	Jakub Maczeński	1	[{"added": {}}]	3	4
733	2023-09-21 13:23:33.642687+00	562	Tymoteusz Grabowski	1	[{"added": {}}]	3	4
734	2023-09-21 13:23:50.755209+00	563	Filip Janowski	1	[{"added": {}}]	3	4
735	2023-09-21 13:24:02.180538+00	564	Michał Magiera	1	[{"added": {}}]	3	4
736	2023-09-21 13:24:23.022447+00	565	Jan Doerre	1	[{"added": {}}]	3	4
737	2023-09-21 13:24:36.258517+00	566	Michał Studziżba	1	[{"added": {}}]	3	4
738	2023-09-21 13:24:48.823368+00	567	Michał Pilch	1	[{"added": {}}]	3	4
739	2023-09-21 13:25:03.538322+00	568	Jan Olejniczak	1	[{"added": {}}]	3	4
740	2023-09-21 13:25:23.822405+00	569	Miłosz Wyjadłowski	1	[{"added": {}}]	3	4
741	2023-09-21 13:25:44.080704+00	570	Sebastian Wójcik	1	[{"added": {}}]	3	4
742	2023-09-21 13:25:58.425546+00	571	Kamil Zdeb	1	[{"added": {}}]	3	4
743	2023-09-21 13:26:16.046136+00	572	Rafał Bochenek	1	[{"added": {}}]	3	4
744	2023-09-21 13:26:29.636682+00	573	Norbert Polak	1	[{"added": {}}]	3	4
745	2023-09-21 13:26:48.400819+00	574	Maksymilian Baran	1	[{"added": {}}]	3	4
746	2023-09-21 13:27:04.67005+00	575	Paweł Myszkowski	1	[{"added": {}}]	3	4
747	2023-09-21 13:27:33.508686+00	576	Krzysztof Kazibudzki	1	[{"added": {}}]	3	4
748	2023-09-21 13:27:52.62735+00	577	Mikołaj Piętak	1	[{"added": {}}]	3	4
749	2023-09-21 13:28:11.963255+00	578	Adrian Kruba	1	[{"added": {}}]	3	4
750	2023-09-21 13:28:28.33299+00	579	Damian Horosin	1	[{"added": {}}]	3	4
751	2023-09-21 13:28:46.788382+00	580	Kuba Wiśniewski	1	[{"added": {}}]	3	4
752	2023-09-22 10:19:24.491626+00	581	Łukasz Dziuba	1	[{"added": {}}]	3	4
753	2023-09-22 10:19:40.475485+00	582	Dawid Pindel	1	[{"added": {}}]	3	4
754	2023-09-22 10:19:56.837921+00	583	Dymitr Krawczuk	1	[{"added": {}}]	3	4
755	2023-09-22 10:20:16.908819+00	584	Oskar Stoczek	1	[{"added": {}}]	3	4
756	2023-09-22 10:20:32.843471+00	585	Oskar Żółciński	1	[{"added": {}}]	3	4
757	2023-09-22 10:20:47.416122+00	586	Krystian Nowak	1	[{"added": {}}]	3	4
758	2023-09-22 10:21:05.000631+00	587	Damian Kudlek	1	[{"added": {}}]	3	4
759	2023-09-22 10:21:20.230271+00	588	Jan Wydziałkiewicz	1	[{"added": {}}]	3	4
760	2023-09-22 10:21:37.566207+00	589	Krzysztof Baran	1	[{"added": {}}]	3	4
761	2023-09-22 10:21:49.530995+00	590	Maciej Serafin	1	[{"added": {}}]	3	4
762	2023-09-22 10:22:03.508164+00	591	Kacper Wydziałkiewicz	1	[{"added": {}}]	3	4
763	2023-09-22 10:22:21.552612+00	592	Miłosz Borowicki	1	[{"added": {}}]	3	4
764	2023-09-22 10:22:37.240184+00	593	Igor Jędrzejczyk	1	[{"added": {}}]	3	4
765	2023-09-22 10:22:52.354613+00	594	Jakub Ptak	1	[{"added": {}}]	3	4
766	2023-09-22 10:23:09.475139+00	595	Jakub Klupa	1	[{"added": {}}]	3	4
767	2023-09-22 10:23:23.887878+00	596	Wojciech Socha	1	[{"added": {}}]	3	4
768	2023-09-22 10:23:37.26189+00	597	Wojciech Foks	1	[{"added": {}}]	3	4
769	2023-09-22 10:23:57.254188+00	598	Kamil Zieleniak	1	[{"added": {}}]	3	4
770	2023-09-22 10:24:09.556845+00	599	Ksawery Konarski	1	[{"added": {}}]	3	4
771	2023-09-22 10:28:28.575845+00	600	Wiktor Waligóra	1	[{"added": {}}]	3	4
772	2023-09-22 10:29:08.302393+00	601	Jędrek Krupiński	1	[{"added": {}}]	3	4
773	2023-09-22 10:29:29.089782+00	602	Michał Latinek	1	[{"added": {}}]	3	4
774	2023-09-22 10:29:48.301578+00	603	Józek Kowalski	1	[{"added": {}}]	3	4
775	2023-09-22 10:30:06.18754+00	604	Michał Rejszek	1	[{"added": {}}]	3	4
776	2023-09-22 10:30:24.726743+00	605	Wiktor Sierant	1	[{"added": {}}]	3	4
777	2023-09-22 10:30:45.483251+00	606	Jakub Wolkowicz	1	[{"added": {}}]	3	4
778	2023-09-22 10:31:13.720817+00	607	Antoni Skowron	1	[{"added": {}}]	3	4
779	2023-09-22 10:31:28.478373+00	608	Bruno Kijowski	1	[{"added": {}}]	3	4
780	2023-09-22 10:31:45.636029+00	609	Iwo Frankiewicz	1	[{"added": {}}]	3	4
781	2023-09-22 10:32:07.599503+00	610	Kamil Kaczmarczyk	1	[{"added": {}}]	3	4
782	2023-09-22 10:32:23.314506+00	611	Szymon Kumorek	1	[{"added": {}}]	3	4
783	2023-09-22 10:32:38.731257+00	612	Michał Fundament	1	[{"added": {}}]	3	4
784	2023-09-22 10:32:52.71823+00	613	Mateusz Guzowski	1	[{"added": {}}]	3	4
785	2023-09-22 10:33:09.403903+00	614	Marcel Turaj	1	[{"added": {}}]	3	4
786	2023-09-22 10:33:23.933517+00	615	Szymon Wołoszyn	1	[{"added": {}}]	3	4
787	2023-09-22 10:34:07.207203+00	616	Adam Ledwon	1	[{"added": {}}]	3	4
788	2023-09-22 10:34:22.610548+00	617	Hubert Waś	1	[{"added": {}}]	3	4
789	2023-09-22 10:34:48.690613+00	618	Jan Borkowski	1	[{"added": {}}]	3	4
790	2023-09-22 10:35:09.258126+00	619	Wiktor Gajoch	1	[{"added": {}}]	3	4
791	2023-09-22 10:35:31.063925+00	620	Maciek Laidler	1	[{"added": {}}]	3	4
792	2023-09-22 10:38:33.510948+00	621	Marcin Rajtar	1	[{"added": {}}]	3	4
793	2023-09-22 10:38:46.777549+00	622	Anatol Strąk	1	[{"added": {}}]	3	4
794	2023-09-22 10:38:59.77297+00	623	Bartek Sosin	1	[{"added": {}}]	3	4
795	2023-09-22 10:39:12.414777+00	624	Dawid Machno	1	[{"added": {}}]	3	4
796	2023-09-22 10:39:39.217083+00	625	Eryk Włodek	1	[{"added": {}}]	3	4
797	2023-09-22 10:59:33.342678+00	626	Filip Gil	1	[{"added": {}}]	3	4
798	2023-09-22 11:08:23.245561+00	627	Filip Morgun	1	[{"added": {}}]	3	4
799	2023-09-22 11:08:40.993315+00	628	Filip Zięcina	1	[{"added": {}}]	3	4
800	2023-09-22 11:09:16.655903+00	629	Igor Wałęga	1	[{"added": {}}]	3	4
801	2023-09-22 11:14:23.040102+00	630	Jan Doniec	1	[{"added": {}}]	3	4
802	2023-09-22 11:14:39.124949+00	631	Janusz Jagiełło	1	[{"added": {}}]	3	4
803	2023-09-22 11:14:53.869366+00	632	Kuba Kobylarczyk	1	[{"added": {}}]	3	4
804	2023-09-22 11:15:08.12243+00	633	Maciek Kosydar	1	[{"added": {}}]	3	4
805	2023-09-22 11:15:19.659591+00	634	Mateusz Adamski	1	[{"added": {}}]	3	4
806	2023-09-22 11:15:50.638284+00	635	Mateusz Wójcik	1	[{"added": {}}]	3	4
807	2023-09-22 11:16:02.816261+00	636	Michał Przybyło	1	[{"added": {}}]	3	4
808	2023-09-22 11:16:15.252217+00	637	Norbert Kasperek	1	[{"added": {}}]	3	4
809	2023-09-22 11:16:26.572401+00	638	Piotr Langier	1	[{"added": {}}]	3	4
810	2023-09-22 11:16:38.86271+00	639	Stachu Kiepura	1	[{"added": {}}]	3	4
811	2023-09-22 11:16:51.231386+00	640	Szymon Zięcina	1	[{"added": {}}]	3	4
812	2023-09-22 11:17:05.80305+00	641	Łukasz Kazała	1	[{"added": {}}]	3	4
813	2023-09-22 11:20:38.126704+00	642	Wojtek Drwota	1	[{"added": {}}]	3	4
814	2023-09-22 11:20:59.925676+00	643	Joachim Bogacki	1	[{"added": {}}]	3	4
815	2023-09-22 11:21:19.761308+00	644	Bartłomiej Wierzba	1	[{"added": {}}]	3	4
816	2023-09-22 11:21:34.075304+00	645	Dominik Bąbol	1	[{"added": {}}]	3	4
817	2023-09-22 11:21:49.189395+00	646	Hubert Januszek	1	[{"added": {}}]	3	4
818	2023-09-22 11:22:11.085251+00	647	Karol Kus	1	[{"added": {}}]	3	4
819	2023-09-22 11:22:33.1232+00	648	Kuba Chwedyk	1	[{"added": {}}]	3	4
820	2023-09-22 11:22:45.86451+00	649	Stefek Barylski	1	[{"added": {}}]	3	4
821	2023-09-22 11:25:15.661942+00	650	Tobiasz Poltorak	1	[{"added": {}}]	3	4
822	2023-09-22 11:25:30.28594+00	651	Tymek Piotrowicz	1	[{"added": {}}]	3	4
823	2023-09-22 11:25:45.923423+00	652	Wojciech Tyberiusz	1	[{"added": {}}]	3	4
824	2023-09-22 11:26:05.752211+00	653	Wojciech Wais	1	[{"added": {}}]	3	4
825	2023-09-22 11:29:32.056662+00	654	Jakub Kasprzyk	1	[{"added": {}}]	3	4
826	2023-09-22 11:29:45.441941+00	655	Adam Kuśmider	1	[{"added": {}}]	3	4
827	2023-09-22 11:29:58.965945+00	656	Dominik Bant	1	[{"added": {}}]	3	4
828	2023-09-22 11:30:13.699033+00	657	Jakub Podraza	1	[{"added": {}}]	3	4
829	2023-09-22 11:30:28.624147+00	658	Karol Kawalec	1	[{"added": {}}]	3	4
830	2023-09-22 11:30:56.669451+00	659	Marcin Barniak	1	[{"added": {}}]	3	4
831	2023-09-22 11:31:08.932866+00	660	Marcin Kłęczek	1	[{"added": {}}]	3	4
832	2023-09-22 11:31:23.221769+00	661	Max Koniorczyk	1	[{"added": {}}]	3	4
833	2023-09-22 11:31:42.228917+00	662	Mikołaj Bereza	1	[{"added": {}}]	3	4
834	2023-09-22 11:31:55.303246+00	663	Nicholas Rusinek	1	[{"added": {}}]	3	4
835	2023-09-22 11:32:08.457337+00	664	Piotr Pęczak	1	[{"added": {}}]	3	4
836	2023-09-22 11:32:22.639321+00	665	Piotr Szymura	1	[{"added": {}}]	3	4
837	2023-09-22 11:32:36.702292+00	666	Szymon Synowiec	1	[{"added": {}}]	3	4
838	2023-09-22 11:32:48.922678+00	667	Szymon Haligowski	1	[{"added": {}}]	3	4
839	2023-09-22 11:33:01.145336+00	668	Szymon Seredyński	1	[{"added": {}}]	3	4
840	2023-09-22 11:33:15.211219+00	669	Szymon Tylek	1	[{"added": {}}]	3	4
841	2023-09-22 11:33:25.1892+00	670	Tomek Fryczek	1	[{"added": {}}]	3	4
842	2023-09-22 11:33:38.562137+00	671	Wiktor Partyka	1	[{"added": {}}]	3	4
843	2023-09-22 11:34:44.056309+00	672	Szymon Nastały	1	[{"added": {}}]	3	4
844	2023-09-22 11:35:01.198124+00	673	Sebastian Tyka	1	[{"added": {}}]	3	4
845	2023-09-22 11:35:15.286047+00	674	Illia Bubnov	1	[{"added": {}}]	3	4
846	2023-09-22 11:35:28.700672+00	675	Michał Radożycki	1	[{"added": {}}]	3	4
847	2023-09-22 11:35:44.134486+00	676	Szymon Zieliński	1	[{"added": {}}]	3	4
848	2023-09-22 11:35:57.803098+00	677	Wiktor Wrona	1	[{"added": {}}]	3	4
849	2023-09-22 11:36:10.931867+00	678	Jakub Duniec	1	[{"added": {}}]	3	4
850	2023-09-22 11:36:24.529036+00	679	Kacper Łudzik	1	[{"added": {}}]	3	4
851	2023-09-22 11:36:39.366426+00	680	Mikołaj Wójcik	1	[{"added": {}}]	3	4
852	2023-09-22 11:36:56.529914+00	681	Igor Jasiówka	1	[{"added": {}}]	3	4
853	2023-09-22 11:37:34.401517+00	681	Dawida Gębuś	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	4
854	2023-09-22 11:38:40.958896+00	682	Eryk Iwaszko	1	[{"added": {}}]	3	4
855	2023-09-22 11:39:04.137593+00	683	Bartek Więcek	1	[{"added": {}}]	3	4
856	2023-09-22 11:39:17.247139+00	684	Stanisław Smoczyński	1	[{"added": {}}]	3	4
857	2023-09-22 11:39:29.486319+00	685	Maciej Maź	1	[{"added": {}}]	3	4
858	2023-09-22 11:39:43.03435+00	686	Michał Stopa	1	[{"added": {}}]	3	4
859	2023-09-22 11:39:58.963573+00	687	Jakub Przedlacki	1	[{"added": {}}]	3	4
860	2023-09-22 11:40:11.532176+00	688	Kamil Cygan	1	[{"added": {}}]	3	4
861	2023-09-22 11:40:23.032757+00	689	Bartłomiej Gostyński	1	[{"added": {}}]	3	4
862	2023-09-22 11:40:38.782306+00	690	Dawid Markowski	1	[{"added": {}}]	3	4
863	2023-09-22 11:40:58.361784+00	691	Dawid Malik	1	[{"added": {}}]	3	4
864	2023-09-22 11:41:13.235062+00	692	Sebastian Saładyga	1	[{"added": {}}]	3	4
865	2023-09-22 11:41:38.232387+00	693	Zuza Sołonczak	1	[{"added": {}}]	3	4
866	2023-09-22 11:41:52.623195+00	694	Oliwier Lassota	1	[{"added": {}}]	3	4
867	2023-09-22 11:42:03.535921+00	695	Oliwier Jarosz	1	[{"added": {}}]	3	4
868	2023-09-22 11:42:18.715732+00	696	Filip Filipczyk	1	[{"added": {}}]	3	4
869	2023-09-22 11:42:33.131224+00	697	Kacper Korbiel	1	[{"added": {}}]	3	4
870	2023-09-22 11:42:45.804642+00	698	Jan Kuc	1	[{"added": {}}]	3	4
871	2023-09-22 11:44:11.494307+00	699	Patryk Pomykała	1	[{"added": {}}]	3	4
872	2023-09-22 11:44:26.231203+00	700	Bartłomiej Gruca	1	[{"added": {}}]	3	4
873	2023-09-22 11:44:37.743176+00	701	Jakub Musiał	1	[{"added": {}}]	3	4
874	2023-09-22 11:44:48.947816+00	702	Mateusz Domagała	1	[{"added": {}}]	3	4
875	2023-09-22 11:44:59.957399+00	703	Jerzy Skwarło	1	[{"added": {}}]	3	4
876	2023-09-22 11:45:15.435719+00	704	Bartłomiej Wilusz	1	[{"added": {}}]	3	4
877	2023-09-22 11:45:25.906286+00	705	Kacper Jednaki	1	[{"added": {}}]	3	4
878	2023-09-22 11:45:39.34666+00	706	Kacper Adamczyk	1	[{"added": {}}]	3	4
879	2023-09-22 11:45:50.551867+00	707	Norbert Wójcik	1	[{"added": {}}]	3	4
880	2023-09-22 11:46:03.519816+00	708	Wojtek Wielgus	1	[{"added": {}}]	3	4
881	2023-09-22 11:46:14.233268+00	709	Patryk Aksamit	1	[{"added": {}}]	3	4
882	2023-09-22 11:46:23.976145+00	710	Zbigniew Kieć	1	[{"added": {}}]	3	4
883	2023-09-22 11:46:37.566902+00	711	Arkadiusz Biegan	1	[{"added": {}}]	3	4
884	2023-09-22 11:56:36.9662+00	712	Maciej Wójcik	1	[{"added": {}}]	3	4
885	2023-09-22 11:57:20.16352+00	713	Igor Szpyt	1	[{"added": {}}]	3	4
886	2023-09-22 11:57:35.591115+00	714	Przemysław Sikora	1	[{"added": {}}]	3	4
887	2023-09-22 11:57:49.293454+00	715	Maciej Miśkiewicz	1	[{"added": {}}]	3	4
888	2023-09-22 11:58:02.735966+00	716	Karol Henrych	1	[{"added": {}}]	3	4
889	2023-09-22 11:58:15.760237+00	717	Dominik Gawlik	1	[{"added": {}}]	3	4
890	2023-09-22 11:58:32.870659+00	718	Emil Szałankiewicz	1	[{"added": {}}]	3	4
891	2023-09-22 11:58:46.984289+00	719	Kuba Ochwat	1	[{"added": {}}]	3	4
892	2023-09-22 11:59:01.048362+00	720	Alek Szafraniec	1	[{"added": {}}]	3	4
893	2023-09-22 11:59:16.350267+00	721	Antoni Tyl	1	[{"added": {}}]	3	4
894	2023-09-22 11:59:36.447128+00	722	Borys Soliński	1	[{"added": {}}]	3	4
895	2023-09-22 11:59:49.175305+00	723	Dawid Sawa	1	[{"added": {}}]	3	4
896	2023-09-22 12:00:10.395954+00	724	Dominik Gawlik	1	[{"added": {}}]	3	4
897	2023-09-22 12:00:26.262971+00	725	Jakub Miechowicz	1	[{"added": {}}]	3	4
898	2023-09-22 12:02:16.680013+00	726	Mikołaj Batko	1	[{"added": {}}]	3	4
899	2023-09-22 12:02:28.307106+00	727	Konrad Marzec	1	[{"added": {}}]	3	4
900	2023-09-22 12:02:44.852052+00	728	Michał Gądek	1	[{"added": {}}]	3	4
901	2023-09-22 12:02:57.263894+00	729	Kacper Małek	1	[{"added": {}}]	3	4
902	2023-09-22 12:03:10.270125+00	730	Marcin Sobczyk	1	[{"added": {}}]	3	4
903	2023-09-22 12:03:23.131862+00	731	Michał Tomsiński	1	[{"added": {}}]	3	4
904	2023-09-22 12:03:35.193748+00	732	Adrian Kucab	1	[{"added": {}}]	3	4
905	2023-09-22 12:03:53.865578+00	733	Krzysztof Miodoński	1	[{"added": {}}]	3	4
906	2023-09-22 12:04:08.577359+00	734	Adam Jędrzejek	1	[{"added": {}}]	3	4
907	2023-09-22 12:04:26.359283+00	735	Konrad Laskowski	1	[{"added": {}}]	3	4
908	2023-09-22 12:04:40.499333+00	736	Łukasz Głowa	1	[{"added": {}}]	3	4
909	2023-09-22 12:04:56.778988+00	737	Kamil Lichwała	1	[{"added": {}}]	3	4
910	2023-09-22 12:11:06.787416+00	738	Jakub Bednar	1	[{"added": {}}]	3	4
911	2023-09-22 12:11:24.532546+00	739	Paweł Karpiński	1	[{"added": {}}]	3	4
912	2023-09-22 12:11:40.453938+00	740	Jakub Grot	1	[{"added": {}}]	3	4
913	2023-09-22 12:12:06.645037+00	741	Michał Wyżga	1	[{"added": {}}]	3	4
914	2023-09-22 12:12:21.256681+00	742	Patryk Hajduk	1	[{"added": {}}]	3	4
915	2023-09-22 12:12:40.5478+00	743	Rafał Krasicki	1	[{"added": {}}]	3	4
916	2023-09-22 12:12:56.061615+00	744	Grzegorz Krasicki	1	[{"added": {}}]	3	4
917	2023-09-22 12:13:42.533114+00	745	Robert Gleń	1	[{"added": {}}]	3	4
918	2023-09-22 12:14:01.699651+00	746	Wojtek Woźny	1	[{"added": {}}]	3	4
919	2023-09-22 12:14:45.530992+00	747	Kacper Kmera	1	[{"added": {}}]	3	4
920	2023-09-22 12:15:04.569789+00	748	Maciej Musiał	1	[{"added": {}}]	3	4
921	2023-09-22 12:15:21.402691+00	749	Michał Luzar	1	[{"added": {}}]	3	4
922	2023-09-22 12:15:35.846717+00	750	Michael Ksishgree	1	[{"added": {}}]	3	4
923	2023-09-22 12:15:59.406137+00	751	Mateusz Sumera	1	[{"added": {}}]	3	4
924	2023-09-22 12:16:11.193473+00	752	Arkadiusz Majoch	1	[{"added": {}}]	3	4
925	2023-09-22 12:16:23.122321+00	753	Kamil Berniak	1	[{"added": {}}]	3	4
926	2023-09-22 12:16:46.219845+00	754	Łukasz Chmielowski	1	[{"added": {}}]	3	4
927	2023-09-22 12:16:57.351462+00	755	Mateusz Płachta	1	[{"added": {}}]	3	4
928	2023-09-22 12:17:07.395847+00	756	Filip Jeżak	1	[{"added": {}}]	3	4
929	2023-09-22 12:17:19.043375+00	757	Patryk Chmolowski	1	[{"added": {}}]	3	4
930	2023-09-22 12:18:12.639186+00	754	Łukasz Chmielowski	3		3	4
931	2023-09-22 12:38:07.010597+00	758	Michał Chmiel	1	[{"added": {}}]	3	4
932	2023-09-22 12:40:31.349446+00	759	Piotr Piszczek	1	[{"added": {}}]	3	4
933	2023-09-22 12:56:41.073665+00	760	Michał Szarlej	1	[{"added": {}}]	3	4
934	2023-09-22 12:56:55.586392+00	761	Mateusz Nowak	1	[{"added": {}}]	3	4
935	2023-09-22 12:57:08.43212+00	762	Krzysztof Woźniak	1	[{"added": {}}]	3	4
936	2023-09-22 12:57:21.601847+00	763	Bartosz Soja	1	[{"added": {}}]	3	4
937	2023-09-22 12:57:35.406817+00	764	Oliwier Świątek	1	[{"added": {}}]	3	4
938	2023-09-22 12:57:46.441321+00	765	Filip Tekiela	1	[{"added": {}}]	3	4
939	2023-09-22 12:58:03.825396+00	766	Filip Żak	1	[{"added": {}}]	3	4
940	2023-09-22 12:58:18.076128+00	767	Karol Kuraś	1	[{"added": {}}]	3	4
941	2023-09-22 12:58:36.193435+00	768	Karol Walkowiak	1	[{"added": {}}]	3	4
942	2023-09-22 12:58:51.748314+00	769	Szymon Gałan	1	[{"added": {}}]	3	4
943	2023-09-22 12:59:07.668336+00	770	Sebastian Wójcik	1	[{"added": {}}]	3	4
944	2023-09-22 12:59:23.030876+00	771	Grzegorz Gracz	1	[{"added": {}}]	3	4
945	2023-09-22 12:59:37.684637+00	772	Tomasz Mączyński	1	[{"added": {}}]	3	4
946	2023-09-22 12:59:59.032674+00	773	Dawid Źródlewski	1	[{"added": {}}]	3	4
947	2023-09-22 13:00:14.81455+00	774	Sebastian Rozkrut	1	[{"added": {}}]	3	4
948	2023-09-22 13:00:33.319056+00	775	Sławomir Rozkrut	1	[{"added": {}}]	3	4
949	2023-09-22 13:00:50.636862+00	776	Damian Przygoński	1	[{"added": {}}]	3	4
950	2023-09-22 13:01:06.903643+00	777	Jakub Cichy	1	[{"added": {}}]	3	4
951	2023-09-22 13:01:30.724286+00	778	Norbert Kawa	1	[{"added": {}}]	3	4
952	2023-09-22 14:54:39.951241+00	61	Participation object (61)	3		14	1
953	2023-09-22 14:54:39.981257+00	60	Participation object (60)	3		14	1
954	2023-09-22 14:54:40.00847+00	59	Participation object (59)	3		14	1
955	2023-09-22 14:54:40.035737+00	58	Participation object (58)	3		14	1
956	2023-09-22 14:54:40.069749+00	57	Participation object (57)	3		14	1
957	2023-09-22 14:54:40.097865+00	56	Participation object (56)	3		14	1
958	2023-09-22 14:54:40.125207+00	55	Participation object (55)	3		14	1
959	2023-09-22 14:54:40.152765+00	54	Participation object (54)	3		14	1
960	2023-09-22 14:54:40.1801+00	53	Participation object (53)	3		14	1
961	2023-09-22 14:54:48.843539+00	59	The Gunners Nowa Huta vs KS Kondycja	3		4	1
962	2023-09-22 14:54:48.87289+00	58	IKS Łucznik Kraków 2 vs Perła Sport	3		4	1
963	2023-09-22 16:16:04.423978+00	60	The Gunners Nowa Huta vs FC Promil Kraków	3		4	1
964	2023-09-22 16:16:26.360986+00	760	Michał Szarlej	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	1
965	2023-09-22 16:42:23.20756+00	8	The Gunners Nowa Huta	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	1
966	2023-09-22 16:42:46.132316+00	17	FC Promil Kraków	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	1
967	2023-09-22 16:49:13.716382+00	4	miniligastaff	2	[{"changed": {"fields": ["Superuser status"]}}]	8	1
968	2023-09-22 16:49:19.34978+00	4	miniligastaff	2	[{"changed": {"fields": ["User permissions"]}}]	8	1
969	2023-09-22 16:58:51.94777+00	62	OIOM vs FC Szpytu	2	[{"changed": {"fields": ["Matchdate"]}}]	4	1
970	2023-09-22 17:23:54.718348+00	62	OIOM vs FC Szpytu	3		4	1
971	2023-09-22 17:25:00.613239+00	68	OIOM	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	1
972	2023-09-22 17:25:07.936298+00	62	FC Szpytu	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	1
973	2023-09-22 17:26:16.678957+00	64	OIOM vs FC Szpytu	1	[{"added": {}}]	4	1
974	2023-09-22 17:26:47.612888+00	68	OIOM	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost", "Matches"]}}]	2	1
975	2023-09-22 17:27:00.26471+00	62	FC Szpytu	2	[{"changed": {"fields": ["GoalsScored", "GoalsLost", "Matches"]}}]	2	1
976	2023-09-22 17:32:27.80986+00	43	FC Kalecy	2	[{"changed": {"fields": ["GoalsScored", "GoalsLost", "Matches"]}}]	2	1
977	2023-09-22 17:32:40.790103+00	38	Pogoń Kraków	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost", "Matches"]}}]	2	1
978	2023-09-22 17:32:54.995648+00	65	Pogoń Kraków vs FC Kalecy	3		4	1
979	2023-09-25 05:50:27.130932+00	779	Remigiusz Mikosinski	1	[{"added": {}}]	3	1
980	2023-09-25 09:19:28.424603+00	780	Filip Więckowski	1	[{"added": {}}]	3	4
981	2023-09-25 09:19:46.824808+00	781	Tomasz Więckowski	1	[{"added": {}}]	3	4
982	2023-09-25 09:20:07.795494+00	782	Paweł Węgrzyn	1	[{"added": {}}]	3	4
983	2023-09-25 09:20:24.270415+00	783	Tomasz Janik	1	[{"added": {}}]	3	4
984	2023-09-25 09:20:40.175077+00	784	Janusz Janik	1	[{"added": {}}]	3	4
985	2023-09-25 09:21:01.367871+00	785	Jakub Janik	1	[{"added": {}}]	3	4
986	2023-09-25 09:21:17.590108+00	786	Maciek Ulh	1	[{"added": {}}]	3	4
987	2023-09-25 09:21:33.292718+00	787	Jakub Sederowski	1	[{"added": {}}]	3	4
988	2023-09-25 09:21:52.106976+00	788	Artur Ślusarczyk	1	[{"added": {}}]	3	4
989	2023-09-25 09:22:05.542686+00	789	Szymon Wirtel	1	[{"added": {}}]	3	4
990	2023-09-25 09:22:19.363234+00	790	Paweł Kmieć	1	[{"added": {}}]	3	4
991	2023-09-25 09:22:39.293948+00	791	Grzegorz Kowalczyk	1	[{"added": {}}]	3	4
992	2023-09-25 09:25:55.636649+00	792	Batsuren Batsuren	1	[{"added": {}}]	3	4
993	2023-09-25 09:27:05.788666+00	793	Michał Bryg	1	[{"added": {}}]	3	4
994	2023-09-25 09:27:28.574934+00	794	Maciej Gazeł	1	[{"added": {}}]	3	4
995	2023-09-25 09:28:20.528967+00	795	Nikodem Surmacz	1	[{"added": {}}]	3	4
996	2023-09-25 09:29:15.72018+00	796	Michał Balak	1	[{"added": {}}]	3	4
997	2023-09-25 09:29:39.216283+00	797	Maciek Korban	1	[{"added": {}}]	3	4
998	2023-09-25 09:31:12.714963+00	798	Jakub Kowal	1	[{"added": {}}]	3	4
999	2023-09-25 09:31:26.667775+00	799	Kamil Solecki	1	[{"added": {}}]	3	4
1000	2023-09-25 09:31:44.346328+00	800	Łukasz Arłamowski	1	[{"added": {}}]	3	4
1001	2023-09-25 09:31:57.546989+00	801	Filip Gurdek	1	[{"added": {}}]	3	4
1002	2023-09-25 09:32:14.132244+00	802	Kuba Oś	1	[{"added": {}}]	3	4
1003	2023-09-25 09:32:28.002077+00	803	Maciek Sluja	1	[{"added": {}}]	3	4
1004	2023-09-25 09:32:45.531105+00	804	Mikołaj Borczuch	1	[{"added": {}}]	3	4
1005	2023-09-25 09:32:58.658905+00	805	Paweł Paszcza	1	[{"added": {}}]	3	4
1006	2023-09-25 09:33:14.536774+00	806	Szymon Celejewski	1	[{"added": {}}]	3	4
1007	2023-09-25 09:33:33.22431+00	807	Dominik Moryc	1	[{"added": {}}]	3	4
1008	2023-09-25 09:33:49.4449+00	808	Dawid Giza	1	[{"added": {}}]	3	4
1009	2023-09-25 09:34:05.143078+00	809	Aleks Czulak	1	[{"added": {}}]	3	4
1010	2023-09-25 09:34:18.176238+00	810	Karol Chmura	1	[{"added": {}}]	3	4
1011	2023-09-25 09:38:03.146924+00	811	Michał Skwara	1	[{"added": {}}]	3	4
1012	2023-09-25 09:38:19.836222+00	812	Kacper Jaworski	1	[{"added": {}}]	3	4
1013	2023-09-25 09:38:48.141049+00	813	Michał Szefer	1	[{"added": {}}]	3	4
1014	2023-09-25 09:39:05.461677+00	814	Mateusz Wojkowski	1	[{"added": {}}]	3	4
1015	2023-09-25 09:39:26.562968+00	815	Jakub Młynarczyk	1	[{"added": {}}]	3	4
1016	2023-09-25 09:39:43.82451+00	816	Filip Cieślik	1	[{"added": {}}]	3	4
1017	2023-09-25 09:39:59.531366+00	817	Kamil Hamowski	1	[{"added": {}}]	3	4
1018	2023-09-25 09:40:18.87566+00	818	Kazik Rymut	1	[{"added": {}}]	3	4
1019	2023-09-25 09:40:52.534816+00	819	Kamil Janowski	1	[{"added": {}}]	3	4
1020	2023-09-25 09:41:12.320502+00	820	Dawid Laskowski	1	[{"added": {}}]	3	4
1021	2023-09-25 09:42:34.134797+00	821	Jan Piekar	1	[{"added": {}}]	3	4
1022	2023-09-25 09:42:47.881922+00	822	Mikołaj Mrówka	1	[{"added": {}}]	3	4
1023	2023-09-25 09:43:02.418844+00	823	Gustaw Bąbel	1	[{"added": {}}]	3	4
1024	2023-09-25 09:43:17.085404+00	824	Benek Kalisz	1	[{"added": {}}]	3	4
1025	2023-09-25 09:43:31.316253+00	825	Filip Szymus	1	[{"added": {}}]	3	4
1026	2023-09-25 09:43:47.981749+00	826	Szymon Hulanicki	1	[{"added": {}}]	3	4
1027	2023-09-25 09:44:02.832086+00	827	Jan Szkaradek	1	[{"added": {}}]	3	4
1028	2023-09-25 09:44:18.647436+00	828	Kuba Berkowicz	1	[{"added": {}}]	3	4
1029	2023-09-25 09:44:32.440412+00	829	Aleksander Kabalak	1	[{"added": {}}]	3	4
1030	2023-09-25 09:45:09.64004+00	830	Antoni Garbacz	1	[{"added": {}}]	3	4
1031	2023-09-25 09:45:26.077405+00	831	Filip Goczał	1	[{"added": {}}]	3	4
1032	2023-09-25 09:45:38.340319+00	832	Filip Kałuża	1	[{"added": {}}]	3	4
1033	2023-09-25 09:45:57.873793+00	833	Franek Czeczot	1	[{"added": {}}]	3	4
1034	2023-09-25 09:46:36.296036+00	834	Igor Tetłak	1	[{"added": {}}]	3	4
1035	2023-09-25 09:46:53.618973+00	835	Illia Kabanov	1	[{"added": {}}]	3	4
1036	2023-09-25 09:47:09.265659+00	836	Joachim Matuszczak	1	[{"added": {}}]	3	4
1037	2023-09-25 09:47:28.184434+00	837	Kajetan Kułakowski	1	[{"added": {}}]	3	4
1038	2023-09-25 09:47:53.621623+00	838	Marcel Zając	1	[{"added": {}}]	3	4
1039	2023-09-25 09:48:28.32409+00	839	Marek Solarz	1	[{"added": {}}]	3	4
1040	2023-09-25 09:48:59.681132+00	840	Mateusz Dańko	1	[{"added": {}}]	3	4
1041	2023-09-25 09:49:13.428568+00	841	Mateusz Nalepka	1	[{"added": {}}]	3	4
1042	2023-09-25 09:49:29.179685+00	842	Mattia Marzocchi	1	[{"added": {}}]	3	4
1043	2023-09-25 09:49:48.211006+00	843	Miłosz Kłonica	1	[{"added": {}}]	3	4
1044	2023-09-25 09:50:04.344519+00	844	Piotr Wojciechowski	1	[{"added": {}}]	3	4
1045	2023-09-25 09:50:22.174976+00	845	Radek Malicki	1	[{"added": {}}]	3	4
1046	2023-09-25 09:50:39.416032+00	846	Roman Kolompar	1	[{"added": {}}]	3	4
1047	2023-09-25 09:50:56.534929+00	847	Sebastian Lipiarz	1	[{"added": {}}]	3	4
1048	2023-09-25 09:51:34.350805+00	848	Szymon Forystek	1	[{"added": {}}]	3	4
1049	2023-09-25 09:51:49.271348+00	849	Tadeusz Kobylański	1	[{"added": {}}]	3	4
1050	2023-09-25 09:52:06.096146+00	850	Tomasz Cieślak	1	[{"added": {}}]	3	4
1051	2023-09-25 09:52:24.074235+00	851	Tytus Kijowski	1	[{"added": {}}]	3	4
1052	2023-09-25 09:53:08.464054+00	852	Wiktor Wiśniewski	1	[{"added": {}}]	3	4
1053	2023-09-25 09:53:25.856706+00	853	Wojciech Wiącek	1	[{"added": {}}]	3	4
1054	2023-09-25 09:54:37.495169+00	854	Tomasz Woźnica	1	[{"added": {}}]	3	4
1055	2023-09-25 09:55:04.568501+00	855	Jakub Gałuszka	1	[{"added": {}}]	3	4
1056	2023-09-25 15:16:06.357873+00	6	Czolgista	1	[{"added": {}}]	8	4
1057	2023-09-25 15:16:51.266171+00	6	Czolgista	2	[{"changed": {"fields": ["Superuser status", "User permissions"]}}]	8	4
1058	2023-09-25 15:22:30.799314+00	6	Czolgista	3		8	4
1059	2023-09-25 15:54:24.656251+00	70	RB Karpiów	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost"]}}]	2	4
1060	2023-09-25 15:55:04.25796+00	57	Grzenkowianka Ego Topy	2	[{"changed": {"fields": ["Points"]}}]	2	4
1061	2023-09-25 15:55:26.027738+00	61	FC Curra Kieciurra	2	[{"changed": {"fields": ["Points"]}}]	2	4
1062	2023-09-25 16:18:56.907324+00	701	Jakub Musiał	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1063	2023-09-25 16:19:53.113528+00	708	Wojtek Wielgus	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1064	2023-09-25 16:20:08.496389+00	703	Jerzy Skwarło	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1065	2023-09-25 16:20:56.646819+00	700	Bartłomiej Gruca	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints", "Matches"]}}]	3	4
1066	2023-09-25 16:25:51.838679+00	660	Marcin Kłęczek	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1067	2023-09-25 16:28:37.904253+00	656	Dominik Bant	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1068	2023-09-25 16:28:55.858118+00	666	Szymon Synowiec	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1069	2023-09-25 16:30:06.838462+00	854	Tomasz Woźnica	2	[{"changed": {"fields": ["MvpPoints", "Matches"]}}]	3	4
1070	2023-09-25 16:32:29.625446+00	655	Adam Kuśmider	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	4
1071	2023-09-25 16:38:31.082249+00	69	Lużne Grajki	2	[{"changed": {"fields": ["GoalsScored", "GoalsLost"]}}]	2	4
1072	2023-09-25 16:38:52.998366+00	68	OIOM	2	[{"changed": {"fields": ["GoalsScored", "GoalsLost"]}}]	2	4
1073	2023-09-25 18:10:40.67601+00	856	FC Szpytu | Bartosz Noga	1	[{"added": {}}]	3	4
1074	2023-09-25 18:11:06.022698+00	857	FC Szpytu | Patryk Daniec	1	[{"added": {}}]	3	4
1075	2023-09-25 18:56:54.326083+00	467	Biuro Ochrony Stonoga | Adam Nowak	3		3	1
1076	2023-09-25 18:57:41.496157+00	858	Lużne Grajki | Bartek Wideł	1	[{"added": {}}]	3	1
1077	2023-09-25 18:58:11.028144+00	859	Lużne Grajki | Tomasz Mucha	1	[{"added": {}}]	3	1
1078	2023-09-25 18:58:29.308476+00	860	Lużne Grajki | Kamil Mitka	1	[{"added": {}}]	3	1
1079	2023-09-25 18:59:23.838076+00	69	Luźne Grajki	2	[{"changed": {"fields": ["Name"]}}]	2	1
1080	2023-09-25 18:59:41.66712+00	72	Alimenciarze FC	2	[{"changed": {"fields": ["Name"]}}]	2	1
1081	2023-09-25 19:01:06.613714+00	503	FC Agenci | Oliwier Kłyś	2	[{"changed": {"fields": ["Surname"]}}]	3	1
1082	2023-09-25 19:01:31.282538+00	504	FC Agenci | Patryk Galas	2	[{"changed": {"fields": ["Surname"]}}]	3	1
1083	2023-09-25 19:02:07.442619+00	861	FC Agenci | Kuba Burakowski	1	[{"added": {}}]	3	1
1084	2023-09-25 19:36:19.203983+00	82	Alimenciarze FC vs FC Szpytu | 2023-09-20	3		4	4
1085	2023-09-25 19:37:36.822031+00	862	U-Diablo | Piotr Kazimierczak	1	[{"added": {}}]	3	1
1086	2023-09-25 19:38:32.327172+00	863	U-Diablo | Konrad Koptyś	1	[{"added": {}}]	3	1
1087	2023-09-25 19:38:54.259249+00	864	U-Diablo | Andrzej Kończyk	1	[{"added": {}}]	3	1
1088	2023-09-25 19:39:11.684487+00	865	U-Diablo | Michał Wiącek	1	[{"added": {}}]	3	1
1089	2023-09-25 19:39:14.468765+00	62	FC Szpytu	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	4
1090	2023-09-25 19:39:28.59392+00	866	U-Diablo | Kamil Sosenko	1	[{"added": {}}]	3	1
1091	2023-09-25 19:39:44.743293+00	867	U-Diablo | Ivan Milenin	1	[{"added": {}}]	3	1
1092	2023-09-25 19:40:09.559632+00	868	U-Diablo | Micha Kazimierczak	1	[{"added": {}}]	3	1
1093	2023-09-25 19:40:33.501427+00	869	U-Diablo | Łukasz Bardaliński	1	[{"added": {}}]	3	1
1094	2023-09-25 19:43:52.657793+00	870	Laga FC | Karol Wszoła	1	[{"added": {}}]	3	1
1095	2023-09-25 19:44:07.651276+00	871	Laga FC | Oskar Słaby	1	[{"added": {}}]	3	1
1096	2023-09-25 19:46:14.315071+00	85	U-Diablo vs Pogoń Kraków | 2023-09-24	2	[{"changed": {"fields": ["Team1score", "Team2score"]}}]	4	1
1097	2023-09-25 19:47:16.216178+00	85	U-Diablo vs Pogoń Kraków | 2023-09-24	2	[]	4	1
1098	2023-09-25 19:48:45.427482+00	85	U-Diablo vs Pogoń Kraków | 2023-09-24	3		4	1
1099	2023-09-25 19:55:47.611721+00	80	IKS Łucznik Kraków 2 vs MKS Mistrzejowice | 2023-09-17	2	[{"changed": {"fields": ["Team1score", "Team2score"]}}]	4	1
1100	2023-09-25 19:56:19.152225+00	63	IKS Łucznik Kraków 2	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost"]}}]	2	1
1101	2023-09-25 19:57:04.348715+00	59	MKS Mistrzejowice	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost"]}}]	2	1
1102	2023-09-25 19:59:04.852072+00	37	U-Diablo	2	[{"changed": {"fields": ["Points"]}}]	2	1
1103	2023-09-25 19:59:19.968593+00	37	U-Diablo	2	[{"changed": {"fields": ["Matches"]}}]	2	1
1104	2023-09-25 19:59:54.352376+00	38	Pogoń Kraków	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	1
1105	2023-09-25 20:01:40.063358+00	360	U-Diablo | Staszek Boczarski	2	[{"changed": {"fields": ["MvpPoints", "GoalsScored", "Matches"]}}]	3	1
1106	2023-09-25 20:02:06.431731+00	351	U-Diablo | Igor Stadnicki	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	1
1107	2023-09-25 20:02:25.236845+00	362	U-Diablo | Karol Sapiński	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	1
1108	2023-09-25 20:02:58.70827+00	361	U-Diablo | Jakub Prostak	2	[{"changed": {"fields": ["MvpPoints", "Matches"]}}]	3	1
1109	2023-09-25 20:03:17.432987+00	350	U-Diablo | Igor Gajda	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	1
1110	2023-09-25 20:04:05.968165+00	180	Pogoń Kraków | Alexander Tatulchankau	2	[{"changed": {"fields": ["MvpPoints", "GoalsScored", "Matches"]}}]	3	1
1111	2023-09-25 20:04:30.830692+00	177	Pogoń Kraków | Aliaksei Shydlouski	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	1
1112	2023-09-25 20:05:39.015728+00	171	Pogoń Kraków | Dmitrij Malczik	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	1
1113	2023-09-26 11:01:58.945296+00	715	FC Szpytu | Maciej Miśkiewicz	2	[{"changed": {"fields": ["MvpPoints", "GoalsScored", "Matches"]}}]	3	4
1114	2023-09-26 11:02:55.726158+00	714	FC Szpytu | Przemysław Sikora	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1115	2023-09-26 11:03:22.948147+00	856	FC Szpytu | Bartosz Noga	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1116	2023-09-26 11:06:13.12948+00	722	FC Szpytu | Borys Soliński	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints", "Matches"]}}]	3	4
1117	2023-09-26 11:12:03.531297+00	695	Alimenciarze FC | Oliwier Jarosz	2	[{"changed": {"fields": ["MvpPoints", "GoalsScored", "Matches"]}}]	3	4
1118	2023-09-26 11:12:26.137762+00	688	Alimenciarze FC | Kamil Cygan	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1119	2023-09-26 11:12:55.725247+00	722	FC Szpytu | Borys Soliński	2	[]	3	4
1120	2023-09-26 11:13:10.044071+00	722	FC Szpytu | Borys Soliński	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1121	2023-09-26 11:14:11.428683+00	685	Alimenciarze FC | Maciej Maź	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1122	2023-09-26 11:14:30.449505+00	692	Alimenciarze FC | Sebastian Saładyga	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1123	2023-09-26 11:14:56.170307+00	695	Alimenciarze FC | Oliwier Jarosz	2	[]	3	4
1124	2023-09-26 11:15:15.94168+00	698	Alimenciarze FC | Jan Kuc	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	4
1125	2023-09-27 09:08:24.520673+00	742	RB Karpiów | Patryk Hajduk	2	[{"changed": {"fields": ["MvpPoints", "GoalsScored", "Matches"]}}]	3	4
1126	2023-09-27 09:10:05.079836+00	741	RB Karpiów | Michał Wyżga	2	[]	3	4
1127	2023-09-27 09:23:46.67657+00	741	RB Karpiów | Michał Wyżga	2	[]	3	4
1128	2023-09-29 08:59:57.079898+00	872	Sneak Peak | Jakub Ptak	1	[{"added": {}}]	3	1
1129	2023-09-29 09:00:39.786242+00	873	Galacticos Kraków 2023 | Micha Olech	1	[{"added": {}}]	3	1
1130	2023-09-29 09:00:58.58361+00	874	Galacticos Kraków 2023 | Igor Jasiówka	1	[{"added": {}}]	3	1
1131	2023-09-29 09:01:20.534905+00	875	Galacticos Kraków 2023 | Galacticos Kraków 2023 Bartosz	1	[{"added": {}}]	3	1
1132	2023-09-29 09:13:19.943163+00	876	FC Agenci | Korneliusz Bem	1	[{"added": {}}]	3	1
1133	2023-09-29 09:24:40.688828+00	877	FootCanser | Marcin Jania	1	[{"added": {}}]	3	1
1134	2023-09-29 09:24:53.716891+00	878	FootCanser | Ignacy Gawron	1	[{"added": {}}]	3	1
1135	2023-09-29 09:25:06.476865+00	879	FootCanser | Jan Mróz	1	[{"added": {}}]	3	1
1136	2023-09-29 09:25:22.855387+00	880	FootCanser | Szymon Jastrzębski	1	[{"added": {}}]	3	1
1137	2023-09-29 09:25:36.961672+00	881	FootCanser | Jakub Bębenek	1	[{"added": {}}]	3	1
1138	2023-09-29 09:25:59.266197+00	882	FootCanser | Kacper Wygaś	1	[{"added": {}}]	3	1
1139	2023-09-29 09:26:12.607398+00	883	FootCanser | Michał Mróz	1	[{"added": {}}]	3	1
1140	2023-09-29 09:26:25.811043+00	884	FootCanser | Kamil Kulma	1	[{"added": {}}]	3	1
1141	2023-09-29 09:26:44.479555+00	885	FootCanser | Bartosz Soja	1	[{"added": {}}]	3	1
1142	2023-09-29 09:27:13.619844+00	886	FootCanser | Aleksander Janik	1	[{"added": {}}]	3	1
1143	2023-09-29 09:27:27.175219+00	887	FootCanser | Krzysztof Pulak	1	[{"added": {}}]	3	1
1144	2023-09-29 09:33:01.938052+00	888	Rosso Negri FC | Arkadiusz Kudzia	1	[{"added": {}}]	3	1
1145	2023-09-29 09:33:17.151894+00	889	Rosso Negri FC | Daniel Wiącek	1	[{"added": {}}]	3	1
1146	2023-09-29 09:33:33.125378+00	890	Rosso Negri FC | Kuba Jasiński	1	[{"added": {}}]	3	1
1147	2023-09-29 09:33:52.534115+00	891	Rosso Negri FC | Łukasz Paciorek	1	[{"added": {}}]	3	1
1148	2023-09-29 09:34:08.019255+00	892	Rosso Negri FC | Marcin Pabian	1	[{"added": {}}]	3	1
1149	2023-09-29 09:34:23.925177+00	893	Rosso Negri FC | Kuba Pietrawas	1	[{"added": {}}]	3	1
1150	2023-09-29 09:34:39.492573+00	894	Rosso Negri FC | Mateusz Pabian	1	[{"added": {}}]	3	1
1151	2023-09-29 09:35:07.349299+00	895	Rosso Negri FC | Mariusz Mosur	1	[{"added": {}}]	3	1
1152	2023-09-29 09:35:24.46372+00	896	Rosso Negri FC | Dominika Mosur	1	[{"added": {}}]	3	1
1153	2023-09-29 09:35:40.279574+00	897	Rosso Negri FC | Nikodem Capek	1	[{"added": {}}]	3	1
1154	2023-09-29 09:35:54.045019+00	898	Rosso Negri FC | Radek Piotrowski	1	[{"added": {}}]	3	1
1155	2023-09-29 09:36:04.044871+00	899	Rosso Negri FC | Eryk Jurek	1	[{"added": {}}]	3	1
1156	2023-09-29 09:36:22.531541+00	900	Rosso Negri FC | Mariusz Orczewski	1	[{"added": {}}]	3	1
1157	2023-09-29 09:37:34.363669+00	901	Sportowcy Nałogowcy | Sebastian Piskorz	1	[{"added": {}}]	3	1
1158	2023-09-29 09:37:50.331481+00	902	Sportowcy Nałogowcy | Ivan Gnatyszen	1	[{"added": {}}]	3	1
1159	2023-09-29 09:38:02.619211+00	903	Sportowcy Nałogowcy | Olaf Pomykalski	1	[{"added": {}}]	3	1
1160	2023-09-29 09:38:15.246046+00	904	Sportowcy Nałogowcy | Szymon Szostak	1	[{"added": {}}]	3	1
1161	2023-09-29 09:38:34.344371+00	905	Sportowcy Nałogowcy | Mateusz Waremczuk	1	[{"added": {}}]	3	1
1162	2023-09-29 09:38:46.643047+00	906	Sportowcy Nałogowcy | Jakub Bartuś	1	[{"added": {}}]	3	1
1163	2023-09-29 09:39:14.458138+00	907	Sportowcy Nałogowcy | Dominik Iniarski	1	[{"added": {}}]	3	1
1164	2023-09-29 09:39:31.396105+00	908	Sportowcy Nałogowcy | Adam Pieniądz	1	[{"added": {}}]	3	1
1165	2023-09-29 09:39:44.982595+00	909	Sportowcy Nałogowcy | Jakub Puto	1	[{"added": {}}]	3	1
1166	2023-09-29 09:39:59.281587+00	910	Sportowcy Nałogowcy | Patryk Hajduk	1	[{"added": {}}]	3	1
1167	2023-09-29 09:40:14.906266+00	911	Sportowcy Nałogowcy | Kacper Szostak	1	[{"added": {}}]	3	1
1168	2023-09-29 09:40:28.079746+00	912	Sportowcy Nałogowcy | Daniel Chyc	1	[{"added": {}}]	3	1
1169	2023-09-29 09:40:46.113787+00	913	Sportowcy Nałogowcy | Filip Gwiźdż	1	[{"added": {}}]	3	1
1170	2023-09-29 09:41:09.988791+00	914	Sportowcy Nałogowcy | Wiktor Rosiński	1	[{"added": {}}]	3	1
1171	2023-09-29 09:41:24.631583+00	915	Sportowcy Nałogowcy | Jakub Piekarski	1	[{"added": {}}]	3	1
1172	2023-09-29 09:41:40.714879+00	916	Sportowcy Nałogowcy | Michał Proć	1	[{"added": {}}]	3	1
1173	2023-09-29 09:42:07.710637+00	917	Sportowcy Nałogowcy | Patryk Toczek	1	[{"added": {}}]	3	1
1174	2023-09-29 09:42:26.000323+00	918	Sportowcy Nałogowcy | Maciek Makulski	1	[{"added": {}}]	3	1
1175	2023-09-29 09:43:11.548316+00	919	Deeks United | Grzegorz Szafraniec	1	[{"added": {}}]	3	1
1176	2023-09-29 09:43:30.533056+00	920	Deeks United | Patryk Bąk	1	[{"added": {}}]	3	1
1177	2023-09-29 09:43:50.088956+00	921	Deeks United | Dominik Tomaszewski	1	[{"added": {}}]	3	1
1178	2023-09-29 09:44:03.643512+00	922	Deeks United | Mateusz Wrona	1	[{"added": {}}]	3	1
1179	2023-09-29 09:44:28.759341+00	923	Deeks United | Szymon Bończyk	1	[{"added": {}}]	3	1
1180	2023-09-29 09:44:46.041219+00	924	Deeks United | Konrad Strzałka	1	[{"added": {}}]	3	1
1181	2023-09-29 09:45:02.938963+00	925	Deeks United | Szymon Powałka	1	[{"added": {}}]	3	1
1182	2023-09-29 09:45:20.138495+00	926	Deeks United | Piotr Powałka	1	[{"added": {}}]	3	1
1183	2023-09-29 09:45:38.981071+00	927	Deeks United | Maks Sosin	1	[{"added": {}}]	3	1
1184	2023-09-29 09:45:59.064933+00	928	Deeks United | Bartek Siembak	1	[{"added": {}}]	3	1
1185	2023-09-29 09:46:19.084193+00	929	Deeks United | Jakub Dyl	1	[{"added": {}}]	3	1
1186	2023-09-29 09:46:37.351746+00	930	Deeks United | Paweł Dużyk	1	[{"added": {}}]	3	1
1187	2023-09-29 09:46:52.622333+00	931	Deeks United | Mateusz Łabuś	1	[{"added": {}}]	3	1
1188	2023-09-29 09:47:05.766707+00	932	Deeks United | Filip Hołuj	1	[{"added": {}}]	3	1
1189	2023-09-29 09:48:17.269423+00	933	Strassenbande | Adrian Grabowski	1	[{"added": {}}]	3	1
1190	2023-09-29 09:48:36.269271+00	934	Strassenbande | Antek Pisarczyk	1	[{"added": {}}]	3	1
1191	2023-09-29 09:48:51.442637+00	935	Strassenbande | Bartek Bogusz	1	[{"added": {}}]	3	1
1192	2023-09-29 09:49:31.366471+00	936	Strassenbande | Bartek Żakieta	1	[{"added": {}}]	3	1
1193	2023-09-29 09:49:45.937779+00	937	Strassenbande | Bartłomiej Broś	1	[{"added": {}}]	3	1
1194	2023-09-29 09:49:59.422612+00	938	Strassenbande | Daniel Pituch	1	[{"added": {}}]	3	1
1195	2023-09-29 09:50:16.117045+00	939	Strassenbande | Igor Chlebowski	1	[{"added": {}}]	3	1
1196	2023-09-29 09:50:29.034269+00	940	Strassenbande | Jacek Waligóra	1	[{"added": {}}]	3	1
1197	2023-09-29 09:50:43.725971+00	941	Strassenbande | Kacper Mochal	1	[{"added": {}}]	3	1
1198	2023-09-29 09:50:59.524295+00	942	Strassenbande | Kacper Pituch	1	[{"added": {}}]	3	1
1199	2023-09-29 09:51:12.819593+00	943	Strassenbande | Kamil Kozak	1	[{"added": {}}]	3	1
1200	2023-09-29 09:51:34.641957+00	944	Strassenbande | Krzysiek Wieciołkowski	1	[{"added": {}}]	3	1
1201	2023-09-29 09:51:52.714466+00	945	Strassenbande | Maciej Salasa	1	[{"added": {}}]	3	1
1202	2023-09-29 09:52:09.365871+00	946	Strassenbande | Mateusz Kawa	1	[{"added": {}}]	3	1
1203	2023-09-29 09:52:30.310536+00	947	Strassenbande | Oskar Bulczyński	1	[{"added": {}}]	3	1
1204	2023-09-29 09:52:46.018796+00	948	Strassenbande | Patryk Gajda	1	[{"added": {}}]	3	1
1205	2023-09-29 09:53:02.819435+00	949	Strassenbande | Patryk Kawa	1	[{"added": {}}]	3	1
1206	2023-09-29 09:53:23.897278+00	950	Strassenbande | Szymon Chowaniec	1	[{"added": {}}]	3	1
1207	2023-09-29 09:53:42.825167+00	951	Strassenbande | Szymon Pelson	1	[{"added": {}}]	3	1
1208	2023-09-29 09:53:57.974211+00	952	Strassenbande | Tomek Stala	1	[{"added": {}}]	3	1
1209	2023-09-29 09:54:13.646958+00	953	Strassenbande | Vova Suchowski	1	[{"added": {}}]	3	1
1210	2023-09-29 09:55:12.499822+00	954	Orzeł BTS | Mateusz Pulnik	1	[{"added": {}}]	3	1
1211	2023-09-29 09:55:26.930945+00	955	Orzeł BTS | Sebastian Twardy	1	[{"added": {}}]	3	1
1212	2023-09-29 09:55:50.660994+00	956	Orzeł BTS | Krzysztof Tondera	1	[{"added": {}}]	3	1
1213	2023-09-29 09:56:09.944513+00	957	Orzeł BTS | Michał Głowacki	1	[{"added": {}}]	3	1
1214	2023-09-29 09:56:27.545818+00	958	Orzeł BTS | Bartek Janicki	1	[{"added": {}}]	3	1
1215	2023-09-29 10:05:45.845465+00	959	Orzeł BTS | Piotrek Rajnert	1	[{"added": {}}]	3	1
1216	2023-09-29 10:06:00.923286+00	960	Orzeł BTS | Mateusz Klimek	1	[{"added": {}}]	3	1
1217	2023-09-29 10:06:15.802481+00	961	Orzeł BTS | Jan Pieczarkowski	1	[{"added": {}}]	3	1
1218	2023-09-29 10:06:34.778578+00	962	Orzeł BTS | Filip Czekaj	1	[{"added": {}}]	3	1
1219	2023-09-29 10:06:54.728015+00	963	Orzeł BTS | Mateusz Frenc	1	[{"added": {}}]	3	1
1220	2023-09-29 10:07:08.967714+00	964	Orzeł BTS | Daniel Kowalski	1	[{"added": {}}]	3	1
1221	2023-09-29 10:07:32.925866+00	965	Orzeł BTS | Wojtek Dudzińśki	1	[{"added": {}}]	3	1
1222	2023-09-29 10:07:51.220741+00	966	Orzeł BTS | Tadeusz Pieczarkowski	1	[{"added": {}}]	3	1
1223	2023-09-29 10:08:05.886433+00	967	Orzeł BTS | Szymon Hajduk	1	[{"added": {}}]	3	1
1224	2023-09-29 10:08:26.397142+00	968	Orzeł BTS | Bartłomiej Niedzielski	1	[{"added": {}}]	3	1
1225	2023-09-29 10:08:42.516934+00	969	Orzeł BTS | Artur Pępkowski	1	[{"added": {}}]	3	1
1226	2023-09-29 10:08:57.966369+00	970	Orzeł BTS | Kuba Skoczek	1	[{"added": {}}]	3	1
1227	2023-09-29 10:09:19.324484+00	971	Orzeł BTS | Arkadiusz Pępkowski	1	[{"added": {}}]	3	1
1228	2023-09-29 10:09:47.096602+00	972	Orzeł BTS | Grzegorz Olesiejuk	1	[{"added": {}}]	3	1
1229	2023-09-29 10:10:05.723772+00	973	Orzeł BTS | Rafał Dobosz	1	[{"added": {}}]	3	1
1230	2023-09-29 10:10:26.056625+00	974	Orzeł BTS | Kacper Gajda	1	[{"added": {}}]	3	1
1231	2023-09-29 10:10:53.749453+00	975	Orzeł BTS | Mark Shevchyshyn	1	[{"added": {}}]	3	1
1232	2023-09-29 10:11:20.952368+00	976	Orzeł BTS | Lahoucine Benhera	1	[{"added": {}}]	3	1
1233	2023-09-29 10:11:38.254548+00	977	Orzeł BTS | Wiesław Kulpa	1	[{"added": {}}]	3	1
1234	2023-09-29 10:11:59.025611+00	978	Orzeł BTS | Kiryl Shashura	1	[{"added": {}}]	3	1
1235	2023-09-29 10:12:18.078659+00	979	Orzeł BTS | Jan Bielecki	1	[{"added": {}}]	3	1
1236	2023-09-29 10:12:30.040809+00	980	Orzeł BTS | Sebastian Wójcik	1	[{"added": {}}]	3	1
1237	2023-09-29 10:13:10.439891+00	981	Hellas Ivvona | Piotr Ptak	1	[{"added": {}}]	3	1
1238	2023-09-29 10:13:32.031795+00	982	Hellas Ivvona | Jakub Krzywiński	1	[{"added": {}}]	3	1
1239	2023-09-29 10:13:56.005738+00	983	Hellas Ivvona | Wiktor Chudy	1	[{"added": {}}]	3	1
1240	2023-09-29 10:14:07.68152+00	984	Hellas Ivvona | Michał Mróz	1	[{"added": {}}]	3	1
1241	2023-09-29 10:14:32.089519+00	985	Hellas Ivvona | Olaf Tyrkalski	1	[{"added": {}}]	3	1
1242	2023-09-29 10:14:51.639101+00	986	Hellas Ivvona | Olek Janik	1	[{"added": {}}]	3	1
1243	2023-09-29 10:15:02.834464+00	987	Hellas Ivvona | Jan Dzierwa	1	[{"added": {}}]	3	1
1244	2023-09-29 10:15:16.046325+00	988	Hellas Ivvona | Bartek Podkowa	1	[{"added": {}}]	3	1
1245	2023-09-29 10:15:29.547157+00	989	Hellas Ivvona | Jakub Najda	1	[{"added": {}}]	3	1
1246	2023-09-29 10:15:48.05707+00	990	Hellas Ivvona | Dawid Kokośiński	1	[{"added": {}}]	3	1
1247	2023-09-29 10:16:02.939498+00	991	Hellas Ivvona | Krzysiek Macek	1	[{"added": {}}]	3	1
1248	2023-09-29 10:16:19.000507+00	992	Hellas Ivvona | Piotr Sobieski	1	[{"added": {}}]	3	1
1249	2023-09-29 10:16:35.67449+00	993	Hellas Ivvona | Roman Biloval	1	[{"added": {}}]	3	1
1250	2023-09-29 10:16:55.837407+00	994	Hellas Ivvona | Adrian Mach	1	[{"added": {}}]	3	1
1251	2023-09-29 10:17:06.986924+00	995	Hellas Ivvona | Dawid Ogarek	1	[{"added": {}}]	3	1
1252	2023-09-29 10:17:20.12775+00	996	Hellas Ivvona | Jan Mróz	1	[{"added": {}}]	3	1
1253	2023-09-29 10:17:36.952273+00	997	Hellas Ivvona | Kuba Tarach	1	[{"added": {}}]	3	1
1254	2023-09-29 10:17:49.836811+00	998	Hellas Ivvona | Maciej Stolarski	1	[{"added": {}}]	3	1
1255	2023-09-29 10:18:03.629449+00	999	Hellas Ivvona | Dawid Gruszkowski	1	[{"added": {}}]	3	1
1256	2023-09-29 10:18:18.700108+00	1000	Hellas Ivvona | Maciek Townsend	1	[{"added": {}}]	3	1
1257	2023-09-30 10:47:06.012052+00	1001	Cracov Elite | Mateusz Mroczka	1	[{"added": {}}]	3	1
1258	2023-09-30 10:47:18.923325+00	1002	Cracov Elite | Tomasz Kłak	1	[{"added": {}}]	3	1
1259	2023-09-30 10:47:33.231302+00	1003	Cracov Elite | Eryk Radwan	1	[{"added": {}}]	3	1
1260	2023-09-30 10:47:49.984462+00	1004	Cracov Elite | Eliasz Mirosław	1	[{"added": {}}]	3	1
1261	2023-09-30 10:48:04.030694+00	1005	Cracov Elite | Jan Janik	1	[{"added": {}}]	3	1
1262	2023-09-30 10:48:17.503969+00	1006	Cracov Elite | Filip Janik	1	[{"added": {}}]	3	1
1263	2023-09-30 10:48:30.817985+00	1007	Cracov Elite | Filip Skowron	1	[{"added": {}}]	3	1
1264	2023-09-30 10:48:53.945216+00	1008	Cracov Elite | Alek Rębacz	1	[{"added": {}}]	3	1
1265	2023-09-30 10:49:08.895695+00	1009	Cracov Elite | Maciej Ryskala	1	[{"added": {}}]	3	1
1266	2023-09-30 10:49:23.633683+00	1010	Cracov Elite | Kuba Król	1	[{"added": {}}]	3	1
1267	2023-09-30 10:49:37.607984+00	1011	Cracov Elite | Antoni Grzyb	1	[{"added": {}}]	3	1
1268	2023-09-30 10:49:51.868199+00	1012	Cracov Elite | Kuba Konopka	1	[{"added": {}}]	3	1
1269	2023-09-30 10:50:11.784254+00	1013	Cracov Elite | Wojtek Ślisz	1	[{"added": {}}]	3	1
1270	2023-09-30 10:50:23.415826+00	1014	Cracov Elite | Wojtek Flis	1	[{"added": {}}]	3	1
1271	2023-09-30 10:50:38.97378+00	1015	Cracov Elite | Łukasz Ślisz	1	[{"added": {}}]	3	1
1272	2023-09-30 10:50:59.473017+00	1016	Cracov Elite | Jan Ślisz	1	[{"added": {}}]	3	1
1273	2023-09-30 10:51:22.522703+00	1017	Cracov Elite | Bartek Ptak	1	[{"added": {}}]	3	1
1274	2023-09-30 10:51:46.664784+00	1018	Cracov Elite | Bartek Cebula	1	[{"added": {}}]	3	1
1275	2023-09-30 10:52:00.612738+00	1019	Cracov Elite | Kamil Dojko	1	[{"added": {}}]	3	1
1276	2023-09-30 10:52:12.90811+00	1020	Cracov Elite | Kacper Kitliński	1	[{"added": {}}]	3	1
1277	2023-09-30 10:52:37.660725+00	1021	Cracov Elite | Mikołaj Purol	1	[{"added": {}}]	3	1
1278	2023-09-30 10:54:13.638635+00	1022	Cracov Elite | Roma Roma	1	[{"added": {}}]	3	1
1279	2023-09-30 10:54:55.814665+00	1023	Cracov Elite | Radek Woźniak	1	[{"added": {}}]	3	1
1280	2023-09-30 10:55:34.644119+00	1024	Cracov Elite | Piotek Pabian	1	[{"added": {}}]	3	1
1281	2023-09-30 10:55:48.149799+00	1025	Cracov Elite | Kuba Krzak	1	[{"added": {}}]	3	1
1282	2023-09-30 10:56:03.725289+00	1026	Cracov Elite | Igor Sobolewski	1	[{"added": {}}]	3	1
1283	2023-09-30 10:56:22.185239+00	1027	Cracov Elite | Oskar Adamczyk	1	[{"added": {}}]	3	1
1284	2023-09-30 10:56:37.058514+00	1028	Cracov Elite | Karol Włodarski	1	[{"added": {}}]	3	1
1285	2023-09-30 10:56:57.633761+00	1029	Cracov Elite | Konrad Zawadzki	1	[{"added": {}}]	3	1
1286	2023-09-30 10:57:12.892938+00	1030	Cracov Elite | Konrad Warzecha	1	[{"added": {}}]	3	1
1287	2023-09-30 10:57:35.206676+00	1031	Cracov Elite | Szymon Sitarz	1	[{"added": {}}]	3	1
1288	2023-09-30 10:57:48.020574+00	1032	Cracov Elite | Łukasz Klocek	1	[{"added": {}}]	3	1
1289	2023-09-30 10:58:03.708449+00	1033	Cracov Elite | Michał Krenich	1	[{"added": {}}]	3	1
1290	2023-09-30 11:05:18.038594+00	1034	RB Karpiów | Maciek Bryg	1	[{"added": {}}]	3	1
1291	2023-09-30 11:06:02.734883+00	1035	Sneak Peak | Robert Zubek	1	[{"added": {}}]	3	1
1292	2023-09-30 11:06:27.973083+00	1036	Sneak Peak | FIlip Bojara	1	[{"added": {}}]	3	1
1293	2023-09-30 11:07:50.040297+00	1037	Galacticos Kraków 2023 | Adrian Kaleta	1	[{"added": {}}]	3	1
1294	2023-09-30 11:08:45.878264+00	1038	IKS Łucznik Kraków 2 | Tomasz Degórski	1	[{"added": {}}]	3	1
1295	2023-10-02 15:33:02.734386+00	923	Deeks United | Szymon Bończyk	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	1
1296	2023-10-02 15:35:50.158531+00	1039	Partyzant Nowa Huta | Maciej Federowicz	1	[{"added": {}}]	3	1
1297	2023-10-02 15:36:11.125766+00	1040	Partyzant Nowa Huta | Kacper Kalinowski	1	[{"added": {}}]	3	1
1298	2023-10-02 15:41:29.661028+00	468	Biuro Ochrony Stonoga | Artur Nowak	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	1
1299	2023-10-02 16:37:33.419866+00	1041	IKS Łucznik Kraków 2 | Matuesz Kądzielewa	1	[{"added": {}}]	3	1
1300	2023-10-02 16:37:56.563882+00	1042	IKS Łucznik Kraków 2 | Jakub Jagielski	1	[{"added": {}}]	3	1
1301	2023-10-02 18:30:53.329931+00	1043	RB Karpiów | Serhi Pylypchuka	1	[{"added": {}}]	3	1
1302	2023-10-02 18:33:01.069862+00	1044	RB Karpiów | Denis Denis	1	[{"added": {}}]	3	1
1303	2023-10-02 18:34:27.01889+00	1045	Najlepsi w Mieście | Jakub Maj	1	[{"added": {}}]	3	1
1304	2023-10-02 18:34:54.648616+00	1046	Najlepsi w Mieście | Grzegorz Rybicki	1	[{"added": {}}]	3	1
1305	2023-10-02 18:35:09.366752+00	1047	Najlepsi w Mieście | Konrad Śmietan	1	[{"added": {}}]	3	1
1306	2023-10-02 18:36:13.335101+00	1048	FF Sao Paulo | Kamil Kus	1	[{"added": {}}]	3	1
1307	2023-10-02 18:36:38.460196+00	1049	Sneak Peak | Maciej Węgrzyn	1	[{"added": {}}]	3	1
1308	2023-10-02 18:36:57.328939+00	1050	Sneak Peak | Hubert Szczepanik	1	[{"added": {}}]	3	1
1309	2023-10-02 18:39:16.809361+00	1051	The Gunners Nowa Huta | Radosław Jarosz	1	[{"added": {}}]	3	1
1310	2023-10-02 18:39:17.844462+00	1052	The Gunners Nowa Huta | Radosław Jarosz	1	[{"added": {}}]	3	1
1311	2023-10-03 15:19:41.821857+00	1053	Huragan Koniowały | Konrad Klita	1	[{"added": {}}]	3	1
1312	2023-10-03 15:20:00.224388+00	1054	Huragan Koniowały | Sebastian Soból	1	[{"added": {}}]	3	1
1313	2023-10-03 15:20:12.527108+00	1055	Huragan Koniowały | Dawid Soból	1	[{"added": {}}]	3	1
1314	2023-10-03 15:20:25.932896+00	1056	Huragan Koniowały | Dawid Kucia	1	[{"added": {}}]	3	1
1315	2023-10-03 15:20:41.381477+00	1057	Huragan Koniowały | Dawid Gdula	1	[{"added": {}}]	3	1
1316	2023-10-03 15:20:58.518801+00	1058	Huragan Koniowały | Łukasz Gdula	1	[{"added": {}}]	3	1
1317	2023-10-03 15:21:09.943232+00	1059	Huragan Koniowały | Radek Michalski	1	[{"added": {}}]	3	1
1318	2023-10-03 15:21:25.625018+00	1060	Huragan Koniowały | Radek Michalski	1	[{"added": {}}]	3	1
1319	2023-10-03 15:21:40.098157+00	1060	Huragan Koniowały | Michał Kromka'	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	1
1320	2023-10-03 15:21:45.642517+00	1060	Huragan Koniowały | Michał Kromka	2	[{"changed": {"fields": ["Surname"]}}]	3	1
1321	2023-10-03 15:21:59.374848+00	1061	Huragan Koniowały | Mateusz Kowalski	1	[{"added": {}}]	3	1
1322	2023-10-03 15:22:11.397206+00	1062	Huragan Koniowały | Szymon Kowalik	1	[{"added": {}}]	3	1
1323	2023-10-03 15:22:23.001533+00	1063	Huragan Koniowały | Szymon Kuć	1	[{"added": {}}]	3	1
1324	2023-10-03 15:22:34.268303+00	1064	Huragan Koniowały | Sebastian Kowalik	1	[{"added": {}}]	3	1
1325	2023-10-03 15:22:53.76824+00	1065	Huragan Koniowały | Wojtek Czyrnek	1	[{"added": {}}]	3	1
1326	2023-10-03 15:23:08.437338+00	1066	Huragan Koniowały | Jakub Stachowski	1	[{"added": {}}]	3	1
1327	2023-10-03 15:23:25.546012+00	1067	Huragan Koniowały | Michał Pustelnik	1	[{"added": {}}]	3	1
1328	2023-10-03 15:23:54.16261+00	1068	Alibaba FC | Antek Jedynak	1	[{"added": {}}]	3	1
1329	2023-10-03 15:24:08.90448+00	1069	Alibaba FC | Bartosz Wiśniowski	1	[{"added": {}}]	3	1
1330	2023-10-03 15:24:34.672418+00	1070	Alibaba FC | Darwin Darwin	1	[{"added": {}}]	3	1
1331	2023-10-03 15:24:55.368477+00	1071	Alibaba FC | Maciek Sylwestrowicz	1	[{"added": {}}]	3	1
1332	2023-10-03 15:25:13.431291+00	1072	Alibaba FC | Maks Satora	1	[{"added": {}}]	3	1
1333	2023-10-03 15:25:35.926704+00	1073	Alibaba FC | Max Holovko	1	[{"added": {}}]	3	1
1515	2023-10-12 09:49:31.4809+00	51	FC Anony	3		2	4
1334	2023-10-03 15:25:56.118591+00	1074	Alibaba FC | Michał Florkiewicz	1	[{"added": {}}]	3	1
1335	2023-10-03 15:26:10.349923+00	1075	Alibaba FC | Patryk Kostaś	1	[{"added": {}}]	3	1
1336	2023-10-03 15:26:23.418891+00	1076	Alibaba FC | Piotr Wysocki	1	[{"added": {}}]	3	1
1337	2023-10-03 15:26:38.940688+00	1077	Alibaba FC | Stachu Kiepura	1	[{"added": {}}]	3	1
1338	2023-10-03 15:26:53.966302+00	1078	Alibaba FC | Wiktor Grabiec	1	[{"added": {}}]	3	1
1339	2023-10-03 15:27:15.430554+00	1079	Alibaba FC | Adam Konieczny	1	[{"added": {}}]	3	1
1340	2023-10-03 15:27:32.197514+00	1080	Alibaba FC | Maciej Adamczyk	1	[{"added": {}}]	3	1
1341	2023-10-03 15:27:47.511337+00	1081	Alibaba FC | Henryk Kochan	1	[{"added": {}}]	3	1
1342	2023-10-03 15:28:04.40382+00	1082	Alibaba FC | Tomek Korzkiewicz	1	[{"added": {}}]	3	1
1343	2023-10-03 15:28:18.434849+00	1083	Alibaba FC | Marcel Odroń	1	[{"added": {}}]	3	1
1344	2023-10-03 15:28:29.635213+00	1084	Alibaba FC | Kuba Stopa	1	[{"added": {}}]	3	1
1345	2023-10-03 15:28:45.14499+00	1085	Alibaba FC | Franciszek Maniak	1	[{"added": {}}]	3	1
1346	2023-10-03 15:28:57.706244+00	1086	Alibaba FC | Maciej Nastałek	1	[{"added": {}}]	3	1
1347	2023-10-03 15:29:11.489492+00	1087	Alibaba FC | Maciek Kosydar	1	[{"added": {}}]	3	1
1348	2023-10-07 10:14:46.378956+00	1088	Iskra Kraków | Grzegorz Latała	1	[{"added": {}}]	3	4
1349	2023-10-07 10:16:45.424859+00	1089	Iskra Kraków | Krzysztof Jaworski	1	[{"added": {}}]	3	4
1350	2023-10-07 10:17:12.534486+00	1090	Iskra Kraków | Daniel Glabian	1	[{"added": {}}]	3	4
1351	2023-10-07 10:17:30.065724+00	1091	Iskra Kraków | Krzysztof Szczurek	1	[{"added": {}}]	3	4
1352	2023-10-07 10:18:57.955921+00	1092	Iskra Kraków | Wojciech Flis	1	[{"added": {}}]	3	4
1353	2023-10-07 10:19:37.314123+00	1093	Iskra Kraków | Jakub Latała	1	[{"added": {}}]	3	4
1354	2023-10-07 10:20:15.617782+00	1094	Iskra Kraków | Bartłomiej Adamczyk	1	[{"added": {}}]	3	4
1355	2023-10-07 10:20:48.784198+00	1094	Iskra Kraków | Bartłomiej Adamski	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1356	2023-10-08 21:10:26.336848+00	1095	TEAM Salvator | Jan Suberlak	1	[{"added": {}}]	3	1
1357	2023-10-08 21:11:17.947916+00	1096	TEAM Salvator | Daniel Poprawa	1	[{"added": {}}]	3	1
1358	2023-10-08 21:11:31.407081+00	1097	TEAM Salvator | Patryk Kuc	1	[{"added": {}}]	3	1
1359	2023-10-08 21:11:48.076045+00	1098	TEAM Salvator | Michał Tatara	1	[{"added": {}}]	3	1
1360	2023-10-08 21:12:02.725374+00	1099	TEAM Salvator | Jakub Tatara	1	[{"added": {}}]	3	1
1361	2023-10-08 21:12:16.653484+00	1100	TEAM Salvator | Mateusz Guzowski	1	[{"added": {}}]	3	1
1362	2023-10-08 21:12:29.393397+00	1101	TEAM Salvator | Jerzy Smalewski	1	[{"added": {}}]	3	1
1363	2023-10-08 21:12:42.256679+00	1102	TEAM Salvator | Mateusz Klimek	1	[{"added": {}}]	3	1
1364	2023-10-08 21:13:00.12703+00	1103	TEAM Salvator | Karol Wilk	1	[{"added": {}}]	3	1
1365	2023-10-08 21:13:16.137707+00	1104	TEAM Salvator | Michał Kordylewski	1	[{"added": {}}]	3	1
1366	2023-10-08 21:13:33.317135+00	1105	TEAM Salvator | Kacper Kawula	1	[{"added": {}}]	3	1
1367	2023-10-08 21:13:45.237227+00	1106	TEAM Salvator | Krzysztof Baran	1	[{"added": {}}]	3	1
1368	2023-10-08 21:13:59.43904+00	1107	TEAM Salvator | Mikołaj Dyga	1	[{"added": {}}]	3	1
1369	2023-10-08 21:14:00.384165+00	1108	TEAM Salvator | Mikołaj Dyga	1	[{"added": {}}]	3	1
1370	2023-10-08 21:14:20.24203+00	1109	TEAM Salvator | Miłosz Ziębacz	1	[{"added": {}}]	3	1
1371	2023-10-08 21:14:37.085615+00	1110	TEAM Salvator | Paweł Jezioro	1	[{"added": {}}]	3	1
1372	2023-10-08 21:15:03.147129+00	1111	TEAM Salvator | Mateusz Skrzeszowski	1	[{"added": {}}]	3	1
1373	2023-10-08 21:15:18.87789+00	1112	TEAM Salvator | Sebastian Saładyga	1	[{"added": {}}]	3	1
1374	2023-10-08 21:28:11.372452+00	1113	TEAM Salvator | Mariusz Skrzyszowski	1	[{"added": {}}]	3	1
1375	2023-10-08 21:28:25.167081+00	1114	TEAM Salvator | Krzysztof Olszewski	1	[{"added": {}}]	3	1
1376	2023-10-09 12:47:59.500517+00	1108	TEAM Salvator | Mikołaj Dyga	3		3	4
1377	2023-10-09 12:57:17.005495+00	1111	TEAM Salvator | Mateusz Skrzeszowski	3		3	4
1378	2023-10-09 12:57:37.944583+00	1115	ELECTROSMART | Paweł Węgrzyn	1	[{"added": {}}]	3	4
1379	2023-10-09 12:57:53.52658+00	1116	ELECTROSMART | Rafał Cepik	1	[{"added": {}}]	3	4
1380	2023-10-09 12:58:08.185955+00	1117	ELECTROSMART | Grzegorz Wojnarowski	1	[{"added": {}}]	3	4
1381	2023-10-09 12:58:19.749201+00	1118	ELECTROSMART | Tomek Bigosiński	1	[{"added": {}}]	3	4
1382	2023-10-09 12:58:32.406096+00	1119	ELECTROSMART | Marcin Tomaszewski	1	[{"added": {}}]	3	4
1383	2023-10-09 12:58:48.753395+00	1120	ELECTROSMART | Przemek Czubaj	1	[{"added": {}}]	3	4
1384	2023-10-09 12:59:00.932873+00	1121	ELECTROSMART | Paweł Piwowarczyk	1	[{"added": {}}]	3	4
1385	2023-10-09 12:59:10.882153+00	1122	ELECTROSMART | Dawid Lis	1	[{"added": {}}]	3	4
1386	2023-10-09 12:59:22.731484+00	1123	ELECTROSMART | Maksymialian Mroczka	1	[{"added": {}}]	3	4
1387	2023-10-09 12:59:45.581798+00	1124	ELECTROSMART | Misha Jurijczuk	1	[{"added": {}}]	3	4
1388	2023-10-09 12:59:57.352431+00	1125	ELECTROSMART | Przemek Kogut	1	[{"added": {}}]	3	4
1389	2023-10-09 13:00:10.743052+00	1126	ELECTROSMART | Kacper Ziółkowski	1	[{"added": {}}]	3	4
1390	2023-10-09 13:00:20.191024+00	1127	ELECTROSMART | Jakub Nowak	1	[{"added": {}}]	3	4
1391	2023-10-09 13:00:32.2347+00	1128	ELECTROSMART | Marek Pawlus	1	[{"added": {}}]	3	4
1392	2023-10-09 13:00:50.992021+00	1129	ELECTROSMART | Dominik Brózda	1	[{"added": {}}]	3	4
1393	2023-10-09 13:01:02.324982+00	1130	ELECTROSMART | Mateusz Ziółko	1	[{"added": {}}]	3	4
1394	2023-10-09 13:01:20.348364+00	1131	ELECTROSMART | Andrii Stroivans	1	[{"added": {}}]	3	4
1395	2023-10-09 13:01:31.225285+00	1132	ELECTROSMART | Damonik Marzec	1	[{"added": {}}]	3	4
1396	2023-10-09 13:01:48.332371+00	1133	ELECTROSMART | Paweł Domszy	1	[{"added": {}}]	3	4
1397	2023-10-09 13:02:09.093387+00	1134	ELECTROSMART | Carlos Hernandez Frias	1	[{"added": {}}]	3	4
1398	2023-10-09 13:02:22.814466+00	1135	ELECTROSMART | Łukasz Sternal	1	[{"added": {}}]	3	4
1399	2023-10-09 13:02:35.477401+00	1136	ELECTROSMART | Kuba Bigosiński	1	[{"added": {}}]	3	4
1400	2023-10-09 13:02:49.155192+00	1137	ELECTROSMART | Kamil Grabek	1	[{"added": {}}]	3	4
1401	2023-10-09 13:03:00.941076+00	1138	ELECTROSMART | Jan Hołowacz	1	[{"added": {}}]	3	4
1402	2023-10-09 13:03:12.845113+00	1139	ELECTROSMART | Kamil Sobecki	1	[{"added": {}}]	3	4
1403	2023-10-09 13:08:52.993944+00	1061	Huragan Koniowały | Mateusz Kowalik	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1404	2023-10-11 12:50:39.694365+00	1140	Deeks United | Kamil Baku	1	[{"added": {}}]	3	4
1405	2023-10-11 12:51:22.940556+00	1059	Huragan Koniowały | Radek Michalczyk	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1406	2023-10-11 12:51:37.138303+00	1052	The Gunners Nowa Huta | Radosław Jarosz	3		3	4
1516	2023-10-12 09:49:46.855953+00	73	FC Bomby	1	[{"added": {}}]	2	4
1407	2023-10-11 12:51:46.595211+00	1063	Huragan Koniowały | Szymon Kuc	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1408	2023-10-11 12:52:14.272836+00	1141	Sneak Peak | Franciszek Korzeniowski	1	[{"added": {}}]	3	4
1409	2023-10-11 12:52:31.119459+00	1142	Sneak Peak | Paweł Bojar	1	[{"added": {}}]	3	4
1410	2023-10-11 12:52:42.510905+00	1143	Sneak Peak | Filip Kusia	1	[{"added": {}}]	3	4
1411	2023-10-11 12:53:03.030932+00	1144	Sneak Peak | Kamil Skałban	1	[{"added": {}}]	3	4
1412	2023-10-11 12:53:14.542416+00	1145	Sneak Peak | Michał Przęczek	1	[{"added": {}}]	3	4
1413	2023-10-11 12:53:25.95999+00	1146	Sneak Peak | Jan Kołodziejski	1	[{"added": {}}]	3	4
1414	2023-10-11 12:53:36.581913+00	1147	Sneak Peak | Dominik Kukieła	1	[{"added": {}}]	3	4
1415	2023-10-11 12:54:13.078132+00	1148	OG Libertów | Jakub Żmuda	1	[{"added": {}}]	3	4
1416	2023-10-11 12:55:07.845395+00	1038	IKS Łucznik Kraków 1 | Tomasz Degórski	2	[{"changed": {"fields": ["Team"]}}]	3	4
1417	2023-10-11 12:56:12.226677+00	580	IKS Łucznik Kraków 1 | Kuba Wiśniewski	2	[{"changed": {"fields": ["Team"]}}]	3	4
1418	2023-10-11 13:00:02.426686+00	1149	Rosso Negri FC | Kamil Grochal	1	[{"added": {}}]	3	4
1419	2023-10-11 13:00:14.098006+00	1150	Rosso Negri FC | Krzysztof Jasiński	1	[{"added": {}}]	3	4
1420	2023-10-11 13:15:50.851486+00	1151	NieNajMłodsi | Damian Michalec	1	[{"added": {}}]	3	4
1421	2023-10-11 13:16:10.384725+00	1152	NieNajMłodsi | Mateusz Sajdak	1	[{"added": {}}]	3	4
1422	2023-10-11 13:16:35.800581+00	1153	NieNajMłodsi | Kacper Nagórzański	1	[{"added": {}}]	3	4
1423	2023-10-11 13:16:46.091589+00	1154	NieNajMłodsi | Mark Planells	1	[{"added": {}}]	3	4
1424	2023-10-11 13:17:05.142628+00	1155	KS Kremerowianka | Jakub Olma	1	[{"added": {}}]	3	4
1425	2023-10-11 13:17:26.499077+00	1156	Perła Sport | Maks Żyłko	1	[{"added": {}}]	3	4
1426	2023-10-11 13:19:24.080863+00	1157	KS Kondycja | Kuba Wyporek	1	[{"added": {}}]	3	4
1427	2023-10-11 13:19:36.668342+00	1158	KS Kondycja | Jędrek Kotaba	1	[{"added": {}}]	3	4
1428	2023-10-11 13:21:14.084948+00	1159	Pogoń Kraków | Aliaksei Vishavaty	1	[{"added": {}}]	3	4
1429	2023-10-11 13:21:35.069894+00	1160	FC Jesiotry | Wiktor Gaczoł	1	[{"added": {}}]	3	4
1430	2023-10-11 13:21:48.253735+00	1161	Sztywni Nieugięci | Kacper Kil	1	[{"added": {}}]	3	4
1431	2023-10-11 13:21:58.958324+00	1162	Sztywni Nieugięci | Mateusz Więcław	1	[{"added": {}}]	3	4
1432	2023-10-11 13:22:09.739278+00	1163	Sztywni Nieugięci | Tomasz Boroń	1	[{"added": {}}]	3	4
1433	2023-10-11 16:05:39.50279+00	1164	Partyzant Nowa Huta | Adrian Grabowski	1	[{"added": {}}]	3	1
1434	2023-10-11 16:06:05.726154+00	1165	Partyzant Nowa Huta | Andrzej Szaroń	1	[{"added": {}}]	3	1
1435	2023-10-11 16:31:41.823265+00	778	The Gunners Nowa Huta | Norbert Kawa	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	3	1
1436	2023-10-11 16:42:44.347237+00	1166	Iskra Kraków | Adam Arłamowski	1	[{"added": {}}]	3	4
1437	2023-10-11 16:43:07.11233+00	1167	Iskra Kraków | Mateusz Nowak	1	[{"added": {}}]	3	4
1438	2023-10-11 16:43:41.763506+00	1168	Iskra Kraków | Krzysztof Woźniak	1	[{"added": {}}]	3	4
1439	2023-10-11 16:44:01.660414+00	1169	Iskra Kraków | Sebastian Pawlikowski	1	[{"added": {}}]	3	4
1440	2023-10-11 16:44:20.524938+00	1170	Iskra Kraków | Wiktor Woźniak	1	[{"added": {}}]	3	4
1441	2023-10-11 16:44:33.805357+00	1171	Iskra Kraków | Piotr Turbasa	1	[{"added": {}}]	3	4
1442	2023-10-11 16:44:57.133462+00	1172	Iskra Kraków | Jakub Pirowski	1	[{"added": {}}]	3	4
1443	2023-10-11 16:45:14.950549+00	1173	Iskra Kraków | Dawid Biernat	1	[{"added": {}}]	3	4
1444	2023-10-11 16:45:28.326312+00	1174	Iskra Kraków | Dominik Kaczmarski	1	[{"added": {}}]	3	4
1445	2023-10-11 16:45:46.767523+00	1175	Iskra Kraków | Sławomir Krzystanek	1	[{"added": {}}]	3	4
1446	2023-10-11 16:46:03.361944+00	1176	Iskra Kraków | Łukasz Nawara	1	[{"added": {}}]	3	4
1447	2023-10-11 16:46:27.084483+00	1177	Iskra Kraków | Kacper Skruch	1	[{"added": {}}]	3	4
1448	2023-10-11 16:46:41.163259+00	1178	Iskra Kraków | Piotr Bocwiński	1	[{"added": {}}]	3	4
1449	2023-10-11 16:47:05.606774+00	1179	Iskra Kraków | Szymon Helicki	1	[{"added": {}}]	3	4
1450	2023-10-11 16:47:24.878708+00	1180	Iskra Kraków | Dominik Kasprzak	1	[{"added": {}}]	3	4
1451	2023-10-11 16:47:38.707138+00	1181	Iskra Kraków | Adam Kamyk	1	[{"added": {}}]	3	4
1452	2023-10-11 16:47:52.8308+00	1182	Iskra Kraków | Robert Poznański	1	[{"added": {}}]	3	4
1453	2023-10-11 16:48:10.078114+00	1183	Iskra Kraków | Jan Krajewski	1	[{"added": {}}]	3	4
1454	2023-10-11 16:48:26.754685+00	1184	Iskra Kraków | Krystian Król	1	[{"added": {}}]	3	4
1455	2023-10-11 16:48:43.509949+00	1185	Iskra Kraków | Szymon Szymczyk	1	[{"added": {}}]	3	4
1456	2023-10-11 16:50:25.922678+00	1186	Diablo Kraków | Jakub Prostak	1	[{"added": {}}]	3	4
1457	2023-10-11 16:56:33.6652+00	1187	Rozbójnicy Rumcajsa | Andrei Sianiuta	1	[{"added": {}}]	3	4
1458	2023-10-11 16:56:50.569407+00	1188	Rozbójnicy Rumcajsa | Wojciech Pozzi	1	[{"added": {}}]	3	4
1459	2023-10-11 16:57:26.946031+00	1189	Rozbójnicy Rumcajsa | Michał Hyla	1	[{"added": {}}]	3	4
1460	2023-10-11 16:57:46.286994+00	1190	Rozbójnicy Rumcajsa | Adrian Goliński	1	[{"added": {}}]	3	4
1461	2023-10-11 16:58:05.67355+00	1191	Rozbójnicy Rumcajsa | Filip Węgiel	1	[{"added": {}}]	3	4
1462	2023-10-11 16:58:22.278439+00	1192	Rozbójnicy Rumcajsa | Filip Despet	1	[{"added": {}}]	3	4
1463	2023-10-11 16:58:39.359976+00	1193	Rozbójnicy Rumcajsa | Kuba Kukułka	1	[{"added": {}}]	3	4
1464	2023-10-11 16:59:05.486394+00	1194	Rozbójnicy Rumcajsa | Jan Czerlunczakiewicz	1	[{"added": {}}]	3	4
1465	2023-10-11 16:59:17.655284+00	1195	Rozbójnicy Rumcajsa | Daniel Wiśniewski	1	[{"added": {}}]	3	4
1466	2023-10-11 16:59:33.122713+00	1196	Rozbójnicy Rumcajsa | Mikołaj Woda	1	[{"added": {}}]	3	4
1467	2023-10-11 16:59:54.331907+00	1197	Rozbójnicy Rumcajsa | Marcin Chojnacki	1	[{"added": {}}]	3	4
1468	2023-10-11 17:00:06.096572+00	1198	Rozbójnicy Rumcajsa | Konrad Ciechanowicz	1	[{"added": {}}]	3	4
1469	2023-10-11 17:00:20.862807+00	1199	Rozbójnicy Rumcajsa | Konrad Gaborek	1	[{"added": {}}]	3	4
1470	2023-10-11 17:00:42.609654+00	1200	Rozbójnicy Rumcajsa | Michał Marszałek	1	[{"added": {}}]	3	4
1471	2023-10-11 17:01:03.221582+00	1201	Rozbójnicy Rumcajsa | Klaudiusz Kowalczyk	1	[{"added": {}}]	3	4
1472	2023-10-11 17:01:14.299854+00	1202	Rozbójnicy Rumcajsa | Grzegorz Góra	1	[{"added": {}}]	3	4
1473	2023-10-11 17:01:31.166672+00	1203	Rozbójnicy Rumcajsa | Dariusz Tarnopolski	1	[{"added": {}}]	3	4
1474	2023-10-11 17:01:49.68172+00	1204	Rozbójnicy Rumcajsa | Mateusz Krztoń	1	[{"added": {}}]	3	4
1475	2023-10-11 17:02:09.495541+00	1205	Rozbójnicy Rumcajsa | Illya Basiuk	1	[{"added": {}}]	3	4
1476	2023-10-11 17:02:34.322329+00	1206	Rozbójnicy Rumcajsa | Maksim Fedarovich	1	[{"added": {}}]	3	4
1477	2023-10-11 17:02:52.229702+00	1207	Rozbójnicy Rumcajsa | Norbert Rzeźnik	1	[{"added": {}}]	3	4
1478	2023-10-11 17:04:43.234641+00	72	Alimenciarze FC	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	1
1479	2023-10-11 17:19:38.785226+00	1208	AP Galaxy | Przemek Pawlik	1	[{"added": {}}]	3	4
1480	2023-10-11 17:19:55.371229+00	1209	AP Galaxy | Daniel Derdaś	1	[{"added": {}}]	3	4
1481	2023-10-11 17:20:16.702973+00	1210	AP Galaxy | Sławek Bożek	1	[{"added": {}}]	3	4
1482	2023-10-11 17:20:39.681454+00	1211	AP Galaxy | Krystian Percik	1	[{"added": {}}]	3	4
1483	2023-10-11 17:20:54.874108+00	1212	AP Galaxy | Wiktor Surma	1	[{"added": {}}]	3	4
1484	2023-10-11 17:21:23.521292+00	1213	AP Galaxy | Kuba Skórzak	1	[{"added": {}}]	3	4
1485	2023-10-11 17:21:32.638489+00	1214	AP Galaxy | Michał Studziżba	1	[{"added": {}}]	3	4
1486	2023-10-11 17:21:42.222274+00	1215	AP Galaxy | Mateusz Studziżba	1	[{"added": {}}]	3	4
1487	2023-10-11 17:21:59.028058+00	1216	AP Galaxy | Piotr Sucharski	1	[{"added": {}}]	3	4
1488	2023-10-11 17:22:57.798455+00	1217	AP Galaxy | Krzysztof Łobaziewicz	1	[{"added": {}}]	3	4
1489	2023-10-11 17:23:11.678266+00	1218	AP Galaxy | Oskar Worgacz	1	[{"added": {}}]	3	4
1490	2023-10-11 17:24:07.24381+00	1219	AP Galaxy | Kuba Gorczyca	1	[{"added": {}}]	3	4
1491	2023-10-11 17:24:19.866606+00	1220	AP Galaxy | Jakub Matoń	1	[{"added": {}}]	3	4
1492	2023-10-11 17:24:40.330556+00	1221	AP Galaxy | Stanisław Magiera	1	[{"added": {}}]	3	4
1493	2023-10-11 17:24:54.462634+00	1222	AP Galaxy | Sebastian Skowron	1	[{"added": {}}]	3	4
1494	2023-10-11 17:25:08.75277+00	1223	AP Galaxy | Mateusz Szopa	1	[{"added": {}}]	3	4
1495	2023-10-11 17:25:30.344782+00	1224	AP Galaxy | Antoni Karp	1	[{"added": {}}]	3	4
1496	2023-10-11 17:25:42.094793+00	1225	AP Galaxy | Szymon Gaweł	1	[{"added": {}}]	3	4
1497	2023-10-11 17:28:32.508779+00	1226	AP Galaxy | Michał Nalepa	1	[{"added": {}}]	3	4
1498	2023-10-11 17:28:49.591553+00	1227	AP Galaxy | Jakub Bujas	1	[{"added": {}}]	3	4
1499	2023-10-11 17:29:10.142933+00	1228	AP Galaxy | Mateusz Dziża	1	[{"added": {}}]	3	4
1500	2023-10-11 17:29:26.326208+00	1229	AP Galaxy | Adrian Czarnecki	1	[{"added": {}}]	3	4
1501	2023-10-11 17:29:39.231088+00	1230	AP Galaxy | Filip Heród	1	[{"added": {}}]	3	4
1502	2023-10-11 17:29:57.397497+00	1231	AP Galaxy | Łukasz Błażowski	1	[{"added": {}}]	3	4
1503	2023-10-11 17:30:15.233883+00	1232	AP Galaxy | Ignacy Popławski	1	[{"added": {}}]	3	4
1504	2023-10-11 17:30:28.376622+00	1233	AP Galaxy | Patryk Likus	1	[{"added": {}}]	3	4
1505	2023-10-11 17:30:44.364783+00	1234	AP Galaxy | Szymon Wysowski	1	[{"added": {}}]	3	4
1506	2023-10-11 17:30:55.94031+00	1235	AP Galaxy | Kuba Legut	1	[{"added": {}}]	3	4
1507	2023-10-11 17:31:12.518153+00	1236	AP Galaxy | Damian Horosin	1	[{"added": {}}]	3	4
1508	2023-10-11 17:31:23.418464+00	1237	AP Galaxy | Tomek Kowalik	1	[{"added": {}}]	3	4
1509	2023-10-11 17:31:35.754556+00	1238	AP Galaxy | Oliwier Soboń	1	[{"added": {}}]	3	4
1510	2023-10-11 17:31:55.226695+00	1239	AP Galaxy | Daniel Sliż	1	[{"added": {}}]	3	4
1511	2023-10-11 17:32:05.432446+00	1240	AP Galaxy | Wojciech Baranek	1	[{"added": {}}]	3	4
1512	2023-10-11 17:47:37.540037+00	145	Kac Kraków vs AP Galaxy | 2023-09-30	2	[]	4	4
1513	2023-10-11 17:48:04.173538+00	145	Kac Kraków vs AP Galaxy | 2023-09-30	2	[{"changed": {"fields": ["Accepted"]}}]	4	4
1514	2023-10-11 18:05:58.799224+00	1241	Pogoń Kraków | Wiktor Izotov	1	[{"added": {}}]	3	4
1517	2023-10-12 10:57:39.481417+00	145	Kac Kraków vs AP Galaxy | 2023-09-30	2	[]	4	4
1518	2023-10-12 11:02:23.864191+00	1242	FC Bomby | Mateusz Niżnik	1	[{"added": {}}]	3	4
1519	2023-10-12 11:02:40.935222+00	1243	FC Bomby | Aleks Porada	1	[{"added": {}}]	3	4
1520	2023-10-12 11:05:33.722223+00	1244	FC Bomby | Stanisław Sierant	1	[{"added": {}}]	3	4
1521	2023-10-12 11:05:49.853718+00	1245	FC Bomby | Victor Sulik	1	[{"added": {}}]	3	4
1522	2023-10-12 11:06:06.421866+00	1246	FC Bomby | Kuba Suliński	1	[{"added": {}}]	3	4
1523	2023-10-12 11:06:26.728068+00	1247	FC Bomby | Kajetan Kos	1	[{"added": {}}]	3	4
1524	2023-10-12 11:06:45.543797+00	1248	FC Bomby | Adam Miroch	1	[{"added": {}}]	3	4
1525	2023-10-12 11:06:59.97359+00	1249	FC Bomby | Antoni Rams	1	[{"added": {}}]	3	4
1526	2023-10-12 11:07:25.561041+00	50	Kac Pisklaki	2	[{"changed": {"fields": ["Name"]}}]	2	4
1527	2023-10-12 11:07:56.816729+00	1250	FC Bomby | Szymon Bodek	1	[{"added": {}}]	3	4
1528	2023-10-12 11:08:14.166558+00	1251	FC Bomby | Maks Misiewicz	1	[{"added": {}}]	3	4
1529	2023-10-12 11:08:29.793797+00	1252	FC Bomby | Igor Kaźnica	1	[{"added": {}}]	3	4
1530	2023-10-12 11:08:43.313151+00	1253	FC Bomby | Kuba Chabasiewicz	1	[{"added": {}}]	3	4
1531	2023-10-12 11:08:59.005341+00	1254	FC Bomby | Martin Bogdanov	1	[{"added": {}}]	3	4
1532	2023-10-12 11:09:14.101453+00	1255	FC Bomby | Franek Glodek	1	[{"added": {}}]	3	4
1533	2023-10-13 15:23:33.314561+00	23	Super Strikers	2	[{"changed": {"fields": ["Name"]}}]	2	1
1534	2023-10-13 18:24:00.643391+00	1256	Sneak Peak | Paweł Kulig	1	[{"added": {}}]	3	1
1535	2023-10-13 18:24:09.603853+00	1256	Sneak Peak | Paweł Kulig	2	[{"changed": {"fields": ["Matches"]}}]	3	1
1536	2023-10-13 18:24:41.332943+00	1257	Sneak Peak | Paweł Kulig	1	[{"added": {}}]	3	1
1537	2023-10-13 18:33:24.689684+00	153	FC Jesiotry vs Cracov Elite | 2023-10-01	2	[{"changed": {"fields": ["Team1score", "Team2score"]}}]	4	1
1538	2023-10-13 18:33:49.538764+00	42	FC Jesiotry	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost"]}}]	2	1
1539	2023-10-13 18:34:18.071839+00	40	Cracov Elite	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost"]}}]	2	1
1540	2023-10-15 18:30:06.082893+00	1258	Grzenkowianka Ego Topy | Maciej Sudek	1	[{"added": {}}]	3	1
1541	2023-10-15 18:30:21.727324+00	1259	Grzenkowianka Ego Topy | Jakub Bryniak	1	[{"added": {}}]	3	1
1542	2023-10-15 18:30:41.739233+00	1260	Grzenkowianka Ego Topy | Antoni Lelek	1	[{"added": {}}]	3	1
1543	2023-10-15 18:31:11.525645+00	1261	Grzenkowianka Ego Topy | Michał Wermiński	1	[{"added": {}}]	3	1
1544	2023-10-15 18:31:34.223999+00	1262	Grzenkowianka Ego Topy | Dawid Ochman	1	[{"added": {}}]	3	1
1545	2023-10-15 18:34:54.725309+00	1140	Deeks United | Kamil Baka	2	[{"changed": {"fields": ["Surname"]}}]	3	1
1546	2023-10-15 18:35:57.366267+00	1263	Galacticos Kraków 2023 | Tobiasz Wilczyński	1	[{"added": {}}]	3	1
1547	2023-10-15 18:36:18.589455+00	1264	Galacticos Kraków 2023 | Karol Owsiniak	1	[{"added": {}}]	3	1
1548	2023-10-15 18:36:36.822586+00	1265	Galacticos Kraków 2023 | Piotr Sierpiński	1	[{"added": {}}]	3	1
1549	2023-10-15 18:37:59.229203+00	1266	Rozbójnicy Pabiana | Robert Urban	1	[{"added": {}}]	3	1
1550	2023-10-15 18:38:15.228751+00	1267	Rozbójnicy Pabiana | Tomasz Puc	1	[{"added": {}}]	3	1
1551	2023-10-15 18:38:38.826588+00	1268	Rozbójnicy Pabiana | Oskar Tenninga	1	[{"added": {}}]	3	1
1552	2023-10-15 18:39:27.47828+00	1269	IKS Łucznik Kraków 2 | Kamil Tułacz	1	[{"added": {}}]	3	1
1762	2023-11-26 07:12:46.980408+00	1393	Kacper Okulski	1	[{"added": {}}]	3	4
1553	2023-10-15 18:41:13.611615+00	543	IKS Łucznik Kraków 2 | Mateusz Filipek	2	[{"changed": {"fields": ["Team"]}}]	3	1
1554	2023-10-15 18:43:29.077266+00	1270	AL-Kohol FC | Michał Węgrzyn	1	[{"added": {}}]	3	1
1555	2023-10-15 18:43:44.201648+00	1271	AL-Kohol FC | Jakub Węgrzyn	1	[{"added": {}}]	3	1
1556	2023-10-15 18:44:11.852998+00	1272	AL-Kohol FC | Sebastian Socholik	1	[{"added": {}}]	3	1
1557	2023-10-15 18:44:30.337433+00	1273	AL-Kohol FC | Mateusz Łabuś	1	[{"added": {}}]	3	1
1558	2023-10-15 18:44:30.389273+00	1274	AL-Kohol FC | Mateusz Łabuś	1	[{"added": {}}]	3	1
1559	2023-10-15 18:44:49.538899+00	1275	AL-Kohol FC | Tomasz Świderski	1	[{"added": {}}]	3	1
1560	2023-10-15 18:45:18.21628+00	1276	AL-Kohol FC | Piotr Zieliński	1	[{"added": {}}]	3	1
1561	2023-10-15 18:45:52.256033+00	1274	AL-Kohol FC | Krzysztof Filipczyk	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	1
1562	2023-10-15 18:46:09.443359+00	1277	AL-Kohol FC | Mateusz Wrona	1	[{"added": {}}]	3	1
1563	2023-10-15 18:46:47.467814+00	1278	AL-Kohol FC | Mateusz Wojtas	1	[{"added": {}}]	3	1
1564	2023-10-15 18:47:01.983766+00	1279	AL-Kohol FC | Karol Trela	1	[{"added": {}}]	3	1
1565	2023-10-15 18:50:25.1969+00	1280	Luźne Grajki | Konrad Grabowski	1	[{"added": {}}]	3	1
1566	2023-10-15 18:50:53.034821+00	1281	Luźne Grajki | Joanna Mikosińska	1	[{"added": {}}]	3	1
1567	2023-10-16 12:47:10.155596+00	1282	OIOM | Magda Drab	1	[{"added": {}}]	3	4
1568	2023-10-16 12:49:58.672326+00	525	Grzenkowianka Ego Topy | Bartłomiej Bogdewicz	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1569	2023-10-16 12:50:19.757794+00	532	Grzenkowianka Ego Topy | Hubert Salwach	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1570	2023-10-16 12:50:53.524828+00	531	Grzenkowianka Ego Topy | Grzegorz Odrzywołek	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1571	2023-10-16 12:51:10.696482+00	530	Grzenkowianka Ego Topy | Adam Odrzywołek	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1572	2023-10-16 12:52:00.278013+00	563	IKS Łucznik Kraków 2 | Filip Janowski	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1573	2023-10-16 12:53:58.206504+00	76	KS Kremerowianka | Maciek Dynia	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1574	2023-10-16 12:54:08.077165+00	1198	Rozbójnicy Rumcajsa | Konrad Ciechanowicz	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1575	2023-10-16 19:48:30.33458+00	1283	The Gunners Nowa Huta | Mój Stary	1	[{"added": {}}]	3	1
1576	2023-10-16 19:49:36.163143+00	1283	The Gunners Nowa Huta | Mój Stary	3		3	1
1577	2023-10-16 19:50:54.814579+00	1284	The Gunners Nowa Huta | Kocham PIS	1	[{"added": {}}]	3	1
1578	2023-10-16 19:51:21.091812+00	1284	The Gunners Nowa Huta | Kocham PIS	3		3	1
1579	2023-10-19 15:25:29.986644+00	50	Kac Pisklaki	2	[{"changed": {"fields": ["GoalsScored", "GoalsLost", "Matches"]}}]	2	1
1580	2023-10-19 15:25:50.990315+00	53	AP Galaxy	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost", "Matches"]}}]	2	1
1581	2023-10-19 15:32:56.965904+00	1285	RB Karpiów | Patryk Kuc	1	[{"added": {}}]	3	1
1582	2023-10-19 15:33:12.635205+00	1286	RB Karpiów | Dominik Sobesto	1	[{"added": {}}]	3	1
1583	2023-10-19 15:33:26.014274+00	1287	RB Karpiów | Dawid Zajączkowski	1	[{"added": {}}]	3	1
1584	2023-10-19 15:40:41.680013+00	1288	Rozbójnicy Pabiana | Krystian Michalik	1	[{"added": {}}]	3	1
1585	2023-10-19 15:41:01.472394+00	1289	Rozbójnicy Pabiana | Kacper Chrobot	1	[{"added": {}}]	3	1
1586	2023-10-19 15:41:15.622524+00	1290	Rozbójnicy Pabiana | Olek Ciarka	1	[{"added": {}}]	3	1
1587	2023-10-19 15:41:33.734363+00	1291	Rozbójnicy Rumcajsa | Filip Szymoniak	1	[{"added": {}}]	3	1
1588	2023-10-19 15:41:51.680165+00	1291	Rozbójnicy Pabiana | Filip Szymoniak	2	[{"changed": {"fields": ["Team"]}}]	3	1
1589	2023-10-19 15:42:21.559486+00	1292	Rozbójnicy Pabiana | Oskar Niedźwiecki	1	[{"added": {}}]	3	1
1590	2023-10-19 15:42:37.018632+00	1293	Rozbójnicy Pabiana | Karol Dusik	1	[{"added": {}}]	3	1
1591	2023-10-19 15:43:01.192953+00	1294	Orzeł BTS | Sebastian Cebula	1	[{"added": {}}]	3	1
1592	2023-10-19 15:43:13.765719+00	1295	Orzeł BTS | Krzysztof Piskorz	1	[{"added": {}}]	3	1
1593	2023-10-19 15:43:31.525953+00	1296	Orzeł BTS | Odunayo James Rodowa	1	[{"added": {}}]	3	1
1594	2023-10-19 15:43:46.778838+00	1297	Orzeł BTS | Nasrollah Skim	1	[{"added": {}}]	3	1
1595	2023-10-19 15:45:34.738541+00	966	Orzeł BTS | Tadeusz Pieczarkowski	3		3	1
1596	2023-10-19 15:46:15.84838+00	1298	Diablo Kraków | Krzysztof Seweryn	1	[{"added": {}}]	3	1
1597	2023-10-19 15:46:26.717042+00	1299	Diablo Kraków | Karol Kękol	1	[{"added": {}}]	3	1
1598	2023-10-19 15:50:14.266673+00	1300	TS Żelbeton Płaszów | Roch Robotycki	1	[{"added": {}}]	3	1
1599	2023-10-19 15:52:20.693013+00	1301	FC Obywatele | Kuba Kulpiński	1	[{"added": {}}]	3	1
1600	2023-10-19 15:52:41.029193+00	1302	FC Obywatele | Łukasz Żywczyk	1	[{"added": {}}]	3	1
1601	2023-10-19 15:55:31.890533+00	1303	Cracov Elite | Michał Pawełka	1	[{"added": {}}]	3	1
1602	2023-10-19 15:57:47.851297+00	1304	FC Jesiotry | Franek Simlat	1	[{"added": {}}]	3	1
1603	2023-10-19 15:58:11.157983+00	1305	AP Galaxy | Szymon Morga	1	[{"added": {}}]	3	1
1604	2023-10-19 15:59:49.314124+00	1306	Alimenciarze FC | Kacper Suder	1	[{"added": {}}]	3	1
1605	2023-10-19 16:00:24.64821+00	1307	Partyzant Nowa Huta | Szymon Idzik	1	[{"added": {}}]	3	1
1606	2023-10-22 10:03:02.087564+00	1308	FC Sołtyse | Adam Górski	1	[{"added": {}}]	3	4
1607	2023-10-22 19:52:14.528402+00	186	U-Diablo vs Gruzik Wieliczka | 2023-10-22	3		4	4
1608	2023-10-23 07:07:01.761939+00	1309	Biuro Ochrony Stonoga | Mateusz Słota	1	[{"added": {}}]	3	4
1609	2023-10-23 07:08:35.332891+00	1310	Biuro Ochrony Stonoga | Seweryn Kozłowski	1	[{"added": {}}]	3	4
1610	2023-10-23 07:13:35.540724+00	1311	Luźne Grajki | David Sidorchuk	1	[{"added": {}}]	3	4
1611	2023-10-23 07:45:23.633948+00	146	Super Strikers | Kacper Grudziński	3		3	4
1612	2023-10-23 18:53:51.325136+00	1312	AP Galaxy | Jakub Jagłowski	1	[{"added": {}}]	3	4
1613	2023-10-23 18:54:24.752357+00	1313	AP Galaxy | Michał Ficek	1	[{"added": {}}]	3	4
1614	2023-10-23 18:56:12.11379+00	1314	Galacticos Kraków 2023 | Grzegorz Papiż	1	[{"added": {}}]	3	4
1615	2023-10-24 14:56:38.214132+00	1315	Sneak Peak | Paweł Lejczak	1	[{"added": {}}]	3	4
1616	2023-10-24 15:06:27.698029+00	92	Perła Sport | Dawid Marzec	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1617	2023-10-24 15:08:25.921714+00	46	Rozbójnicy Pabiana | Filip Poręba	3		3	4
1618	2023-10-24 15:11:17.065246+00	1291	Rozbójnicy Pabiana | Filip Szymoniak	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1619	2023-10-24 15:18:04.449562+00	1316	OG Libertów | Kacper Kalita	1	[{"added": {}}]	3	4
1620	2023-10-24 16:12:37.789867+00	1317	FC Promil Kraków | Szymon Kończak	1	[{"added": {}}]	3	4
1621	2023-10-27 12:35:41.294632+00	136	Super Strikers | Oskar Adamczyk	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1763	2023-11-26 07:13:09.588738+00	1394	Patryk Gawin	1	[{"added": {}}]	3	4
1622	2023-10-27 12:35:55.865889+00	137	Super Strikers | Kuba Kobylarczyk	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1623	2023-10-27 12:37:10.321958+00	1318	KS Kondycja | Maciek Stramek	1	[{"added": {}}]	3	4
1624	2023-10-27 12:37:26.835655+00	1319	KS Kondycja | Arek Majoch	1	[{"added": {}}]	3	4
1625	2023-10-27 12:37:41.77864+00	1320	KS Kondycja | Mateusz Sumera	1	[{"added": {}}]	3	4
1626	2023-10-27 12:39:38.78358+00	553	IKS Łucznik Kraków 1 | Damian Leśniak	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1627	2023-10-27 12:39:51.703934+00	556	IKS Łucznik Kraków 1 | Adrian Kruba	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1628	2023-10-27 12:41:13.035956+00	1158	KS Kondycja | Jędrek Kotarba	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1629	2023-10-27 12:42:06.036251+00	1321	Zwyrole | Jakub Chudyba	1	[{"added": {}}]	3	4
1630	2023-10-27 12:42:21.329833+00	1322	Zwyrole | Jan Zygmunt	1	[{"added": {}}]	3	4
1631	2023-10-27 12:42:45.984096+00	1323	Rozbójnicy Pabiana | Karol Kuczmier	1	[{"added": {}}]	3	4
1632	2023-10-27 12:43:53.317799+00	1324	AP Galaxy | Jakub Morga	1	[{"added": {}}]	3	4
1633	2023-10-27 12:44:09.465785+00	1325	AP Galaxy | Krzysztof Sokołowski	1	[{"added": {}}]	3	4
1634	2023-10-27 12:44:25.200409+00	1326	AP Galaxy | Piotr Kedziora	1	[{"added": {}}]	3	4
1635	2023-10-27 12:51:08.224292+00	1326	TEAM Salvator | Piotr Kędziora	2	[{"changed": {"fields": ["Team", "Surname"]}}]	3	4
1636	2023-10-27 12:56:20.771677+00	1327	IKS Łucznik Kraków 2 | Kacper Suder	1	[{"added": {}}]	3	4
1637	2023-10-27 12:56:43.41879+00	1328	Sneak Peak | Damian Dziemba	1	[{"added": {}}]	3	4
1638	2023-10-27 12:57:00.883711+00	1329	Sneak Peak | Marcin Kanigowski	1	[{"added": {}}]	3	4
1639	2023-10-28 07:50:17.279093+00	1330	FC Pacynki | Piotr Gralak	1	[{"added": {}}]	3	4
1640	2023-10-29 12:39:07.491848+00	1331	IKS Łucznik Kraków 2 | Szymon Kurzeja	1	[{"added": {}}]	3	4
1641	2023-10-30 08:31:58.382856+00	1332	TS Żelbeton Płaszów | Szymon Sikora	1	[{"added": {}}]	3	4
1642	2023-10-30 08:34:43.992653+00	111	TS Żelbeton Płaszów | Dymitr Krawczuk	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1643	2023-10-30 08:38:49.32628+00	655	OIOM | Adam Kuśmider	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1644	2023-10-30 08:55:03.549054+00	1333	KS Kondycja | Łukasz Chmielowski	1	[{"added": {}}]	3	4
1645	2023-10-30 08:58:49.765529+00	416	KS Kondycja | Patryk Daniec	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1646	2023-10-30 09:06:52.713532+00	1065	Huragan Koniowały | Wojtek Czyrnek	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	3	4
1647	2023-10-30 09:09:52.731884+00	1054	Huragan Koniowały | Sebastian Soból	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1648	2023-10-30 09:10:02.812094+00	1058	Huragan Koniowały | Łukasz Gdula	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1649	2023-10-30 09:10:09.919812+00	1059	Huragan Koniowały | Radek Michalczyk	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1650	2023-10-31 12:26:52.41004+00	1272	AL-Kohol FC | Sebastian Socholik	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1651	2023-11-02 16:40:44.287486+00	1334	Najlepsi w Mieście | Szymon Piątek	1	[{"added": {}}]	3	4
1652	2023-11-02 16:41:10.338176+00	1335	Najlepsi w Mieście | Mateusz Kwiecień	1	[{"added": {}}]	3	4
1653	2023-11-06 12:06:04.183074+00	41	Rozbójnicy Pabiana | Szymon Everard	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1654	2023-11-06 12:06:12.441886+00	1126	ELECTROSMART | Kacper Ziółkowski	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1655	2023-11-06 12:12:32.268511+00	579	IKS Łucznik Kraków 2 | Damian Horosin	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	3	4
1656	2023-11-06 12:12:53.02358+00	1263	Galacticos Kraków 2023 | Tobiasz Wilczyński	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	3	4
1657	2023-11-06 12:13:06.981394+00	672	Galacticos Kraków 2023 | Szymon Nastały	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	3	4
1658	2023-11-06 12:18:07.64173+00	1332	FC Braziliana | Szymon Sikora	2	[{"changed": {"fields": ["Team"]}}]	3	4
1659	2023-11-06 12:19:44.832191+00	111	TS Żelbeton Płaszów | Dymitr Krawczuk	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1660	2023-11-06 12:20:35.285247+00	1336	Sneak Peak | Bruno Sikorski	1	[{"added": {}}]	3	4
1661	2023-11-06 12:21:19.566353+00	1337	Grzenkowianka Ego Topy | Karol Kielijan	1	[{"added": {}}]	3	4
1662	2023-11-06 12:21:32.337026+00	1338	Grzenkowianka Ego Topy | Szymon Filar	1	[{"added": {}}]	3	4
1663	2023-11-06 12:21:52.423143+00	1339	Grzenkowianka Ego Topy | Krzysztof Nowakowski	1	[{"added": {}}]	3	4
1664	2023-11-06 12:22:08.971356+00	1340	Grzenkowianka Ego Topy | Szymon Figura	1	[{"added": {}}]	3	4
1665	2023-11-06 12:22:25.206832+00	1341	Grzenkowianka Ego Topy | Rafał Madej	1	[{"added": {}}]	3	4
1666	2023-11-06 12:25:25.231244+00	1342	Diablo Kraków | Mateusz Ryskala	1	[{"added": {}}]	3	4
1667	2023-11-06 12:25:40.119339+00	1343	Diablo Kraków | Josh Ernstzen	1	[{"added": {}}]	3	4
1668	2023-11-06 12:26:05.267209+00	1344	Orzeł BTS | Andrzej Polachow	1	[{"added": {}}]	3	4
1669	2023-11-06 12:28:27.499864+00	1345	Laga FC | Dominik Mika	1	[{"added": {}}]	3	4
1670	2023-11-06 12:28:46.050724+00	1346	Laga FC | Marcin Rybak	1	[{"added": {}}]	3	4
1671	2023-11-06 12:29:01.652706+00	1347	Laga FC | Przemek Broś	1	[{"added": {}}]	3	4
1672	2023-11-06 12:29:36.119765+00	1348	TEAM Salvator | Antoni Rożdżenski	1	[{"added": {}}]	3	4
1673	2023-11-06 12:29:46.234176+00	1349	TEAM Salvator | Aleks Paczka	1	[{"added": {}}]	3	4
1674	2023-11-06 12:30:06.771419+00	1350	AP Galaxy | Norbert Morek	1	[{"added": {}}]	3	4
1675	2023-11-06 12:30:59.470921+00	1351	MKS Mistrzejowice | Dominik Kwaśnik	1	[{"added": {}}]	3	4
1676	2023-11-07 11:42:26.860021+00	235	ELECTROSMART vs Rozbójnicy Pabiana | 2023-11-03	2	[{"changed": {"fields": ["Team1score"]}}]	4	4
1677	2023-11-07 11:42:39.284713+00	9	ELECTROSMART	2	[{"changed": {"fields": ["GoalsScored"]}}]	2	4
1678	2023-11-07 11:43:01.137688+00	18	Rozbójnicy Pabiana	2	[{"changed": {"fields": ["GoalsLost"]}}]	2	4
1679	2023-11-07 12:09:10.774192+00	85	KS Kremerowianka | Wiktor Filipczyk	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1680	2023-11-09 11:46:49.648101+00	244	AP Galaxy vs Laga FC | 2023-10-29	2	[{"changed": {"fields": ["Accepted"]}}]	4	4
1681	2023-11-09 11:47:57.321007+00	2140	AP Galaxy vs FootCanser | 2023-11-04 | Bartosz Soja	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	14	4
1682	2023-11-09 11:48:22.458115+00	245	AP Galaxy vs FootCanser | 2023-11-04	2	[{"changed": {"fields": ["Accepted"]}}]	4	4
1683	2023-11-09 11:55:23.975554+00	1352	Adam Kubiena	1	[{"added": {}}]	3	4
1684	2023-11-09 11:56:54.475341+00	244	AP Galaxy vs Laga FC | 2023-10-29	2	[]	4	4
1685	2023-11-10 12:47:45.054572+00	1353	Jakub SIemanow	1	[{"added": {}}]	3	4
1686	2023-11-10 16:12:57.699664+00	1354	Adam Habas	1	[{"added": {}}]	3	4
1687	2023-11-12 11:11:19.438208+00	245	AP Galaxy vs FootCanser | 2023-11-04	2	[]	4	4
1688	2023-11-12 11:12:16.003275+00	244	AP Galaxy vs Laga FC | 2023-10-29	2	[{"changed": {"fields": ["Accepted"]}}]	4	4
1689	2023-11-12 11:12:23.607214+00	244	AP Galaxy vs Laga FC | 2023-10-29	2	[{"changed": {"fields": ["Accepted"]}}]	4	4
1690	2023-11-12 17:16:22.908585+00	1355	Filip Chłopek	1	[{"added": {}}]	3	4
1691	2023-11-12 18:04:34.547322+00	1262	Dawid Ochman	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1692	2023-11-12 18:09:09.304288+00	520	Renan Primo	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1693	2023-11-13 11:14:25.274712+00	1356	Michał Niedziela	1	[{"added": {}}]	3	4
1694	2023-11-13 11:14:37.875067+00	1357	Kamil Kolodziej	1	[{"added": {}}]	3	4
1695	2023-11-13 11:14:54.902613+00	1358	Jan Korczak	1	[{"added": {}}]	3	4
1696	2023-11-13 11:16:58.164622+00	30	Maurycy Jakubiec	2	[{"changed": {"fields": ["MvpPoints", "GoalsScored", "Matches"]}}]	3	4
1697	2023-11-13 11:17:19.243302+00	37	Tadeusz Pitera	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1698	2023-11-13 11:17:43.518441+00	27	Konrad Kukułka	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1699	2023-11-13 11:18:05.722566+00	35	Szymon Olajossy	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1700	2023-11-13 11:18:21.147636+00	36	Tadeusz Pieczarkowski	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1701	2023-11-13 11:22:56.115812+00	1359	Szymon Biedrzycki	1	[{"added": {}}]	3	4
1702	2023-11-13 11:23:15.990531+00	1360	Adam Wołowiec	1	[{"added": {}}]	3	4
1703	2023-11-13 11:23:47.787966+00	1361	Patryk Koszela	1	[{"added": {}}]	3	4
1704	2023-11-13 11:24:03.229821+00	1362	Bartosz Pietrzyka	1	[{"added": {}}]	3	4
1705	2023-11-13 11:24:22.345882+00	1363	Jakub Kucharski	1	[{"added": {}}]	3	4
1706	2023-11-13 11:24:39.503956+00	1364	Mikołaj Mateja	1	[{"added": {}}]	3	4
1707	2023-11-14 14:02:17.988213+00	742	Patryk Hajduk	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1708	2023-11-14 14:02:33.536253+00	739	Paweł Karpiński	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1709	2023-11-14 14:02:56.557216+00	793	Michał Bryg	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1710	2023-11-14 14:03:16.389301+00	1043	Serhi Pylypchuka	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1711	2023-11-14 14:04:56.056163+00	53	AP Galaxy	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	4
1712	2023-11-14 14:05:37.898192+00	1365	Krzysiek Chromiec	1	[{"added": {}}]	3	4
1713	2023-11-14 14:13:25.575635+00	1366	Kiryl Shashura	1	[{"added": {}}]	3	4
1714	2023-11-14 14:13:49.756056+00	1367	Gracjan Tronina	1	[{"added": {}}]	3	4
1715	2023-11-14 14:14:08.586739+00	770	Sebastian Wójcik	3		3	4
1716	2023-11-14 14:14:24.343017+00	980	Sebastian Wójcik	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	4
1717	2023-11-14 14:14:48.858984+00	1368	Kuba Polniak	1	[{"added": {}}]	3	4
1718	2023-11-14 14:15:04.340196+00	1369	Adam Habas	1	[{"added": {}}]	3	4
1719	2023-11-15 12:00:53.277728+00	738	Jakub Bednar	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	4
1720	2023-11-15 12:01:02.527659+00	738	Jakub Bednar	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1721	2023-11-15 12:01:19.385306+00	793	Michał Bryg	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1722	2023-11-15 12:06:11.516037+00	1370	Wojciech Kociniak	1	[{"added": {}}]	3	4
1723	2023-11-15 12:07:36.668125+00	1371	Bartosz Wrzecionek	1	[{"added": {}}]	3	4
1724	2023-11-15 12:07:50.096704+00	1372	Adam Łakota	1	[{"added": {}}]	3	4
1725	2023-11-15 12:08:05.604766+00	1373	Jan Waniewski	1	[{"added": {}}]	3	4
1726	2023-11-15 12:08:22.809224+00	1374	Michał Wąsowicz	1	[{"added": {}}]	3	4
1727	2023-11-15 12:08:36.108795+00	1375	Mikołaj Liszka	1	[{"added": {}}]	3	4
1728	2023-11-15 12:12:22.426372+00	1376	Kuba Wojdyło	1	[{"added": {}}]	3	4
1729	2023-11-15 12:12:56.157869+00	1377	Paweł Jerzyna	1	[{"added": {}}]	3	4
1730	2023-11-19 17:34:00.338036+00	520	Renan Primo	2	[{"changed": {"fields": ["Matches"]}}]	3	4
1731	2023-11-19 17:37:32.920295+00	520	Renan Primo	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1732	2023-11-19 21:02:49.168123+00	825	Filip Szymus	2	[{"changed": {"fields": ["Team"]}}]	3	4
1733	2023-11-20 11:37:12.17195+00	270	FC Imigranci vs RB Karpiów | 2023-11-19	2	[{"changed": {"fields": ["Team1score", "Team2score", "Accepted"]}}]	4	4
1734	2023-11-20 11:37:45.44974+00	70	RB Karpiów	2	[{"changed": {"fields": ["GoalsScored", "GoalsLost"]}}]	2	4
1735	2023-11-20 11:38:14.697707+00	58	FC Imigranci	2	[{"changed": {"fields": ["GoalsScored", "GoalsLost"]}}]	2	4
1736	2023-11-20 11:41:07.647724+00	553	Damian Leśniak	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1737	2023-11-20 11:41:23.422953+00	549	Grzegorz Jabłoński	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1738	2023-11-20 11:41:43.12815+00	555	Hubert Wasilewski	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1739	2023-11-21 12:27:35.122454+00	1065	Wojtek Czyrnek	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1740	2023-11-21 12:34:27.239952+00	1378	Egor Kutilov	1	[{"added": {}}]	3	4
1741	2023-11-21 12:34:39.304777+00	1379	Kuba Łuc	1	[{"added": {}}]	3	4
1742	2023-11-21 12:35:01.059371+00	1380	Illia Goncharov	1	[{"added": {}}]	3	4
1743	2023-11-21 12:35:41.334238+00	1381	Mateusz Świerk	1	[{"added": {}}]	3	4
1744	2023-11-21 12:35:56.792713+00	1382	Patryk Idzik	1	[{"added": {}}]	3	4
1745	2023-11-21 12:37:05.995652+00	1383	Kajetan Hawira	1	[{"added": {}}]	3	4
1746	2023-11-21 12:37:38.548596+00	1384	Hubert Suder	1	[{"added": {}}]	3	4
1747	2023-11-21 12:38:02.018635+00	1385	Dawid Kubański	1	[{"added": {}}]	3	4
1748	2023-11-21 12:39:08.153439+00	1386	Oliwier Kłyś	1	[{"added": {}}]	3	4
1749	2023-11-21 12:39:35.907506+00	1387	Jonasz Kluza	1	[{"added": {}}]	3	4
1750	2023-11-21 12:57:22.154103+00	272	ELECTROSMART vs Hellas Ivvona | 2023-11-19	2	[{"changed": {"fields": ["Team2score"]}}]	4	4
1751	2023-11-21 12:57:59.240292+00	9	ELECTROSMART	2	[{"changed": {"fields": ["GoalsLost"]}}]	2	4
1752	2023-11-21 12:58:15.840396+00	14	Hellas Ivvona	2	[{"changed": {"fields": ["GoalsScored"]}}]	2	4
1753	2023-11-25 15:24:35.779352+00	1257	Paweł Kulig	3		3	4
1754	2023-11-25 15:25:11.223071+00	1256	Paweł Kulig	2	[{"changed": {"fields": ["MvpPoints", "GoalsScored"]}}]	3	4
1755	2023-11-25 15:25:33.627505+00	1141	Franciszek Korzeniowski	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1756	2023-11-26 07:09:17.187323+00	1388	Aleksander Udała	1	[{"added": {}}]	3	4
1757	2023-11-26 07:09:17.66922+00	1389	Aleksander Udała	1	[{"added": {}}]	3	4
1758	2023-11-26 07:09:36.044374+00	1389	Konrad Hajto	2	[{"changed": {"fields": ["Name", "Surname"]}}]	3	4
1759	2023-11-26 07:10:10.338267+00	1390	Mateusz Małek	1	[{"added": {}}]	3	4
1760	2023-11-26 07:11:14.836292+00	1391	Jakub Niedziela	1	[{"added": {}}]	3	4
1761	2023-11-26 07:12:05.042538+00	1392	Paweł Pawlikowski	1	[{"added": {}}]	3	4
1764	2023-11-26 07:13:26.160118+00	1395	Emil Szałankiewicz	1	[{"added": {}}]	3	4
1765	2023-11-26 07:14:24.05536+00	1396	Patryk Kubański	1	[{"added": {}}]	3	4
1766	2023-11-26 07:14:43.794202+00	1397	Jakub Frączewski	1	[{"added": {}}]	3	4
1767	2023-11-26 07:15:29.036564+00	1398	Olaf Katarzyński	1	[{"added": {}}]	3	4
1768	2023-11-26 07:16:09.436048+00	1399	Wojciech Olsza	1	[{"added": {}}]	3	4
1769	2023-11-26 07:16:28.180466+00	1400	Hypolite Drums	1	[{"added": {}}]	3	4
1770	2023-11-26 07:16:48.945615+00	1401	Nicholas Carta	1	[{"added": {}}]	3	4
1771	2023-11-27 08:28:54.758886+00	1402	Artur Kowalik	1	[{"added": {}}]	3	4
1772	2023-11-27 08:43:33.838755+00	1003	Eryk Radwan	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1773	2023-11-30 19:11:44.374577+00	1403	Tymon Piotrowicz	1	[{"added": {}}]	3	4
1774	2023-11-30 19:13:03.661568+00	350	Igor Gajda	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1775	2023-11-30 19:13:39.803751+00	76	Maciek Dynia	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1776	2023-11-30 19:13:57.440202+00	418	Mateusz Niedopytalski	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1777	2023-11-30 19:17:28.129132+00	1404	Kacper Gil	1	[{"added": {}}]	3	4
1778	2023-11-30 19:17:56.098389+00	160	Mateusz Długosz	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1779	2023-11-30 19:18:52.822587+00	1405	Arkadiusz Baran	1	[{"added": {}}]	3	4
1780	2023-11-30 19:19:07.800954+00	1406	Michał Capik	1	[{"added": {}}]	3	4
1781	2023-12-03 18:03:32.150123+00	923	Szymon Bończyk	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1782	2023-12-03 18:03:49.705253+00	888	Arkadiusz Kudzia	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1783	2023-12-03 18:16:44.521724+00	12	AKS Wolni Strzelcy	2	[{"changed": {"fields": ["GoalsLost", "Matches"]}}]	2	4
1784	2023-12-07 07:08:56.914669+00	1311	David Sidorchuk	2	[{"changed": {"fields": ["Team"]}}]	3	4
1785	2023-12-07 07:12:34.859825+00	58	Jan Zawiliński	2	[{"changed": {"fields": ["Surname"]}}]	3	4
1786	2023-12-07 07:13:40.96621+00	66	Przemysław Wojdak	2	[{"changed": {"fields": ["Team"]}}]	3	4
1787	2023-12-09 14:54:31.195189+00	902	Ivan Gnatyszen	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1788	2023-12-09 14:54:59.051319+00	778	Norbert Kawa	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1789	2023-12-09 14:55:12.508957+00	902	Ivan Gnatyszen	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	4
1790	2023-12-14 19:17:54.077798+00	981	Piotr Ptak	2	[{"changed": {"fields": ["Team"]}}]	3	4
1791	2023-12-14 19:18:58.411529+00	1407	Oskar Podkowa	1	[{"added": {}}]	3	4
1792	2023-12-18 11:08:56.553482+00	1408	Kacper Piech	1	[{"added": {}}]	3	4
1793	2023-12-20 08:13:34.813133+00	1312	Jakub Jagłowski	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	3	4
1794	2023-12-28 13:45:49.63768+00	1409	Filip Padyś	1	[{"added": {}}]	3	4
1795	2023-12-28 13:49:38.595431+00	1410	Bartek Zydek	1	[{"added": {}}]	3	4
1796	2023-12-28 13:54:13.135353+00	1411	Filip Leśniak	1	[{"added": {}}]	3	4
1797	2023-12-28 13:54:36.906369+00	1412	Max Mrowiec	1	[{"added": {}}]	3	4
1798	2023-12-28 13:55:24.917194+00	1413	Maciej Wojtaszek	1	[{"added": {}}]	3	4
1799	2023-12-28 13:59:20.130952+00	1414	Antoni Ziajko	1	[{"added": {}}]	3	4
1800	2023-12-28 14:00:42.988617+00	1415	Aleksander Karagiannakos	1	[{"added": {}}]	3	4
1801	2023-12-28 14:01:56.957469+00	1416	Dominik Wesołowski	1	[{"added": {}}]	3	4
1802	2023-12-28 14:02:19.620385+00	1417	Jan Olszewski	1	[{"added": {}}]	3	4
1803	2023-12-28 14:17:49.320336+00	1418	Karol Dusik	1	[{"added": {}}]	3	4
1804	2023-12-30 07:46:29.809197+00	1419	Karol Sałamaj	1	[{"added": {}}]	3	4
1805	2024-01-01 14:44:58.133522+00	832	Filip Kałuża	2	[{"changed": {"fields": ["MvpPoints", "KeeperPoints"]}}]	3	4
1806	2024-01-01 14:45:47.859901+00	21	Tomek Tychoniak	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1807	2024-01-01 14:46:25.237027+00	1298	Krzysztof Seweryn	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1808	2024-01-01 14:46:50.780055+00	1369	Adam Habas	3		3	4
1809	2024-01-01 14:47:38.308211+00	11	Jakub Kleczar	2	[{"changed": {"fields": ["Name"]}}]	3	4
1810	2024-01-01 14:50:25.051158+00	41	Szymon Everard	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1811	2024-01-02 12:12:21.038625+00	13	Strassenbande	2	[{"changed": {"fields": ["GoalsLost", "Matches"]}}]	2	4
1812	2024-01-08 12:36:38.387485+00	1420	Filip Leśniak	1	[{"added": {}}]	3	4
1813	2024-01-08 12:36:51.512222+00	1421	Max Mrowiec	1	[{"added": {}}]	3	4
1814	2024-01-08 12:37:36.848972+00	1422	Emiliano Uria	1	[{"added": {}}]	3	4
1815	2024-01-08 12:53:48.2499+00	1423	Piotr Porada	1	[{"added": {}}]	3	4
1816	2024-01-08 12:54:02.59309+00	1424	Kamil Szwed	1	[{"added": {}}]	3	4
1817	2024-01-08 12:54:18.639414+00	1425	Kacper Bonarek	1	[{"added": {}}]	3	4
1818	2024-01-08 12:54:33.381426+00	1426	Maciek Kopeć	1	[{"added": {}}]	3	4
1819	2024-01-08 12:54:45.074463+00	1427	Martin Tesio	1	[{"added": {}}]	3	4
1820	2024-01-08 12:55:17.151425+00	1428	Jacek Kusiak	1	[{"added": {}}]	3	4
1821	2024-01-08 12:55:56.852162+00	1429	Szymon Garus	1	[{"added": {}}]	3	4
1822	2024-01-08 12:56:55.742086+00	1430	Kacper Rodak	1	[{"added": {}}]	3	4
1823	2024-01-08 12:57:12.79263+00	1431	Szymon Rewilak	1	[{"added": {}}]	3	4
1824	2024-01-08 13:53:15.214877+00	450	Mateusz Łabuś	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1825	2024-01-08 13:53:28.060112+00	455	Krzysztof Malina	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1826	2024-01-08 13:54:52.646672+00	876	Korneliusz Bem	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1827	2024-01-08 13:55:18.597154+00	503	Oliwier Kłyś	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1828	2024-01-08 13:55:50.225201+00	498	Wiktor Banachowicz	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1829	2024-01-16 12:43:55.279286+00	701	Jakub Musiał	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1830	2024-01-16 12:45:59.733504+00	1418	Karol Dusik	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1831	2024-01-16 12:47:37.557834+00	1432	Maciej Ziolowicz	1	[{"added": {}}]	3	4
1832	2024-01-16 20:41:53.59102+00	1433	Jakub Sewioł	1	[{"added": {}}]	3	4
1833	2024-01-17 12:41:58.48075+00	453	Filip Kowalski	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1834	2024-01-20 15:50:25.113899+00	1434	Arkadiusz Grabowski	1	[{"added": {}}]	3	4
1835	2024-01-22 11:20:49.727494+00	1435	Szymon Zdebski	1	[{"added": {}}]	3	4
1836	2024-01-22 11:21:42.739988+00	646	Hubert Januszek	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1837	2024-01-22 13:00:33.551927+00	531	Grzegorz Odrzywołek	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1838	2024-01-22 13:00:45.216549+00	531	Grzegorz Odrzywołek	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1839	2024-01-22 13:00:54.59409+00	530	Adam Odrzywołek	2	[{"changed": {"fields": ["Matches"]}}]	3	4
1840	2024-01-22 13:01:13.872607+00	1338	Szymon Filar	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1841	2024-01-22 13:05:37.949066+00	1338	Szymon Filar	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1842	2024-01-23 09:22:45.16347+00	1436	Maciej Dzięgiel	1	[{"added": {}}]	3	4
1843	2024-01-23 12:24:28.05033+00	1437	Damian Anders	1	[{"added": {}}]	3	4
1844	2024-01-27 11:40:28.417151+00	1438	Michał Matuszczyk	1	[{"added": {}}]	3	4
1845	2024-01-27 11:40:42.016947+00	1439	Dominik Sikora	1	[{"added": {}}]	3	4
1846	2024-01-27 11:40:57.955017+00	1440	Filip Szarka	1	[{"added": {}}]	3	4
1847	2024-01-27 11:41:44.02552+00	1441	Artur Gruchała	1	[{"added": {}}]	3	4
1848	2024-01-27 11:42:11.63623+00	1442	Natan Draus	1	[{"added": {}}]	3	4
1849	2024-01-27 11:42:48.158604+00	1443	Vladyslav Yurchenko	1	[{"added": {}}]	3	4
1850	2024-01-27 11:43:25.49556+00	542	Tomasz Kozak	2	[{"changed": {"fields": ["Team"]}}]	3	4
1851	2024-01-27 11:44:08.15914+00	1444	Mikalai Serebro	1	[{"added": {}}]	3	4
1852	2024-01-27 11:44:31.604403+00	1445	Vitalii Vozniak	1	[{"added": {}}]	3	4
1853	2024-01-27 11:44:58.828262+00	1446	Dawid Rybałtowski	1	[{"added": {}}]	3	4
1854	2024-01-27 11:45:33.946364+00	1447	Aleksander Stanula	1	[{"added": {}}]	3	4
1855	2024-01-27 11:46:15.424945+00	1448	Dawid Śmiech	1	[{"added": {}}]	3	4
1856	2024-01-27 11:46:38.621165+00	1449	Igor Wójcik	1	[{"added": {}}]	3	4
1857	2024-01-28 11:43:56.908039+00	981	Piotr Ptak	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1858	2024-01-28 11:44:11.628522+00	772	Tomasz Mączyński	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1859	2024-01-30 15:48:22.78037+00	1450	Dominik Matuszczyk	1	[{"added": {}}]	3	4
1860	2024-01-30 15:48:43.96281+00	1451	Dawid Gruszkowski	1	[{"added": {}}]	3	4
1861	2024-01-30 15:48:58.858041+00	988	Bartek Podkowa	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1862	2024-01-30 15:50:51.508294+00	988	Bartek Podkowa	2	[{"changed": {"fields": ["GoalsScored"]}}]	3	4
1863	2024-01-30 16:11:45.354676+00	1452	Igor Chlebowski	1	[{"added": {}}]	3	4
1864	2024-01-30 18:35:28.254033+00	1453	Nikodem Wszołek	1	[{"added": {}}]	3	4
1865	2024-02-01 17:48:50.864911+00	1454	Jan Obrał	1	[{"added": {}}]	3	4
1866	2024-02-01 17:49:28.729923+00	1455	Odbayar Oibadrakh	1	[{"added": {}}]	3	4
1867	2024-02-01 17:49:50.87967+00	1456	Leszek Zieliński	1	[{"added": {}}]	3	4
1868	2024-02-01 17:50:12.097115+00	1457	Marcin Cieliński	1	[{"added": {}}]	3	4
1869	2024-02-01 17:50:30.663707+00	1458	Mateo Styrna	1	[{"added": {}}]	3	4
1870	2024-02-02 10:14:07.649258+00	1459	Maciej Jurkowski	1	[{"added": {}}]	3	4
1871	2024-02-03 12:00:08.764839+00	461	FC Cytadela vs FC Pacynki | 2024-01-29	3		4	4
1872	2024-02-03 12:33:49.14936+00	64	FC Pacynki	2	[{"changed": {"fields": ["Points", "Matches"]}}]	2	4
1873	2024-02-05 20:12:27.758499+00	18	Rozbójnicy Pabiana	2	[{"changed": {"fields": ["Points", "GoalsLost"]}}]	2	4
1874	2024-02-05 20:12:49.848045+00	16	Rosso Negri FC	2	[{"changed": {"fields": ["Points", "GoalsLost"]}}]	2	4
1875	2024-02-05 20:13:21.884098+00	17	FC Promil Kraków	2	[{"changed": {"fields": ["Points", "GoalsScored", "GoalsLost"]}}]	2	4
1876	2024-02-05 20:13:38.422806+00	8	The Gunners Nowa Huta	2	[{"changed": {"fields": ["Points"]}}]	2	4
1877	2024-02-05 20:18:23.537064+00	1054	Sebastian Soból	2	[{"changed": {"fields": ["MvpPoints"]}}]	3	4
1878	2024-02-05 20:19:49.62704+00	643	Joachim Bogacki	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1879	2024-02-05 20:24:21.359247+00	6	Deeks United	2	[{"changed": {"fields": ["Points", "GoalsScored"]}}]	2	4
1880	2024-02-06 19:14:35.594659+00	142	Mikołaj Wójcik	2	[{"changed": {"fields": ["GoalsScored", "Matches"]}}]	3	4
1881	2024-02-06 19:16:07.570006+00	520	Renan Primo	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1882	2024-02-09 16:00:51.843516+00	515	U-Diablo vs Kac Pisklaki | 2024-02-07	3		4	4
1883	2024-02-09 16:01:31.72134+00	37	U-Diablo	2	[{"changed": {"fields": ["Points", "GoalsScored", "Matches"]}}]	2	4
1884	2024-02-09 16:01:58.253175+00	50	Kac Pisklaki	2	[{"changed": {"fields": ["GoalsLost", "Matches"]}}]	2	4
1885	2024-02-11 22:20:14.44334+00	1460	Bartosz Owczarek	1	[{"added": {}}]	3	4
1886	2024-02-12 17:35:46.687342+00	903	Olaf Pomykalski	2	[{"changed": {"fields": ["Matches"]}}]	3	4
1887	2024-02-12 18:22:56.570769+00	902	Ivan Gnatyszen	2	[{"changed": {"fields": ["Matches"]}}]	3	4
1888	2024-02-14 11:16:23.648037+00	63	IKS Łucznik Kraków 2	2	[{"changed": {"fields": ["Matches"]}}]	2	4
1889	2024-02-15 11:59:57.352123+00	520	Renan Primo	2	[{"changed": {"fields": ["KeeperPoints"]}}]	3	4
1890	2024-02-15 12:01:45.548899+00	738	Jakub Bednar	2	[{"changed": {"fields": ["KeeperPoints", "Matches"]}}]	3	4
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."django_content_type" ("id", "app_label", "model") FROM stdin;
1	main	league
2	main	team
3	main	player
4	main	match
5	admin	logentry
6	auth	permission
7	auth	group
8	auth	user
9	contenttypes	contenttype
10	sessions	session
11	main	matchqueue
12	main	playerqueue
13	main	teamqueue
14	main	participation
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."django_migrations" ("id", "app", "name", "applied") FROM stdin;
1	contenttypes	0001_initial	2023-09-15 19:17:37.825454+00
2	auth	0001_initial	2023-09-15 19:17:38.024107+00
3	admin	0001_initial	2023-09-15 19:17:38.050683+00
4	admin	0002_logentry_remove_auto_add	2023-09-15 19:17:38.058187+00
5	admin	0003_logentry_add_action_flag_choices	2023-09-15 19:17:38.06726+00
6	contenttypes	0002_remove_content_type_name	2023-09-15 19:17:38.113462+00
7	auth	0002_alter_permission_name_max_length	2023-09-15 19:17:38.122666+00
8	auth	0003_alter_user_email_max_length	2023-09-15 19:17:38.130924+00
9	auth	0004_alter_user_username_opts	2023-09-15 19:17:38.138401+00
10	auth	0005_alter_user_last_login_null	2023-09-15 19:17:38.146163+00
11	auth	0006_require_contenttypes_0002	2023-09-15 19:17:38.148587+00
12	auth	0007_alter_validators_add_error_messages	2023-09-15 19:17:38.156012+00
13	auth	0008_alter_user_username_max_length	2023-09-15 19:17:38.169343+00
14	auth	0009_alter_user_last_name_max_length	2023-09-15 19:17:38.218843+00
15	auth	0010_alter_group_name_max_length	2023-09-15 19:17:38.227603+00
16	auth	0011_update_proxy_permissions	2023-09-15 19:17:38.235089+00
17	auth	0012_alter_user_first_name_max_length	2023-09-15 19:17:38.242741+00
18	main	0001_initial	2023-09-15 19:17:38.310163+00
19	main	0002_match	2023-09-15 19:17:38.332998+00
20	main	0003_rename_date_match_matchdate	2023-09-15 19:17:38.341727+00
21	sessions	0001_initial	2023-09-15 19:17:38.3593+00
22	main	0004_matchqueue	2023-09-16 10:03:36.837773+00
23	main	0005_teamqueue_playerqueue	2023-09-16 10:21:27.902129+00
24	main	0006_remove_teamqueue_league_matchqueue_playersdata_and_more	2023-09-16 11:30:09.517086+00
25	main	0007_match_accepted_match_players_delete_matchqueue	2023-09-16 13:08:29.394221+00
26	main	0008_remove_match_players_participation	2023-09-16 13:17:03.85513+00
27	main	0009_alter_player_keeperpoints	2023-09-26 11:10:18.445242+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."django_session" ("session_key", "session_data", "expire_date") FROM stdin;
9ce1tqs9aevyu56hvuj51186gkb7zntp	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qs81d:5V38VhGZgCl84fKufeSvluEAhs4kAyG3CPxJQNW7xxQ	2023-10-29 20:47:49.622276+00
c3q3t33hhaisgy9xysunhq8glwjlq0r2	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpCS3:72scdGsANgRvIPFdWp623K3DejwBbBi9KivJuFfUrbo	2023-10-21 18:54:59.734697+00
d4hrhpmpetl68wjmskvfwnp2yxab6tyq	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qzgHv:w3wzxiaGlQdCo3uN9YkdECHyVDXbYjGXuCGw3I0HPoQ	2023-11-19 16:47:51.107655+00
hx4scp8dkk26k4w1ni80vpxgpu3cxtkc	.eJxVjDsOwjAQBe_iGll2Nv5R0nMGa9de4wBypDipEHeHSCmgfTPzXiLitta4dV7ilMVZaHH63QjTg9sO8h3bbZZpbusykdwVedAur3Pm5-Vw_w4q9vqtHWQI1nur_UhmLMCDUmwCKQKFTumiIXsVygCuGOJsNIPGBMBoHXrx_gC4fzc6:1qjjD7:-PIC037Zt4OBkLDa2gOC4UkS8YKoXVxM9kRDVH2yfFg	2023-10-06 16:40:57.056974+00
mxs7bdx0sc0amweyd1jjezxr5fnhy5lf	.eJxVjMsOwiAQRf-FtSFMcXi4dN9vIDADUjU0Ke3K-O_apAvd3nPOfYkQt7WGreclTCwuAsTpd0uRHrntgO-x3WZJc1uXKcldkQftcpw5P6-H-3dQY6_fmlAjWwCnbTKGYj77DJTQAZM2AwzeK1WUZUBkZ01KhTRmXRSBomLE-wPPXzeb:1qiBZK:0GWHGoMjDu5mKU37koFtNxSAk2Gnhu3xLVEoG_9QoTk	2023-10-02 10:33:30.996454+00
yt8k0cquxdgb22u5n3oq9gast1g4njm5	e30:1qia1A:X3rn02noHUuEickxCgQIbEk0LpmAYZV7DWtGxChB_Q0	2023-10-03 12:39:52.789751+00
r656w0gblthwh9546i61yyt1yxn16lcy	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qkoef:10DVN4URegVcr93UI0O3p1CWcXrf48-Ip4xxw_wSEso	2023-10-09 16:41:53.210899+00
mjkj05jwe8krvst8chjthb68jdxzqo6q	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qkotc:AgbXnr53voLeYAwGMXWiJybctYDZm6_J9UP53G4rX5o	2023-10-09 16:57:20.637467+00
4vjyxgykk73n2kl4xz628ru482dukrwv	.eJxVjEEOwiAQRe_C2hBoAQeX7nsGMsCMVA0kpV0Z765NutDtf-_9lwi4rSVsnZYwZ3ERWpx-t4jpQXUH-Y711mRqdV3mKHdFHrTLqWV6Xg_376BgL9_aAhilFHvFOCY03nBESyY7VJytY4YhOW9HFQ3BGRDAW0cONDKlQYv3B-C8N-g:1qkS0H:kxS366EEorpm8M3wtWPKWmgQZnPra8wqcoYc2kfQucg	2023-10-08 16:30:41.34709+00
iv447axtiox2ng4g17pqjnc1m2b62a8p	.eJxVjEEOwiAQRe_C2hBoAQeX7nsGMsCMVA0kpV0Z765NutDtf-_9lwi4rSVsnZYwZ3ERWpx-t4jpQXUH-Y711mRqdV3mKHdFHrTLqWV6Xg_376BgL9_aAhilFHvFOCY03nBESyY7VJytY4YhOW9HFQ3BGRDAW0cONDKlQYv3B-C8N-g:1qpb1h:S_uvfeIwC5PTD7D_2aKgzNFVAjYXgbmt8aW2oeEzRZU	2023-10-22 21:09:25.69058+00
rr81j395aojc5c2utt0l6pwpcqqtkdo2	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkS9I:QfWqjVq2XHZWbhPwionXMHCQx6obLTvsv6dhOqto4-o	2023-10-08 16:40:00.646618+00
bvcnnr56puofy5xqcfpw1yr506sj7at0	.eJxVjDsOwjAQBe_iGln-fyjpOYO19m5wANlSnFSIu0OkFNC-mXkvlmBba9oGLWlGdmaenX63DOVBbQd4h3brvPS2LnPmu8IPOvi1Iz0vh_t3UGHUb62NcCRJgAQZrDJTcNEZQOuDKNYJixKMhoAFrVCoAiitlIkxx8mT9-z9Ab4sNuY:1qkq1Q:Tvaqh1Ycb85Qu38ch3W6HEcxuY5uqO_jfecIYmzmyjY	2023-10-09 18:09:28.626112+00
j6053erzt4yatm01w3yjriwcq8nm74fm	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qvjKx:PLyXucPGf8o2Nv35QPyRqz5ZCh0SKtDo2przpFpoA_Y	2023-11-08 19:14:39.133412+00
y1ucuvnq44sil8eo0b2ak27y3djpdsvh	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkSFF:zit4KFCNfWH9GTUb2fX9VjBKpuyy4Ko4baJei7f2ZGA	2023-10-08 16:46:09.435653+00
issm67dp103kmqqnwcnsh40wseqdd0vo	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkSFj:V2De0JAvnxWSS08P-Wk8pXjYGLtPTfJ89legS71hpcE	2023-10-08 16:46:39.860648+00
9p4mj3fq81jlzbz0w4ryzlq7pr66kfg1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qn3Fh:OlHssop2zB4B40oNXmJRpNY3hgX7-zGe5bqF9bYShBM	2023-10-15 20:41:21.599138+00
njmzxnm7xg068srp8fyletmfxyeoq1ik	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkSbE:W7ewDSuw42obvx1MWT4XVnirRrfahlnTXcp84zd3XPA	2023-10-08 17:08:52.71922+00
6c6lt58cbwyf22y5kgazq9jrcr1ckoc9	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkSmF:O_-PD1D9xfTS_JdLxIZjl0ltZrpEfRuJIg-vcFE4yXo	2023-10-08 17:20:15.141145+00
4d8x53s91awcxmpt3certlmkgjgqzas5	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkTRz:bPwWH6HZmZWvac_s13Bc04jNDPsYGDUfahKHYg1bpw0	2023-10-08 18:03:23.638338+00
sgrr4qii7aurbnh5gofntu5nya5arnk8	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkTy8:lIjhxIcdWglhiSnxkX8Ur6ZLe2GLsgegobNEqph4-eY	2023-10-08 18:36:36.211557+00
ombkvp9cdfys83yptzga48k7j8qygjub	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkUNa:akodlna02m9O8Stwi1dYdDznzIE3-VxnyEA5t4Exh8A	2023-10-08 19:02:54.95613+00
e8a9dwftmtvrs0ra156b1qiywqfaa3ib	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkUNb:JlEhgi-Hhit8oBkEUuHviwUAt0o5eXRFwbpLyqm1PB8	2023-10-08 19:02:55.946466+00
8qs3wqrvzfnifdvgub5d85e58ah1f8tb	.eJxVjDkOwjAUBe_iGllxFi-U9Jwh-osdG5AtxUmFuDuOlALaN_PmLWbYtzjv1a9zYnEVSlx-NwR6-nwAfkBeiqSStzWhPBR50irvhf3rdrp_gQg1tvc46c4iK5wmYquJO0BtjdGDJdejQxVogLE3QXnLRiEG57Q2ruHABlq0ln0l31rAnPIiPl8LGj4N:1qibvn:EwFgMnpeDWwmPhXctsbl0TkuAqGEFhfMwQN5AogAL7M	2023-10-03 14:42:27.13076+00
gb4b4k6pqdig3waarl2jeeoi7nx4zfgv	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkUyz:Ye91hVJIv2DOKDwNIVzqPYZZsFzVaXl81w44Hv6i684	2023-10-08 19:41:33.415666+00
yi4bvexrmorr2byxh78nhocti9sueort	.eJxVjEEOwiAQRe_C2pDSFgZcuu8ZyAwDUjWQlHZlvLtt0oVu_3vvv4XHbc1-a3HxM4urUOLyuxGGZywH4AeWe5WhlnWZSR6KPGmTU-X4up3u30HGlvd61KazxIq0DmxN4A7JWAAz2OB6cqRSGHDsIaloGRRRcs4YcDtODCg-X-OAOCc:1qjfiq:Vtu_dl1bsI6TlqZPfht6Jeqhvj0aAesNzEHqxE42vc0	2023-10-06 12:57:28.807523+00
f90pa4ti5b5e7r4lkr4oewjjhsi4fckx	.eJxVjEEOwiAQRe_C2pDSFgZcuu8ZyAwDUjWQlHZlvLtt0oVu_3vvv4XHbc1-a3HxM4urUOLyuxGGZywH4AeWe5WhlnWZSR6KPGmTU-X4up3u30HGlvd61KazxIq0DmxN4A7JWAAz2OB6cqRSGHDsIaloGRRRcs4YcDtODCg-X-OAOCc:1qjh8d:ZN6e_lJ8OOY_Iqb9YUhUBNj6ZChtgWfuc_Y0u2AIvwA	2023-10-06 14:28:11.800418+00
3vcwqn4agnomfqe4hjjnnatsg7m2541e	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkV6L:MMrdCmKsH-u0zHx5-nV9PVAW7nxY7JIlkCvhNVH9cNY	2023-10-08 19:49:09.849312+00
kgbqlwaacxbifo7bjfndoami6iy1gkah	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qsJIF:Rn6yUlwoY0nKmVJKHf1vQ5JoPn1c3yg8FbmBSfZoUd0	2023-10-30 08:49:43.089185+00
hf0vjhph6qbdsyw7fss0gwrtv2yd9o3x	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkYw5:ZqavWNZC9RIxT1ZCuXy1FhbPscw1ilBd4asnaLPnm_c	2023-10-08 23:54:49.709694+00
gy4km4a34zbu7ok7tdq8ettjjo6dy8t6	.eJxVjDsOwjAQBe_iGln-fyjpOYO19m5wANlSnFSIu0OkFNC-mXkvlmBba9oGLWlGdmaenX63DOVBbQd4h3brvPS2LnPmu8IPOvi1Iz0vh_t3UGHUb62NcCRJgAQZrDJTcNEZQOuDKNYJixKMhoAFrVCoAiitlIkxx8mT9-z9Ab4sNuY:1qko0G:LwqvKZyn17QBaSyoC-woO9TThhM0-NJV-SyCJg0JZdQ	2023-10-09 16:00:08.488434+00
0vvmgqzxg2aur09cnmldax42f374a40m	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkYw7:evuW9BKSym2fT717V_RsCEF4Voqz_5weIoLz9EO9C6U	2023-10-08 23:54:51.927848+00
dkxoi5ctiqnrzr0oj88u5bolrjdw3g03	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qrFWX:cSuicf6vr1sYOcjr8LDy7J48uK2wBvyjTFdSRhxPFgE	2023-10-27 10:36:05.388531+00
ohmahj65yyep1ks6gl0cpeuhsg2rjwf7	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkYwA:KxwmzZz5goDy31FpLFLxX1nfbshKXk68R0h0ZlTi0b4	2023-10-08 23:54:54.132577+00
hdf9bw8k996w7epf1sb6soshwlnyuv6j	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qkoiD:y9FqzI_4Iev6tvL6TIla6n7gVY2O0Tkm0gkWUeX_Cqg	2023-10-09 16:45:33.530074+00
8e1ds6p297woljfv2ys7n1yx4hrmikvh	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkYwC:P0Bw5PsJTrpMtILBb9Tv0jEXjnJwFbMVf2-lWeFdvOM	2023-10-08 23:54:56.326676+00
qran745vkkvnla4jakd97k2v2w1hgyxh	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qkoiF:K29K6-mezuWLHvmL3J3h38K1McPd0vBvUGwQqZATciw	2023-10-09 16:45:35.022576+00
4mrfy86rwrqeymtkq14opr98oavpzq3z	.eJxVjEEOwiAQRe_C2hBoAQeX7nsGMsCMVA0kpV0Z765NutDtf-_9lwi4rSVsnZYwZ3ERWpx-t4jpQXUH-Y711mRqdV3mKHdFHrTLqWV6Xg_376BgL9_aAhilFHvFOCY03nBESyY7VJytY4YhOW9HFQ3BGRDAW0cONDKlQYv3B-C8N-g:1qkeTJ:DAlHP6ClV8GWpUQm3V1RocTARCpqs80lsir5PkL6MxA	2023-10-09 05:49:29.494383+00
sbu3w8jqjokpov2i9p19j5e3nqhm2apt	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qkojn:N3T9m0mFUNgAXAHsIuI3u1C3dmlJe4HNzHqdsSJTGek	2023-10-09 16:47:11.276418+00
6325yo4wyb0yaphhfu3cjtbnh2f3dt94	.eJxVjEEOwiAQRe_C2hBoAQeX7nsGMsCMVA0kpV0Z765NutDtf-_9lwi4rSVsnZYwZ3ERWpx-t4jpQXUH-Y711mRqdV3mKHdFHrTLqWV6Xg_376BgL9_aAhilFHvFOCY03nBESyY7VJytY4YhOW9HFQ3BGRDAW0cONDKlQYv3B-C8N-g:1qkeTK:0uKdCqkM-cpAsRMGUzdke37YLGE7MfWF1Y7PT3MFKIY	2023-10-09 05:49:30.091822+00
vdca2taikxjwj7ksqc0mx3dyqjkyh18k	.eJxVjEEOwiAQRe_C2hBoAQeX7nsGMsCMVA0kpV0Z765NutDtf-_9lwi4rSVsnZYwZ3ERWpx-t4jpQXUH-Y711mRqdV3mKHdFHrTLqWV6Xg_376BgL9_aAhilFHvFOCY03nBESyY7VJytY4YhOW9HFQ3BGRDAW0cONDKlQYv3B-C8N-g:1qkeWK:GrpnPvCiPvUVmFJGB-oEfZgrvyC1VXl4psTXfZQJGj0	2023-10-09 05:52:36.289302+00
eoho2yh5n2y7t6wapsjtinnx4tfbyz8h	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkgrZ:6dXXq50kg7T1GZcI9LgHTRF6zzcXDLO6ShUWutOOfGM	2023-10-09 08:22:41.067678+00
heo9israyrl2bofzd1oihk82amzd0beb	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkhbZ:0PkgIQWkul7-XoxxB64Lz_0-qZwciTrkPOY1scOVFFA	2023-10-09 09:10:13.055667+00
5fub83hkpdbcqx5gk978k1q2u39qjvo1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkiHQ:Pzh6IhLjo1W8LaApim34SFmfzDu8T9F9bcHfEY1jSXg	2023-10-09 09:53:28.892374+00
461dyotm2jbsi3xa2soctocassvvvpf4	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkiS5:Nd5PYTrrfCIumlUbwj_PUVIdu8e5MttPzSN0WP4srdE	2023-10-09 10:04:29.083612+00
ibaj7i33xsv3ozudbc1wjtmoy0ni0aqs	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkiS6:65Z21vGBnKv3_5F0mjaZKI1M9Y88RjvdW6wVZ-OYJdk	2023-10-09 10:04:30.988164+00
jb2pem5g4ax7vnru6pz22mcgcvgddvak	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkn6v:MZK9HkzVwpSPp-NHpQ3yH9rnYu0mS0AOw3QPKAdusB0	2023-10-09 15:02:57.562148+00
ducelvo7llvpjy3aw4t96zx0kl1xylew	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qmWIv:0drXX7f74ChxayPOo4G4xlzzpMbFUXryBKMLyRZMlec	2023-10-14 09:30:29.495249+00
tsrft10gzusaq4n0fpav740ywfxm1qma	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qknHI:zfc36STrrTpbQt6VDfU9Y9oxFV22YrM2KaC1i8eB-LY	2023-10-09 15:13:40.462055+00
hu6ot4xl3ib9aw7584mcn7eobv4o1dc1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qnJfi:S5dBuYAn0kkDNTJRzTRKeZm3svkOxkiMYJd3aRnBCTo	2023-10-16 14:13:18.071088+00
j10k8ejkhs4d1y9jukich8ixd7b32ck8	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qknOx:8GFfTp8KReMYsW0v5-5uXKqKvfNU5MGAV38J_HY0eUc	2023-10-09 15:21:35.660504+00
p2qb93gild0kyxv4r015u9yqdhkkle89	.eJxVjDsOwjAQBe_iGln2JvGHkj5nsNbeNQ4gR4qTCnF3EikFtG9m3lsE3NYStsZLmEhcBYjL7xYxPbkegB5Y77NMc12XKcpDkSdtcpyJX7fT_Tso2MpeZwCrwFrdE-W-c46HHn3q9A64Y2Uw62gUA4A25DNbdCoO3qeY3WC0-HwBzPw3dw:1qknU7:J7TdR5ZA3Kz6tkbWwzd45A3vQvVZ4NBhk5BGKreMSzw	2023-10-09 15:26:55.662803+00
wqdz2rtd4j5mpywmtafultn6i9jcneik	.eJxVjDsOwjAQBe_iGln2JvGHkj5nsNbeNQ4gR4qTCnF3EikFtG9m3lsE3NYStsZLmEhcBYjL7xYxPbkegB5Y77NMc12XKcpDkSdtcpyJX7fT_Tso2MpeZwCrwFrdE-W-c46HHn3q9A64Y2Uw62gUA4A25DNbdCoO3qeY3WC0-HwBzPw3dw:1qknX9:9rERkv5QRLbvgOtHcdgI8hQ2YrL7Iez799ka4x79Bl4	2023-10-09 15:30:03.335324+00
e8uwce4b6qdov3k49z9n0xkt048jaxqu	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rDBiw:c5Ll_5wUqSnab4MVTA4MUGMUegO4nGXDhYTO4LkcB-w	2023-12-26 22:59:34.622908+00
p4yduyqa4lcvaljq8hrdrffmtcn9dzo5	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkqIg:1TSGC_Xzq6wPliHjL1A8nSHizSss_AdK4NH1uQ2IKPg	2023-10-09 18:27:18.055206+00
cnv4wgc60pdopnr8ievn2y1ze24cqm7a	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qp4DY:vHrek2b9oao4pCayOf3Uy5cpM6PjrjLOOm0PFSUlGxc	2023-10-21 10:07:28.701862+00
aoef61avsvafj021ldj5gdb0vczxxn0v	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qsN4F:x0dP9aDj7rGE3UgnY4kvrcv7TUFUJR9_BoC6f1arFo0	2023-10-30 12:51:31.495001+00
02z6n1e1r4t073m5kc1u37emb0q6qmyw	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qp4Gc:KXyNK4tycSrWWy_v4-NbMt3FI04P22vXjPTRHcsKruY	2023-10-21 10:10:38.89946+00
lqmsi6i9qsd3oaipk06b5b80l74mxv3u	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpVkF:YrgS-KC1pcz1rzKOErRw0Kwv-S4zrbavayWp1WWA53I	2023-10-22 15:31:03.71978+00
n0c8ifczeh5qvekqtkd9bxonlordjmei	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qsN4G:Owakhw-Hff7SrCcj_93pnHMx__XRq82Lj5-Qd_p5e1U	2023-10-30 12:51:32.429881+00
4gfzrfh2oy7wcvywl6lgsrbp8ee0lkhm	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpbdX:xvRpkAhdWAKGDUWKe6a_vCndr_eWF_GU3WO9a_X_F24	2023-10-22 21:48:31.491595+00
hijfdh6v3lxza3ruw0ovx900gnvkknyc	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qppfE:8uboQGq0yKeEJuse0Z8BtX2n0yIQMSToXpHjUrD6oa4	2023-10-23 12:47:12.618391+00
wvg8pm5hpwid8z6wwxayn4ib6f6ng5t8	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpxVR:z53ei-Aq3UgicJOwDII1QoZSf21FOhlerH-maCih120	2023-10-23 21:09:37.591712+00
enmss58xrdchrc6flfx7nnezlb1nvkpn	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqHYq:NOruHYtfoBq28m_yS_lMkYw3SxHXsZ2ecgoC4QugvAw	2023-10-24 18:34:28.161181+00
x4vywkyjul49aupb3rmherp3rnmwmum4	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qtVXq:NMJoSjiTmHNmYAqBcfQPbA9CG-HWTHYiLgDv_UAHxP0	2023-11-02 16:06:46.253587+00
321cp1vfd1ghyko8sxn3j3kusrjcom3h	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qqYva:hsDlJ0aELWDqkGVbk81Y0pLG1JcOXg7UMLC1BDFum9M	2023-10-25 13:07:06.684859+00
qhi1v77h8ovrp3jiy4ho853s59pwcvv7	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqbjm:9sgL61IOHzoZorVYjiYipPA8se99RgWiVhhUejUUUwg	2023-10-25 16:07:06.202863+00
34eyd6sme0wydahwkov4aj31oi7zs286	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqcAq:_AwwDFfC0GbJHA1m2Sw9dRv-WHpoVDlvu5JVtkiDo1Y	2023-10-25 16:35:04.999199+00
cbw89d28l8hipq03by2794omla0bv7nb	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqcAr:c3rGaS7jnMqbhVdK15aPCotkAeNklkUdUVIW2zhzJYw	2023-10-25 16:35:05.718909+00
fnvfg59k1lf55gvywabg9evrlo3j4gk6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1quVBj:JurupTLTN2klrrVlNSVqJHAhcmpTDHliDFQI_g3ucmo	2023-11-05 09:56:03.443376+00
kf73j371pq5dfe4nkgt4saxwirb2ruk3	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqxmu:fp2XGUW2uClAw4rw0Ie6kPovElh5ni-SJu3abpXQN6M	2023-10-26 15:39:48.290989+00
albj08d52t84n934f0mj1v0rdi4ptf8h	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qrJtf:0HkNCC9N2_B2GaqZxAaKcKCHcQuBLt9gq6-h2qMV7BU	2023-10-27 15:16:15.805842+00
urb85fvhjdzlcqskyovx7bibwi4gfrm8	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qrkiL:-NlZRjFxoBTrH4oJsg3mD7zFpHcUdlhtOkVaCc9f3wk	2023-10-28 19:54:21.744829+00
cl6ps7x2iqgmo8tn3p98zilbub6l3dk9	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1queUD:2AeXKF3JPNb5GRPWmrYPq8pnuJfUR8Ggg6zotFgZFf8	2023-11-05 19:51:45.038945+00
vdp64q543bkks9jea7xk8m9urdwtico9	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qs5jv:zP-twUfrnSUzpUqDf4BnAGbIKt4oMaTYKTcXe9iqhms	2023-10-29 18:21:23.017063+00
8a2pmqi31jfpxdjbahm6gf1ex0iwn513	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qvMVf:6taDQ9aEZwRY3SHo7JGI114fS79JETe08g8vu-lrIko	2023-11-07 18:52:11.653219+00
2kfi5ucvc4idvdyygoj709g0vth9jlwr	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qw9gh:fdETpqkorCyQeeqwuYlZ9ywZJ819G53__NufiqPXh0w	2023-11-09 23:22:51.132638+00
uwbk76sp7t090n9a4bheh73elkbnpegl	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qxBI9:w-I_wIRTZ2hqUxWX8pXA5IMRe28FOq8rshD-GuNNy8M	2023-11-12 19:17:45.077356+00
gfvo8kovv1ym7fc9aqbtmhten6sfbhes	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qxDLA:ygm_ZIJhiQdai2j1Fa1OogZxIMBHj0naYF3CySms5ck	2023-11-12 21:29:00.930812+00
7yp94j64uraplj0x543paxfb2cpy1vp6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkqsH:1_qMVA993YmLngaY1AtJORdqKbUiDxbCSWmdhL73f-g	2023-10-09 19:04:05.051759+00
ihok0agg151aemomwub1s3kadk8qcknr	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r4exn:6D4OITSlOTakPfbJ7WjqymDHMbYLaPXg68RQBJ7SLg8	2023-12-03 10:23:39.626092+00
e06l3x2tiszwj7lfckxpq2ouvciq5c5d	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qkr5X:9UHkGef4nrDQYxkOmy21xgnNadlVfjF4j-eJu5qzot8	2023-10-09 19:17:47.41462+00
g705bb16n06ufufb8y6oknc0jhihhgw7	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qt07a:7yEtD6Bduv7zaw2JN-FRYPjTlpjggYFIB7h5D0fXeYk	2023-11-01 06:33:34.510611+00
p44w87xfcllgl2my48krh1b9kp0ftv2w	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qtBX6:1fvtYmSLij_SYuqR0dafBXpUHfZSWrPJvIIN7HuIZ2U	2023-11-01 18:44:40.282643+00
w1g6mqvq4lnde29ctvmv26eytwfurxsy	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1ql5Qq:wKbmdRxPBZ4FwldU6e8D8BDctWwK6SsEWDqcd2XmLyo	2023-10-10 10:36:44.351675+00
686rqw5yxphxh3juqm3z9k5vqg5n9ode	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpVbe:hdCcjfeuUwygkmLGCzFxIiwp2G1W3FITMCjzWkLE2UI	2023-10-22 15:22:10.355003+00
whr39mqor2tiecdr2vv3h1y6rpgk6gvk	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1ql5nW:tey1b7WRX7ibsIzn6A11d1ORscz3epSF3F3tTVg0N-8	2023-10-10 11:00:10.248176+00
ibf8fjpvs8brzai62liavkzolyowldzx	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qlhTv:Gzqgwmswp-DcZuTFd-r_rC2vRFXltkvW5C1QIX-Ofs4	2023-10-12 03:14:27.477777+00
f9oqc59rgz3fbl5xzkm4xmvukces5hge	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qlqyH:3lNQyHcqlD_oBGvSNBRFTtE2f_d5cfqc7Va_A83bAME	2023-10-12 13:22:25.250609+00
09j9g3th1ks2977cgpqfzzdp9iptprko	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qmY96:18Ep91s2P-yljCB_KDao_qalaAdKjy7Ih_b8f3BDJPQ	2023-10-14 11:28:28.557753+00
582ldt6etdrvn3jgfuzntlgigt5nunle	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qmYrQ:kqAetFHkbSzBu1NPOsMhdq1oWykdk4YfJZbgahbJ0Hs	2023-10-14 12:14:16.553505+00
6tom7hn8jfxbyps0iwk3iwkn8y4ovguv	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqxqA:71QyCpgVZ45bnBcLQkmxvEkLzrAeZIgcvL-zv3G4pXU	2023-10-26 15:43:10.677133+00
nkum5natowq7ulk3fq9iwxrn8q0j0lqs	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qmbiz:l_bdZ-wGt_anVskf9mS5NiJLH5XxaoWVEmBWA8OH-8k	2023-10-14 15:17:45.015254+00
6zxlo0lwjar99923xvqtsvnhao6xnc3q	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qrJmQ:XPgSQAf0bAVW4zSmEhbt54m1EoANp-LFOgoF8Yl8bAw	2023-10-27 15:08:46.793289+00
5ab6115zfjvdeyyku6o2e45rrb97dpdw	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qmhhs:oYFwvl313nf5dBewsKKLVGBNf8UAmV0FMus6vPlok8M	2023-10-14 21:41:00.803916+00
myr84r6ytlesko0ruumrm6plgp851dtk	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qn0Mx:0Hon7UxvN5KCcL9gmUrAi0NGcZEpwRVbCeAWVt0GFVA	2023-10-15 17:36:39.099718+00
3pobpexuncclk628auuo36nluhuy6q7m	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qn0Mz:MWk81RwnsG6u8UNwDl52pcSge8YO7b5_7kXJgK4GOaA	2023-10-15 17:36:41.200714+00
o41b3tvh6trtjoe436lew7429xknvov1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qn0RL:6jETHn452CwnGZcsCl7MXfs06h2ZWieLshiJ_e4iBBc	2023-10-15 17:41:11.287869+00
fhb07bs5ykjwxtnyseurcw6n8qajoxl1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qn2pq:wIoaBNJNUH1zd5lJTVibVbDyeMYrrrdc6kuRpqQdu3k	2023-10-15 20:14:38.635894+00
vit236a4pcpo37vtxcze8f971q82tpkr	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qn3wV:2hsNk_6XmkGQ7yhnRekBCPMtKVzOdghGlaskV6lYr30	2023-10-15 21:25:35.774281+00
d53tbi2hgfqle18qwf9tg5nc5i4atd76	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qnEEw:oEfDYsXVuJyt4lBn6J1VRD5qr3tratXYXANykKnv0Q8	2023-10-16 08:25:18.440975+00
rrcla1pq3fkr30fxqs4ll918vt0l8bs6	.eJxVjEEOwiAQRe_C2hBoAQeX7nsGMsCMVA0kpV0Z765NutDtf-_9lwi4rSVsnZYwZ3ERWpx-t4jpQXUH-Y711mRqdV3mKHdFHrTLqWV6Xg_376BgL9_aAhilFHvFOCY03nBESyY7VJytY4YhOW9HFQ3BGRDAW0cONDKlQYv3B-C8N-g:1qnGtJ:N94lfBJUH7M8spELnk9sFKHTW8qT1sb5tmdn2PruACM	2023-10-16 11:15:09.072296+00
u0sw0sv6sgkolvwfan4iuefq1xpztgnz	.eJxVjEEOwiAQRe_C2hBoAQeX7nsGMsCMVA0kpV0Z765NutDtf-_9lwi4rSVsnZYwZ3ERWpx-t4jpQXUH-Y711mRqdV3mKHdFHrTLqWV6Xg_376BgL9_aAhilFHvFOCY03nBESyY7VJytY4YhOW9HFQ3BGRDAW0cONDKlQYv3B-C8N-g:1qnGtJ:N94lfBJUH7M8spELnk9sFKHTW8qT1sb5tmdn2PruACM	2023-10-16 11:15:09.768195+00
2mcjrgokcc8es0xhjqde1nnejlk5pla2	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qnJxn:VtcRk1TA1TG1GNlOYtw8QTsVWRwtW94U_BUp7awVLlU	2023-10-16 14:31:59.659084+00
pas4apqpxp6fpwmuq49rw0g8qxcp0yv2	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qoKN6:eE4Mb8j1e9Kfi8xXG4XVcpTujgPo6SzLpHoheOPqS_g	2023-10-19 09:10:16.864495+00
uuphix0ucddqg32n4ui585re8igsmfcj	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qs85k:uUuwC8El_nGv8mD-8s3gARZRq4rQ-aFRrEgmzB52xa4	2023-10-29 20:52:04.329958+00
zu9kpjra1re9wphiom79o5sz5gzopen9	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qsR9s:z7TTNeILp4m2QQzn5KawgCyNHhQNQexRRjMHBI8X7vo	2023-10-30 17:13:36.138213+00
a4admhndk47osvloqlig8elmqt3dbcv8	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpXTJ:pZ85m05vElOW9IhNSk864QtcySvM5TD6xh6Kn-V8RHQ	2023-10-22 17:21:41.96868+00
7y107gcuhytxtp1nu9iwnywfsfsrryw5	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qshF3:Nn_nra_1RICDh4J6EhzmUYfimf4jdzi9fUdKIcG6iWM	2023-10-31 10:24:01.207173+00
tkf1zj08g7hkcodbcug4hlgf87kvypfl	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpXZh:yby1kBC2Abi8ookZE9FOmr1qkqpcs-u5XK9OM40wLKU	2023-10-22 17:28:17.165416+00
vvb7bar2b1o3hwwlxndhm2kj3bmixgse	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qzc5b:RQeUfsIoZFtFyRTrOFpOTtCRbPUe1gfexm34m57aHN4	2023-11-19 12:18:51.090576+00
lslw79ii6pkpyie7qx3bqanzb5yw0vjz	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qt0UP:vJ5GYaj2mzRfuTl0m7VfTPPjCbT73-abBhMIBMTsr90	2023-11-01 06:57:09.22541+00
xwrz2plb5mozc4n4abr1idzq253h3pwm	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qzjMr:C0sFhF7KH5-ZeoUIkoJv19BQ3QxQeQARNOdKyOIHeW4	2023-11-19 20:05:09.71947+00
2zllt94t4m5jp859osm7qchl8ag71sit	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rSwmX:cBRbj--7tY9TgyyKUWPDbX6-7BPQpIgSufRvpvLS3_k	2024-02-08 10:16:25.573562+00
v2ft5xjq03yl0u7gswbuex7lfpw6h3nf	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qpbZX:gFcHIE0VHiXeBP_qY8jOBA6uAT-3EkAQu8FFL72MbRs	2023-10-22 21:44:23.317146+00
acxhopedg3mv09t0eczrne0706qkkb5g	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qphQv:LtJHG_HN0I2GpSKjo0JG9MErZBHcq1xbMfEi9_xHVXI	2023-10-23 03:59:53.482628+00
eqg6t68nw8y6phqsl41hvnwsmf2eonl6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1quIXH:k62_nKrFOKzwgPxLp4HMoWH5FAVaqp5t8uRlWGupLJA	2023-11-04 20:25:27.44056+00
o2u4n1982x0u3asw32hm2nw8x2sq1uy3	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qphVP:ANO4Hu-uE1fpvOJ5WJC1OvbSIiEd97GcFCV7AsWmTQw	2023-10-23 04:04:31.389365+00
pehsj2o5m3i0bsd35dxq4tp20em1zw8y	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1quZaW:A6RVkI46U9QtjWT9TuhXgQuHqNIIPYekeGheOU7Zat0	2023-11-05 14:37:56.466128+00
b3o2z5ucn5tpjhnvkmktq6gqyarfrqm6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqDc8:xR4hXzw8J3avfvhmAShKy4jzxZcN8f2eTTmCX7d94S4	2023-10-24 14:21:36.359685+00
uhw1uqehu3i08jm51jwsh2kdq7fjoz3f	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qqYqg:mqyNquhqoK1hnsgijfgbK_mTxPoUfJFM18VS_hz-iJE	2023-10-25 13:02:02.808779+00
dgwnmu6f3a2nl8eb06s83flqdybtzhjk	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qua4T:onsGr5YT7D7pp1TaUiW7cWm59LiSbvU88ybGRhyq1-8	2023-11-05 15:08:53.768267+00
can47et095ce2d4toh13qbywze2ki2lc	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqd3x:pMmlxO5KwUjvZ5lGxODvB7i4hlZ1EpGzvj7gXTUOLeo	2023-10-25 17:32:01.427974+00
ck3gcrcgxdvrzdhuo3h2znql5uhrgx0q	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqd8L:sA_hh9YsnD_mxCJzPb5_krltrJloMbkTI35zLQ19Mns	2023-10-25 17:36:33.227075+00
gfyf9bkmz4z0gq1dcj8cm0s9srh5rt5v	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7Gx6:SRH58VNT9ZLIWI6nDc9E5WW2kRhNzDym1dHTMPoq6Ao	2023-12-10 15:21:44.833088+00
hqumt1q3wm191orzp6wyt9o73kkuvhxo	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqd8M:NfxZFFNrWuAm-5IO5OYyjLT6aHhjJBokWNz4E6aggHM	2023-10-25 17:36:34.001163+00
6rz9bkvfgfkt1njqgvc67ditb9kp7twy	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qqyqK:ESbzpl8cv6gIGDDYdusrL6qv4e8j2sV2b2_kks2raCU	2023-10-26 16:47:24.621085+00
wndp0p8f9b57ifz51gs48xiid0ii3wq0	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qutDA:-53JPzgR6p-WRUYtXzLnEn1jf5HcrBTcbcT0zTKBGCI	2023-11-06 11:35:08.254954+00
gs5u2e7aroqhsb8p1wynhdl6bkclm0y8	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qvIpI:YisQjvNpDWiG-6K9hPDYSweSnM8GLFsaR2JrJZu0csg	2023-11-07 14:56:12.233155+00
b978jbh7ygfa8syp94uo0xpew6dw4ttf	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qvK5y:1oPmT3DZgsDiG7kTD944ALjSsmvKkHzjwgN0SA5dvmA	2023-11-07 16:17:30.347318+00
nyylbo2swt5dmcy4i5xqp1mf5zc5g28o	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qvKHp:aqgYFi49qXAFQINXmtCikuKOKWnl6Jye2AfASvnVQhs	2023-11-07 16:29:45.529147+00
urm9nd4qnugkqz5sodbmjczsyb09v8rg	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qvXrP:dNnCGAeb_yL_-iEctTOwcuN1jyza1jXA7g9LABWlL20	2023-11-08 06:59:23.498207+00
3g0kalcs67zv6utf7ssz4qkzc50wikms	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rT2GZ:29tC-px6yhjN0chVZKsZFh22ShR5VHFNUqnlR02ULI4	2024-02-08 16:07:47.863957+00
k0f6jmfyihn3cp6izaa5xdw5096mtf4m	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r4i1k:newCSNdAd-4c8yj-dHu49DQ9Fk9jweQdMOfscuXhfHc	2023-12-03 13:39:56.461013+00
5yvck52qlt7tom90jyczl29lkweubbuq	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rYS2y:3g7kSrVzEjKX1gDmfHMY1B4m1KyAeWpOeZ3diTYd-2k	2024-02-23 14:40:08.828837+00
z4vswl8ew8wrdtoesvut2cwavxgao83o	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rFWjH:TuROwXocms4uTvMRAM8jpk6FhrUgUOnxoVv-XOFkSuk	2024-01-02 09:49:35.555445+00
z7wlyyw7zy04yggvrzaqynztnfhx802d	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r8ICL:c_CNi828rmRT96hYlhYcfRwMRCEIcMupECTQRiLP4Xc	2023-12-13 10:53:41.054791+00
0ny3ibat7tggmh5iy4lb9iksclkqf35m	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r9qp4:NN0tvHRq2oSZnzt4gAits7sjNDmS0aQjzvuhDdbzq7g	2023-12-17 18:04:06.238411+00
twoewpl22gucrk4s0uoxq8op223dmifh	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rJU27:AZp5YD_gG50wTyPaoDFZHjPp3wvSKzA9Ta3wr5y9DpA	2024-01-13 07:45:23.667512+00
mdzfm59vqrpp5k6v6wbsl6lb41ke0aft	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rQmOU:yS6x7z7YJzEtBAeU78924knvOs8Kv4j9_jIyksd2ngg	2024-02-02 10:46:38.23133+00
o6iw3x3jxxmq1jf9ljf75edn93v3csrw	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qvZiv:tDquKkQAg7MIqggEswcec-d0qlOp-bDR76ejF2SVcKI	2023-11-08 08:58:45.53532+00
5lrcam8m8b8dlas9s7c951kcw2wt11yd	.eJxVjEsOwiAUAO_C2pDyKR-X7j0DefAeUjWQlHZlvLuSdKHbmcm8WIB9K2HvtIYF2ZlpdvplEdKD6hB4h3prPLW6rUvkI-GH7fzakJ6Xo_0bFOhlbGdtpTOGkkX0FtSEaJX8Ap-FnsQsJXmBPns0oChDUohOZ_QxZek0e38A1Gk4Iw:1r0hQ5:TCrb1ghEDoJOXLAFRF3cZTsm7z5UB1rNxLmw3kOyotM	2023-11-22 12:12:29.118812+00
jc3ww7ckgz344tiv3cekkivb7l1k5hm2	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rDWO6:REDCTMP6NwQoRpL-V-Ab2yhaOsvuDk6nbMPFbBs9dvk	2023-12-27 21:03:26.665488+00
rjjtt8ame3bauvevakod57tsgyhmq0x8	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r4kZG:Wf23uBUUGfjw4vL7tLIESmuAGK_KkkZV3DowfBR7Lu4	2023-12-03 16:22:42.564009+00
5nl6be6t4tcfz7xss35l17ei2r7602bt	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rTixD:R3xArZQQTa0sMXZQJA2SR4M_NMRu7JqNdKYU6V0TcO8	2024-02-10 13:42:39.241705+00
m5mk2htor42tfnd86axig4wqgiku6m7n	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r8mRE:Zaf1BuagRnlrF2SIg-uJSP1eLoU5F08GFGCir9li_2c	2023-12-14 19:11:04.525711+00
g81mbg8mvxaa7yrkvo0wwpdak9h5iy01	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rTj0i:hjaqolftayX4J-SrxjnIl4u-yPzmUwa6KHQZmZxGXps	2024-02-10 13:46:16.213103+00
kvu34exq6mj094pvztk08nitzfeqkt3t	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rDsvp:_6tDwAlkfT1khPOh2LBsYBbrAr3gXxUU-QSFI64y_Tk	2023-12-28 21:07:45.437906+00
saaq9b6rlc9h7ahhy985xvj6iq3ya1nj	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rEuY2:ysf0qd-guR6T6URdJsz10Nvydz8jjFjCoW1M5odBE5c	2023-12-31 17:03:26.782792+00
4tebcrj8a18lwxpk4au28vz2i3m7p9tj	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rJY9x:n6B-Z7_S0micubgu7oTienpHXS49nZEnJB0uIVZ3Lt8	2024-01-13 12:09:45.227801+00
r2sjrchb0jld60hbm66vxn59f0cvyp7x	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rWbkA:voN5KOro2LDbf1_EZV162P2twPTYYq-pK71Ib4At8Zs	2024-02-18 12:37:06.945397+00
6b8eartqzs9hu7524wjoa39k2042j2j4	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rJak5:efiyIbSJcBfO66iIXxhr40Qw70Op9kNoWbNmM4VNNhA	2024-01-13 14:55:13.415079+00
kjdk17dalvkqq1tfy5sxc8hp8ckwib5q	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rRdbk:wjS93iN6T-vO6SXtfT5_fbXK7G3RQyUei46z0xOD5C8	2024-02-04 19:35:52.717947+00
xgbkukpulky7e7t1bifqge785j3ar818	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rYp1G:4R9dM7Bq2QVuIW62Mx2_OMzXQTasG2RnG8LQTqwxFTI	2024-02-24 15:11:54.107692+00
0tlww1dq2cyxhbrd9klbw42xekh6njjg	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qvtL5:z-FqyzeomckfI1r3jOEfgbxBLSlG5IHnFtDdVV6B3TY	2023-11-09 05:55:27.982665+00
j0d9egmyppuo45h3lox2qhilzf4yja12	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r0hoE:WORY_6ycgXsT46p2Y3eAvmSTansYB3gzJOn1-NYJ7ok	2023-11-22 12:37:26.067123+00
yviqjtru3las024r0r2fymcmbw3s78rm	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rDmWr:Pi48NQG6Tja7bg3qEOq22ykM-g1Nb22zo8RCB3lagBg	2023-12-28 14:17:33.793663+00
pqy4rf6nzj0wilwwh9hq1b4eqn3oynwm	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r4ohY:zrIuyHZK_MVqTrRDbcyqpE62Q8nhtpESFlw08VrSIZc	2023-12-03 20:47:32.731984+00
xz1bzjrj3iyvn4ybuwa040d0xslp49w1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rTr45:AO7WViPJGqMYR7pDTAbn4ab8Izguh24oMfdzQmJOw6w	2024-02-10 22:22:17.532344+00
qkmit039ykr346euzgu25fokz981892b	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r9lkx:85t33Y2p5npnPBWRhrIEY6YTm1lgLJOKwAHUxyt0fN4	2023-12-17 12:39:31.63955+00
k44foi8npzjccjvodzlctk08fmt73cc2	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rEC4d:Lezep54Pdo1_Ui_2kxhlE87vXH0v_x9Ffz3T80iau4A	2023-12-29 17:34:07.363725+00
c4bxk87ntbhgh6qmno86lx4yyjqegx7c	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rKJUy:LBfVZ2n24KIXU0R5aXcg5dB8pC5yVsiKP0lrb32Dq5c	2024-01-15 14:42:36.072546+00
0xwd222wa0e2abd1kv71zivl12rqnzh8	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rRfH6:tItZqVzU9lQq-k2rOGtyBrNYwP1bAg5c8h_PaeiTzF4	2024-02-04 21:22:40.801501+00
u04cxop0ndcekztfqpivlp28iwvirie3	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZYcW:0ANOK7Mpj8HLCHDV9ieKQ5XSKRNU6lLd241p-dsmEJU	2024-02-26 15:53:24.812148+00
n9nkldkfd4w0eppe7dthayvgiw8potxp	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qw5Jm:c1KU4S_jdvZuICKnVrahoeCwSkFqg2yNdNIjH477S_o	2023-11-09 18:42:54.737795+00
dpf078wpta9w2v3zypdejyr95rjf8k9a	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r0ld6:Q2lO75cj67NP67G3QcxNHN3EKXmGnLae7tqsIwfi9Ao	2023-11-22 16:42:12.178511+00
yfbwfcydlnuw0hi9r3amp0k8nfz47y81	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rED6I:GMoYtWE87sQWpNHeWfGLVHG2a_zcm_N6l4Ooj4srhnw	2023-12-29 18:39:54.480153+00
miuelb5t3xz2xju0zc7w1s5md1dhlous	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r4pC6:K_FR1cfh4hZjczKMkZC09uUomuK-v0ZS_UjmTaJloM8	2023-12-03 21:19:06.428307+00
jc720si5450gdcsduljimcxjupf2njie	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rU7Xc:ZysLeOXQiMSZMTxdBFgxbBnatm8d1kR1TPK7u1v_zVg	2024-02-11 15:57:52.529206+00
n45napf8jc3yc4vb5r1g2hp8ei83la1y	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r9lvR:OjOwy1b2YFwXKvYah-BBF7sKADt_6mHIGHnshpZI4ls	2023-12-17 12:50:21.528485+00
lx9gkth4hqtxiygo499kxrmfgx8vyljj	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rKhtq:cTG4NQCDxQSpVLHEuqbJ_2jhxZhbqEiErZdONmffrfQ	2024-01-16 16:45:54.118099+00
846wsysa4lmyzeipgycawb6rn665n6h3	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rKhuO:Mq6ItCNikxHlpzT-Hm3kRVEz6tKOkkZm51R1sPwCLUE	2024-01-16 16:46:28.296537+00
6zacnhiku91krhkb5i9zvdci9je48mt1	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rRs28:joWVLIY40YJKuJi0Xw9yLkcRuFXDnKU_p8wxQpqsX8M	2024-02-05 11:00:04.403131+00
enekl73h4oimi3wp2mr3xda1n9pafaxp	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZSnS:T7q4ok7XUJrgaRzS9QmuUBZBh7igqAIrvd0kbuR5cYU	2024-02-26 09:40:18.278048+00
hddl6g6n2sy11u8bu523szdyeaorkaxu	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwJHE:twSkKLHPUlsZNildAYa3jqPYUemUssbQpvqB9-fey_g	2023-11-10 09:37:12.285767+00
0jquvojoi2xyf8oq6xo8zifb4qs61qyh	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r139z:xNdXzxXhn_NNFqsPba3OdoxSPxBt1AEyXcsh_FQVUA0	2023-11-23 11:25:19.54347+00
ka8pvwuvb7urtc1cy1r3uvbghfby95tc	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r54b1:DNecdgzZ2Z7l0LdmCY1oia9jR33NMM2iTMKDD2oAbkw	2023-12-04 13:45:51.439615+00
t2chrmh8o2lkkzg5nmps5v6kaqesmbdf	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rYT32:wF5kpvDrmVTjdcF24vOKa3mXyq2e1pt7M-6fNpHmbbY	2024-02-23 15:44:16.682102+00
8dkuj1gnlxvo7efofdc7py7p8y23am6x	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r9nM3:L7cDBrFocLx2eOsjAg_W8QoIxGxOg15RVlcGEsr_E70	2023-12-17 14:21:55.520609+00
9i0wpk2icta23auo5prbei5zr4exh0c6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rLUJO:7p29dWFA-aSrQUHajN9twKqhF-BpJL398_xXDdG2Z_8	2024-01-18 20:27:30.498066+00
i9pbchgnuol4724js93c8o990lbsxgz3	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rMAA9:wqEXoGoedb30C5sfFe-1n6YMMyVtk9P6tkMA-3bfNW0	2024-01-20 17:08:45.279469+00
bksls7ja9ixrrtinztmzj99mb61kf4b1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZJCl:MlzIr82tKRVPNapYbf3NkpEFmPaCFxvmGXYxckAQjw8	2024-02-25 23:25:47.753093+00
iyhilpu04enoaf8caqf7o2lu5v5v90j6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rRs7H:sSOQjzT1AjFP0wJsgQbZY5BRV3m9EtzJW6Lxlvo2v90	2024-02-05 11:05:23.196284+00
2z8zwn5chkfa0qripusqtlfat6y46rst	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZJCm:mkuG0lH5bOdkfM4iHYOlaRzms8cyfFz-YnbrbKsEpWI	2024-02-25 23:25:48.7607+00
as290uof4o5z6txzkxyiy7o7lpnuck7d	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qwLTp:XeOTatDNVbpEn29ygf2N0SWa1z0QikFn8tiMy37xFpk	2023-11-10 11:58:21.688918+00
gsp2qgq7d2losj1hywqr42263hfkky7q	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r13TV:lbav40g4rXx-gTDQ9YEHkbdkLqP09US-v_o7VgQfd9w	2023-11-23 11:45:29.458589+00
9un15j7em9otpl0hi5j9hcw61g8ykh8i	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rEnCH:JFaz8wc0p4BJ8BJ3rNPVTRQBHDwX3fpKWCaZ5qvs8yQ	2023-12-31 09:12:29.412784+00
3m5xn1dja7kq16edjn5ijukidj50dn7d	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r5Czc:Q1zDZf188NabSFZsTl5TXNjd52Hu0UwrDSZ5ZFrOxvk	2023-12-04 22:43:48.610473+00
88pv3sf3l7odym7z774hqv0mcwst1t1g	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rVEqm:33z_b2D0F2APVXYLQV_uDn8Ejuhf3GV2xqkv1Wk3_0s	2024-02-14 17:58:16.439798+00
wli6j7uf19dd0yacw9z6tlr7s4fxunrg	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rADZP:n3dZ3nIpC2NWITfYgElOmhiTlvg3rv_CQykfV5o0CmI	2023-12-18 18:21:27.588935+00
3n8q2uw6z9iqoisj5l4k92b78m9lc0mg	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rM7J1:A-VaKlrApyfv0DxhuQiu-fV8SVHj-QIshMolJWeM9nY	2024-01-20 14:05:43.727006+00
61bjmfu3m35dvj97l74s55ev9d8745aq	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rRtuX:r5nF6e8WXwf9NNXph389zqKzjJ5fNh4lFgcroOpcaxU	2024-02-05 13:00:21.581819+00
um9vlkupbns49o4uk9upwq2oqe60qaf9	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rZW4r:O3hypU1a4YY1v-hmJ0I-4C8Him8I-3xocBmzat0PPqg	2024-02-26 13:10:29.54118+00
5zcmnleqti8ksnbehxylsj1a0x2v1zjq	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qwM2P:mMQwrv9Tfj7w5APbCTGBLhqzSYRFAa_9dG3Bu0fpzJg	2023-11-10 12:34:05.09451+00
ota5x9w8ioukwfhbiy02j0oolz9ft2s5	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r14KX:N5WVqHFvjzfh0_54yvrstlVFMIjBxCA8rw2QyLS4F-s	2023-11-23 12:40:17.265942+00
w9uk39lfbxbchlmui279edyfv7l2005e	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rEr9Q:oC8SrIXvty_qL-q4AquCK27LROBZS4TKNbNzTpRTQqI	2023-12-31 13:25:48.609808+00
cmfnver1njz66sct51qofykzs5ckpr7s	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r14Tm:18m-LSfhK75k8hmhRipaKEE_nvgpTfVhzC6Am1o3MJQ	2023-11-23 12:49:50.445725+00
jr0i421co13o3nxwk0aiaiwqb3nzaqm7	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rErD0:i2Otyuelze3i66qGfuLQ8s1jimjJlV-5NgCNob6g-AE	2023-12-31 13:29:30.709995+00
u6gnixbk6brp0fqbngkmjab4hizv8l4q	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r6tr5:ZEltEi2lsVif7SsXE_zEDG01wLnnEbHISoEnDLzLGVs	2023-12-09 14:41:59.7141+00
dxxgp2s2g6nvufuodxc4fm2q1uq0q36h	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rApTR:T5055H6KoqdzLU4Hi-xWMnuqk_bs3odqv1uv69PDbfs	2023-12-20 10:49:49.254423+00
jpwv20tav778vxjrxufqmy3fwu7y01ts	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rM9C9:-2qUI3QFoSV8TLZeqkJUupVWMMG-V1p3p8wsQ9M_9Zc	2024-01-20 16:06:45.198499+00
yw027jfbm4zy9g56lp5waj0cgaoaqmgm	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rVbAK:1HYPXnn8ee04PbsFi4tpKnvjvFgnpp8j57Mly2DNQqs	2024-02-15 17:47:56.547579+00
vf4djycrjhwqedslslv7m7ppibumk4d5	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rXjXD:llZAqRhCW18xUHbF1kKMOAY0L_e3jFOHK00k7G-OB9U	2024-02-21 15:08:23.398831+00
bumx59vicc3my9mo5iitnuwvs91ayisi	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZq6i:ND-wTmsxW2v0YXkPURI8Mujtt3LM8Zu5J3wNqAiYb18	2024-02-27 10:33:44.973372+00
ic74nqq7rvyuwi0vdw2dbj3hszmn17m5	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwU6S:_dubzP9tWOvuIoFhcD_GSYPBXizqgCBWjP1Jd_ir52E	2023-11-10 21:10:48.927734+00
a9xj4vvubtymbxdm2meuhqf5uiro7i1t	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r16vR:t5ZuUJoQrGIFFAg_DHBFPBEKElJwyn9sXYr8frJvCCk	2023-11-23 15:26:33.615874+00
pmdkv5lmmwyqkfw0ddmhseoilyhj1qgb	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rErNL:_L2_2RVdr3Zm831x0T3VwJhKHuaZ3c9Igmwgzuz4r08	2023-12-31 13:40:11.927095+00
77y6c97368oy9iju5htbi9d0i9n7ufua	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r5St9:OljDnQoLN5iI3lwBwDUe4eUF6b3T0UWNeqy7Yltk5KY	2023-12-05 15:42:11.081252+00
en2vglbp1mj9zjear5wrc0qk855hfq5v	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rVdjY:eusMaDyHFOW9Ozd56Uft0Hk7bf20rY0zCpmGeTEDBpc	2024-02-15 20:32:28.141495+00
gdf61qlg3vi8fsh09ay0p1grgrnl825o	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rB8UU:uCZSfGLc7_DNiWnIMAytb_t_uYnc1R6AtLNdhSXUQnY	2023-12-21 07:08:10.635108+00
d5cztgfm66s625gjis9s1g83q3jdvl1t	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rMDvZ:CdqO_-ungjGhHNosFyaD9mxdadOutknjzxMeIL0Ms-o	2024-01-20 21:09:57.166326+00
46kb1m95erms3ebsv7b2kjhc9v38tbbq	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rS0fI:DGXZyViiqvgkevg4-brKxc-MtLwvoJWfYiRbJXZDLC4	2024-02-05 20:13:04.48681+00
06gtqldkqkq6svjec0jgl1kbwcsifgp2	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1raGcM:VejkEdU0dZK3HWv-fKtsmaovt_3lgFhmtdAEpoIWnT4	2024-02-28 14:52:10.925072+00
suz9hmstqr5yowru749vspixm9ovzx4b	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwdwR:3KqIosAVxGKwZmGZsDWcVnPL2SyaKKtWUXer0hgpULw	2023-11-11 07:41:07.611495+00
073gtupfri0eom7tg4fee8j80qm7ef9p	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rEuYU:US5bXxKD982BeXO0lVZSFGvQDS8ZUJv5Ek72diACRkQ	2023-12-31 17:03:54.994706+00
n002oib3bmsgal1cha72faui701pek28	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r1CJe:tSBQpeCelkp7_G-wCT9XGG2rAByPKKpsSWy12UceCzY	2023-11-23 21:11:54.2632+00
o4lle42hn9yac9l6h8p2d5m47n6kevrl	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rEuYV:Q6-2S2dWCWe1_2Nfdt7RC7zC98gzZs4zBzsScH8jXaU	2023-12-31 17:03:55.792617+00
65o4v9fd39cblz8dsneinc8c98g8w3ph	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r5qWh:xSZuD2ZOXwjxNZFg25ab6vyk5UbGogULtT_PsSM_8nA	2023-12-06 16:56:35.805903+00
yl07qlt2xcp1je2wz9w2tmwxvzz939ma	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rBdaf:iJNT2q6OCYLrKl5iwaDIdSmpckJZXkGlcMuVLHdy91c	2023-12-22 16:20:37.580025+00
vahtv3yqt2rualt25avw6eetg58ncuxw	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rMFsU:dpv9h2CmVhfIjNACWeMbaFQzhv4LbXloQ4rwU_tqCHw	2024-01-20 23:14:54.164079+00
ohi4upoiv7606cp9sn4xx9qqbt5irp9b	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rBdag:Rig_yoju97tEgmtYv4oj_HQNPWk6dTAJYqJpyr9vEsk	2023-12-22 16:20:38.567548+00
rwerbzx2z82a5d50ie4iohep3fskd0p4	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rMFsV:IUgmw7UqgtkQgOqs1oamVVLHRJy8RvbuyH-DBHwki30	2024-01-20 23:14:55.260031+00
541myoorb8ixydfqpwa78tnjnge26mry	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rVqIg:EbTB5-h7SxtSqcZPTSSH6qhSTW-sQSI0-JMNKlwTPkY	2024-02-16 09:57:34.319082+00
obp52afcwlagzwaf3uak7i3grki0kss7	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rSJlf:IgezurXs9Y_fN7CyMWI2SrDlTewNH6iskqULBYvaBvs	2024-02-06 16:36:55.057996+00
di7ruiwuwd23w1s4r08quhe8jddq97zz	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZB89:TywTouPCwpQQmmFutuZnvrAJ_NPh2EaauV6c1OCGAZc	2024-02-25 14:48:29.040921+00
6h5reuw1g6pjfl5anzvhdi6w7rx495qt	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rSJlf:IgezurXs9Y_fN7CyMWI2SrDlTewNH6iskqULBYvaBvs	2024-02-06 16:36:55.945437+00
ay455tij0zpc15e6tkzencdzlp417pac	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwe8k:BYIW9PQhd8B4Zx90JLyuB89JtynTMJOo0YIiBiJV5z8	2023-11-11 07:53:50.942211+00
ja48hocbfpifibxn32p60s2nzol2zoq4	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r1Qqw:_tQHdgmI0jpncc6tOY6aTHmQ7455GuE2sWRk2ZcYxAI	2023-11-24 12:43:14.694609+00
c6rqlll4u4ejara6q835pzerpiy59xmz	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rFAJs:LnnxFw1QhFHDhDNYInnJMui5o3UdX_AJim97GpftroE	2024-01-01 09:53:52.641605+00
7m2vr3efpuo05u5qos65ng6og8ky8xou	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r1Qri:l5Z-RDJw1feerl1IiKZKdXXuHI-mlmJvArvp8anWfag	2023-11-24 12:44:02.72723+00
00d02f2hd2aobj6qzmbdiclak2gwgt7z	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rVzNs:iyYngIYhOCajojFNJNxHHUN-4XbkouqnuPo7eV4oTEc	2024-02-16 19:39:32.322543+00
4ggp31i532g948ssbzf97o68sqpslweg	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7Mjt:e11fT1bvPRaIZzSygAADh7nxrMqDDRu6nQSrkP5F8uU	2023-12-10 21:32:29.811588+00
k42ovjplsr2qx1emkcunjvy9uxpxbkh3	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rCMsv:dB0cuM9Zzotlqw6xgpY1X_VLPBqtkojh9HQPNe3cPoY	2023-12-24 16:42:29.330333+00
m2tstvnfk4bkw4sc69kbp6c6byijpkqc	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rRZQf:HfRrRkML1MBIXz_kPi7O9TnJ7-NTK6lByF7teeabvdM	2024-02-04 15:08:09.975122+00
kjkp5sxzyj5igty161be0mvqef8bz5tx	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwhd0:aOQiSWyTaHZqFgVvKlHQ_RPyuMVkXb7vV1R5lPtlKEM	2023-11-11 11:37:18.053286+00
e1v0l1cxfmqsg4paw0axdtfi894je0yx	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwmbf:UiwbyNCW36laQX-gF3-8HCP0guUO1riIxLi_wou1FF4	2023-11-11 16:56:15.311201+00
7hk2j24ckz3w84ub8y6pozzlijpj2z56	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r1R4M:3bJy2zr-pyOU4srC4V68AdVyR7QavALB811zH1e4K5A	2023-11-24 12:57:06.494113+00
99rc29mw1yjhc7dydn8g389tntmtftlp	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r6aR0:QLl7ATx41xQnbW_-j5j9H4p1ZKhNYE7n9O6zoaIfr9w	2023-12-08 17:57:46.679444+00
wv9p22mbhrm733rt0329pvm9rhkdgcpg	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rKloZ:pySdoxMi3--5K0Hwn-E2tEELtT5Zv909Zv9Vr8pIBXY	2024-01-16 20:56:43.07918+00
9qkjzddsgb6ior0xs79w638rmdms9z8b	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rCO10:GQdgJDp--foAgWaOI9MV3Q1n_i65VVWLqrZjx_XyHA0	2023-12-24 17:54:54.465753+00
hdws4zhla3lzh67nfl3hy9ziwgmzxtot	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rWiS1:5oLRj3LOl97Iii9wZWhjFXJlPkXMfRoY33lnwnNTjxM	2024-02-18 19:46:49.519994+00
wfi05vi418b93tmj2m37m26bu8mka1rf	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rXhzZ:tidn3-BhURwDykqElZzT4saY945ndYGWlYOyuv2HMH0	2024-02-21 13:29:33.047703+00
k5bzsrkp4ajo3t6x29ve75nlpz0gmvz3	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwnFU:EycPb_EaVi8QMTJCS27RlzmOQfLiriHJ7jQO0RzqsEQ	2023-11-11 17:37:24.182946+00
k4ruo6y6vvk494o0l7vbrg4mt36tw3fz	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rEvoI:IIFhfcDXex1512uW5HsARAvymJ_9nudQ69opntWfPiU	2023-12-31 18:24:18.224086+00
4roo5k8apk1f7qwg0hqri85xp084255l	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r1uQh:iqi0wg3dqyY_rKFOiWXYXAZczu1a5CHenRXN4-aCD0w	2023-11-25 20:18:07.930086+00
h4cf9hjxlllumrvyqyncm3xduyueoktj	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r6sIA:aGOlBqqaPctGPXY3FWEHjg6u1vcEpIfhKA-bpiL_Y08	2023-12-09 13:01:50.703515+00
bsqh7exfdujjw6lxoryv0hj4i3o6jqi9	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rFC65:RLC2A52QZjQGNq4Z6p87IGi_8ZKhpFwRVOd0h03uIfQ	2024-01-01 11:47:45.929968+00
i6kcuna147cts6yl17d0jtpb0d8hcv6f	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rWrtK:ChwVofoMC2gP9kd1BBdJemK1MC8YESbFhPHRKG2kmpk	2024-02-19 05:51:38.730041+00
ncp3k3y46rg6s4w90c3wtv5htyhl4lam	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r6sK1:6umy15b02e_f_H-ymGxD2EPWwP6MuXlgYSVuppdzmD4	2023-12-09 13:03:45.194231+00
dmbe1so7gz1wn1c4aiwy0x1hngmkxnnb	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rMaJt:KoAtFHjG0q_P--d0rcfga2COPcw5MTSp_x4Y4d5FuaM	2024-01-21 21:04:33.374273+00
r51av1xj32atuuzyraz502j55wfw0o9v	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rMaJu:8kQSLyNhWGPkl2okDQHq1-nlo5nctPNbqvMS45UzLTQ	2024-01-21 21:04:34.373463+00
7ge93y2zt81bloj4wa1ioo4olakgs20m	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rMas3:cfsrmJbTigcX59U3y1q_kPUXkVJ2QJMkhottk3yvZCQ	2024-01-21 21:39:51.663381+00
v7g8x7q19w0f7zx8cou7ckh0hdsvlmkq	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qwoga:iiae8yUvetxf7qO4O5a2RXoTBQCZfox3Hdvof4orM_w	2023-11-11 19:09:28.895726+00
lhm9ssqvhxtwv8mylsggykwhmnd6uzph	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r2E7z:AaljdJ_8C0zQcIkrPwjHrskn13L6GVksRmvAmFamGUs	2023-11-26 17:20:07.33144+00
i00bqg9beubc5gjm8iebb3spzu7lvzp2	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rX5UA:wSMQvIMjGonK3BYV1Qw2hIdcGMfhejkV8aSN_IjXc98	2024-02-19 20:22:34.977837+00
yiqt3jw9o9gbo1wri8pxn7fh38al6d9n	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7EPT:vZSbYAuo4-Ti6LSCXOmLCclv-kGm4yk1ScFae4qbnbM	2023-12-10 12:38:51.62372+00
qgyxgb48jxfr68ki9bt1nz3f6gm3qj0c	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rKJdA:5BSM8NobGj7-wBIxsUBE6o1N0-f9GoZchCYs7YgBSj0	2024-01-15 14:51:04.874969+00
dh2az7ks0auo6ghsrbu3hdpw230vx59n	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rCPsi:OT-E-pnQGLHwd8NjWU9xJNVnm6r-jNc6mR1tCKJe760	2023-12-24 19:54:28.084001+00
tdbd6aauxbfhs4kxd9urona65zgasthm	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rMooq:b7fEAYPdeg_8sQc64LYlEY3wj4GAKsPiZwwAzyw2Bag	2024-01-22 12:33:28.815075+00
v6x7bkkkzaqf1wkmo9fyhfdyomqsz4u9	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qx3oW:LGb5v9RxYU28II1W4d-EavSiSDXs3eKU_HW-tbbG2GU	2023-11-12 11:18:40.504157+00
q3tf3neu11wuon3z821asguzcbnw6f61	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qx3qf:JQzM5S7mTHXmj9evTmohFg-LBlrJjSA-V30m7F1GstQ	2023-11-12 11:20:53.61949+00
gc2wz2mujeufa8k775itfvx9rrydw5fw	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r27t3:13q_GlZyj0N_Gs01EII4bgcTQ45Ts_26lfUHsjPmiYI	2023-11-26 10:40:17.383049+00
dqavkk4qsqyfu6vixrnqghgw1mwj03nv	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rFx5w:mddG2I_w2ScYVBb_jVq9RXAwRJJIpWZrKCUIL7bsA0k	2024-01-03 13:58:44.814577+00
g8tqw7pcj8un8rxverqc5raph4pwe2n9	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rX64A:r2_jl2sdxWQr_RFbET4mDeMP3AN6d4TgNA-7ppyS_Ic	2024-02-19 20:59:46.289893+00
u6lu1535eet3vyiqpcqckutp69zo8xaa	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7HqT:dUgMxh5cxn-CRT1yHBFX8_y5v3z-SkHgv8E1MgdeTHw	2023-12-10 16:18:57.317016+00
z9bdvuah66f71cxz9y8iibcaudzoh7hj	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rNIY5:GgxUn2UMMIHvOpMFKNS-0DkdRuZjtI9KA2WYquZZdWY	2024-01-23 20:18:09.65726+00
qrzrvghx5vfxtyw6fqyauq537zktmn7k	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qxDKP:DEm8Ooxv5lIG65FLcIGiq8V6_t51GSOsqUWAVR_z958	2023-11-12 21:28:13.04968+00
ilduc11gul0s6x2dkm3zs2sz4m3ts6e9	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r2B7D:GC008RnGZAJB5Bf_qjxU6FGmJ-5mPqrX4co73UnU8wY	2023-11-26 14:07:07.913984+00
p52e1emg8y8azci3elep7m4lup9mt1as	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rWhYm:PN9_ZRDgiGXx_9yzv85-mJ2iTNM6_y8ibYmjd-RiPqE	2024-02-18 18:49:44.387712+00
vd6pcef809s5hdiwtytrs55cgehhn1jv	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7Mju:UngYP1dss4hJ61A4Kgfqjejcuzb2sZ2M2aKq06kcvFg	2023-12-10 21:32:30.655262+00
vvi4w2ja5pt8awj6ca8qpgaz7p4j20jd	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rJaKe:397qsHOCmaX3D5NDhxZq5riC-LxWN3mAMruJUwVC-VM	2024-01-13 14:28:56.215382+00
0vt9ec4vtjjljqges954bsoyk0l5ce1y	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZY9J:gLjAaCndHHYtKwRFehStN6yg6dO3T5BOv5pU2vKxOKI	2024-02-26 15:23:13.916192+00
bpewvq3st7w7sx8zfa4hcde2y5ixxmrx	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qxTMc:FHvl-Z69qZRhN9ZCXubA4vI7xW8Mow5t1uuHhxQWZsI	2023-11-13 14:35:34.26073+00
uzfkrebz4dc6teomkj03p331o7esnr73	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rH1me:JpfsIzXglFY8cJ-rAA5Juvi2UWkjzM2_52CxhyUHCBA	2024-01-06 13:11:16.483164+00
4pfqupnnx0v3471l7y8r2cg7me73l6p7	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r2CKr:7TwXgBLtesf_yX-ia5EOKa7Qhe7VBRUdGnEAS6NbZic	2023-11-26 15:25:17.418944+00
m2w8y4cgehf0yn9z403oail64xbyj5os	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7WXT:7-c_xZUmx7D69q9bfTssyiC2C0MEWT1dTWc4nDjTalg	2023-12-11 08:00:19.282359+00
2vretbcx6tyidexs39cqj6w8ggkzwjd6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7Waw:bK6vwauSjZEnbNtEpjAX1EkHAAXg8MXuMkvkrXk6xdk	2023-12-11 08:03:54.287315+00
6mp9mfd76r1lai4xizydvh0tl5wr4cxv	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rWidI:ugWxDeNGHqn6F32FyQ9DL4Ze_aibbDpl6JPOfFmPCas	2024-02-18 19:58:28.514927+00
t3qfcwycftg0sx2cessyncfa92vgmusd	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rWv14:Hx_PLkGQ6u1pBbdLj2a_PtJ-uVaHRykCiLvj_8FTbow	2024-02-19 09:11:50.118666+00
jxd5okiigm4g2sau8havjenhizx8f7bp	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rXKL2:wpS6715cg3fBRPNDXOs8siKuQcCjWPDG7bEhwysDd_M	2024-02-20 12:14:08.150939+00
fxakzr1ur1wlxrcfvqyq91i0tjdoz40e	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qzj6E:dzEpGyg8HQBP4Mw4B0ChRkp8jrTYBYVgZXwrKWsW-9A	2023-11-19 19:47:58.713687+00
119coedtnanonab1xvv8kbuwcm95e2q5	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rH9SZ:w5jAW--XNHAtS0iqqI-3BdELhJv9I3gZjiUjD9vhu8I	2024-01-06 21:23:03.953019+00
969kj1ocm2xxzztshe9oaqhcrn8lnurq	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r2CJV:9lRoMaaZWIQ6RY6RBcRFBFQI-a0MCfFJ60FC0DbSYnw	2023-11-26 15:23:53.319174+00
12sh5k5w3nj5dk08rl5kpqfs4eujue2c	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rXQtV:sYqmg_2N0tgk8Yas1PtPktafZDyEPKi7aV4MXIMCqME	2024-02-20 19:14:09.908882+00
ijpgdmcbpulgj7wpvn6sjls75as0mkli	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7Wer:H8ri_1ok3gHaeGyw2UwYWdTOJVihRthLLkdRgtzq3Fg	2023-12-11 08:07:57.18048+00
5820w6nhc4fp5kkqyhfi0htppttuhk9t	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rH9Sb:O8TDjPnQvhm7zfwUc-u39s-I7duEWSqpZaEQaSoXv20	2024-01-06 21:23:05.108903+00
pvtsv89bwsd36mz1f5mpnx1rm3pwt2ql	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7WgZ:pyT5FUIHucUg-tKMksLSQSKcg1Zs26k7Hh9hzetraS8	2023-12-11 08:09:43.011+00
b4hzqmy2k8cartabahzbt68b5e188yam	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rP2kd:He3LEjtt0Pend8YhGLOiQWJnFsMtYkyFO6JRsMsRfko	2024-01-28 15:50:19.027743+00
c9d3sekejxzr06g0q0z4wdf3gdchqdsw	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rXQtW:jfeVfeaJJiVKDHh_cR8U5CCjiobTu8E1bWr-1nrQ-1k	2024-02-20 19:14:10.889143+00
4zkkak2dih6ha0h01jnxqafme7toegq0	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qyD0B:608uALqVmgawYY3MM9IZAP9CDJThzyAxgY8tU1fcR9M	2023-11-15 15:19:27.672997+00
gk0ree179cnuizaayripp2sx5u0189fz	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r2HZQ:RMeoEjr2yeOFBQjeedLiEKs3RmsdVrOxjjZ6kaLX7kg	2023-11-26 21:00:40.372378+00
7s1qqsdis9pzwqpkgro8lh3i83cuedc7	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rHLOg:1I37L9fzFYZ_bRLkSpzpBBzMZm-uFh4e8D41H10jBU8	2024-01-07 10:07:50.093312+00
y2v9zq8voa7cgk9biu9r9scwd8qlbxlr	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7WxA:cona_pLrP8knzhVjp6Rv4i2MY_I3MqHAdSZ0XBBRsVk	2023-12-11 08:26:52.189784+00
ks5zyxosy63b40ag2evkg1ij1xkcwj3b	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rXRoP:wFvyK-LNsS1ZX2VnFVDERq52vrCj3UaJ6Eez99_rPl8	2024-02-20 20:12:57.860136+00
673n2cp5mt1j4je04dspghacuy3l51qd	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7WxB:UPU7924H8VNuUyhob6TN2hycKMkxFwrgPV_v5ARx9es	2023-12-11 08:26:53.016702+00
fc5btq11u6caa9wowf3ul3n7fjy9xcf4	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rRf5p:wyUVwl8IYs46SfBzn8UApHBP8XQ6D2kvc7H9Tqkvv4M	2024-02-04 21:11:01.974734+00
n68ssto1h7ud0f0bzjdxupuf79vq3z9q	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qyah2:eY0INpC02LAdp8KrFgclTee6HGqKydDu4kgG6Y3EPJI	2023-11-16 16:37:16.026023+00
fd4pn1ejlaq5iow7bysodwrzoe08d4ox	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qyajt:pxGqXKwxnSET8dUjKdf8Gp0RO31vHpq7KxSHXfky4rI	2023-11-16 16:40:13.745377+00
1nwvvoul2fpe35xz4sbg3b1oie145611	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r2q88:gUZGKSSE38J0agVxyA2JnkSQXNwXIIludhfV-3r7DI0	2023-11-28 09:54:48.461984+00
enn5dtcos72cdxea845q9zsxi3hguc5x	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1qyaju:VrdUCUhrvCq6kp4M3INEQR3DeTlwurBbzsa1tZUEHgI	2023-11-16 16:40:14.754577+00
wwbmg2aoxpsx7g7s1ng49fuve9aji3ur	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7X6m:iBrpbWcUFiyWcbp25fzjrTWFb06LnYg7T6b2EjPPDsI	2023-12-11 08:36:48.27855+00
dambjbmv9tqf5ncfmvsrlmpw0h20i4mi	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rYYqU:yIrrIFuyezt_oWBeOVhI-l1vGi4DIFr0tlpkLXtS9aA	2024-02-23 21:55:42.057487+00
ns2cwymf5mowuj2fqp3ao3759sykcijm	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rMUHu:LB6978kFL4jXnLXKxf81B60PRCkfKuN34C7nKz-GbFE	2024-01-21 14:38:06.80878+00
mgwgmq6q9c3wt2dk5q9re64vsutexz68	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rP69P:Rpf8qcxt9bQXcR_GT17zrrdnZDd6nz071irAPJHVbVE	2024-01-28 19:28:07.757802+00
stqfk23tu2pwhwasa5pkk2k9njqtk2pz	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qyatH:MNfceF4GJSZ8GF2rbvInRlwU0ZsU-O0fWn2EYQD6iEE	2023-11-16 16:49:55.14567+00
y22p79yvh1u2e6ze3gzf1hwxf46f35nn	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rTkAo:Z3vjk61Ck58eHDikakFYEZi8pV5-K8cb6Nj2COLeb_w	2024-02-10 15:00:46.893945+00
k3wwu0co565g63q7dp5hhlpmfu392zhn	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r3Nur:JQU3N8aDJD8pXP0TZzPUQh0wt0m7z5dH2YP6SNyPOaQ	2023-11-29 21:59:21.997277+00
61ydh8cfp3wj38gdxeiimaptsyjtdyyf	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7fGd:bIKbpWwPW7CNoFhQgIqOstWs0L6NHRGyO_K5rZB4Oog	2023-12-11 17:19:31.825479+00
qr2bskijz2ymfzxzx98uxdg978auj3v1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rIZms:YGfyULyAg2e_DaIFCGj-X9hItQZYO4DNUPOcnbn2dvQ	2024-01-10 19:41:54.017387+00
gkhbcgr4fffld1ygi2ia0ce1qnaoyjgt	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rXpDg:owm_hEbLMgfdEfiL54djU5k3_Ir02GnljpblMRp2uU4	2024-02-21 21:12:36.187946+00
nfod8m3pg42u0dnsjw9b72m70drbzo47	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1qyhF1:iyi_383T3E3EZZYtcb59k6XQkpk49Qa-ko5DewAifEs	2023-11-16 23:36:47.024815+00
t8it87v83v3v91qxl26dfqzumrwvwden	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r3vgE:D1xCF2M6eRv3xWXPxhLcabl5wp7lfTz8zewNZWqqbj4	2023-12-01 10:02:30.605596+00
htmwcfv4pb6ogxzzd3xh4jcrw47q0uop	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rJJ2A:fNmpmqOTjVGmjlA_yapZ9-pibnPOcYL6XYWFieXB3bM	2024-01-12 20:00:42.757632+00
8n98cinn6px4o8i16v8jtc5intw3nj23	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1r3vgF:__UozuZFHPAzLuPjwK10mhim3PrU_glB0n99M6Mq5jA	2023-12-01 10:02:31.605555+00
p0cafxs1loy8iukucnxl1tfppsw7tzzh	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7jSA:SrRVOHm1vQ7Aw47_LHkQ-rCbPKfGNKdZFMBEqnREXIk	2023-12-11 21:47:42.442907+00
tbv0h5umnxfe1ca5z8r9cajjadllbxhq	.eJxVjMEOwiAQRP-FsyHSLdL16L3fQIDdlaqBpLQn47_bJj3obTLvzbyVD-uS_dp49hOpq-rV6beLIT257IAeodyrTrUs8xT1ruiDNj1W4tftcP8Ocmh5WzuDjABoBWgYHBjjAA0hgUWLDs6QxHaGI0bkLolsUSBeTHC9IJP6fAG3-jed:1rPq8i:7KSubWjgsamEVWjXe93AbSJ62QOVDvpx8trmmt8aiZQ	2024-01-30 20:34:28.622033+00
1h9vzhjmff4l63vffdxmr2kt0c8n0w6x	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rYCaE:2ewU9Z69UvWEkb5bx73Sq2MWkwGnu81v8a_Pr1mbqvI	2024-02-22 22:09:26.477408+00
0v50qugqwyhb3glmizq5a20qdx8bheai	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rZBXD:cFUc5XGx41t3RzoAjPH23YflYiwmWyGDk9_rUpmAZ7U	2024-02-25 15:14:23.133899+00
5h9tz6y0v949e0ubv15i66azv0o6jiz6	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rJKDC:ilmX4guME259aJaDrqF_JG7sFb5lbF5AeQxyfWug2kY	2024-01-12 21:16:10.801067+00
rdxuzqkurho9g9lf6hs0f8x9bs7lr0fm	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r13qE:0TqUUAr28DEw6jMgi_m04B8hEKZnXJvg6Rx0C5qc_vU	2023-11-23 12:08:58.653984+00
m203c2tqphxeruqseklpxr920gnllec1	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r4STF:zwoXIYah5KwGeHuWd0V2YX4qZy_-mERwhbxiHL2pqGc	2023-12-02 21:03:17.148079+00
nz81lz1i6qceekygn8na8mn1av0fvf83	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rPqyR:La0-vLIKxQrK0NaFaBzHAuoZs9xYbNXdSvzBFsQmUzM	2024-01-30 21:27:55.420524+00
i4usdr3v8royojc5x8f0i1u53wgrvbqs	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1r7uUN:GfKJv9sV-Sxq2n_RpV-sXUiuQ0V0X6A_x0mfFUbJplY	2023-12-12 09:34:43.907564+00
cclbmoi923ku5480695apn4sl18dqiql	.eJxVjEsOwiAUAO_C2hA-BYpL9z0DefAeUjWQlHZlvLsh6UK3M5N5swDHXsLRaQsrsitT7PLLIqQn1SHwAfXeeGp139bIR8JP2_nSkF63s_0bFOhlbHMiRG3TJGfvRdKgDLostCfSCixKrcGpHKNx0mRnhaHJKRCzk9JmxT5f6Xc3bQ:1rYWg3:4zTDdlDSSIzhGAcfOVpIGbbF_H5tUqeKJ5MAOFI8kcQ	2024-02-23 19:36:47.961915+00
\.


--
-- Data for Name: main_league; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."main_league" ("id", "leagueID") FROM stdin;
1	1
2	2
3	3
4	4
\.


--
-- Data for Name: main_match; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."main_match" ("id", "team1score", "team2score", "matchdate", "team1_id", "team2_id", "accepted") FROM stdin;
134	11	3	2023-10-08	69	70	t
83	15	8	2023-09-17	45	42	t
84	8	4	2023-09-17	37	39	t
86	5	3	2023-09-24	37	38	t
80	3	15	2023-09-17	63	59	t
64	7	4	2023-09-17	68	62	t
66	13	8	2023-09-17	70	61	t
69	5	9	2023-09-23	63	67	t
70	8	12	2023-09-24	57	70	t
68	2	4	2023-09-17	19	26	t
107	20	5	2023-09-27	69	72	t
108	10	5	2023-09-29	69	55	t
109	9	7	2023-09-23	61	58	t
110	17	7	2023-09-28	37	48	t
73	9	6	2023-09-23	55	60	t
112	10	0	2023-09-29	44	46	t
72	4	6	2023-09-21	48	38	t
116	7	5	2023-10-01	16	18	t
113	8	10	2023-10-01	43	39	t
114	14	10	2023-10-01	67	59	t
111	8	27	2023-09-30	29	35	t
115	13	7	2023-10-01	6	8	t
76	4	3	2023-09-23	69	68	t
75	7	4	2023-09-19	69	59	t
77	12	6	2023-09-24	44	39	t
78	8	7	2023-09-23	62	59	t
81	9	8	2023-09-20	62	72	t
79	18	10	2023-09-16	67	60	t
118	12	5	2023-10-02	64	61	t
124	10	0	2023-10-01	5	17	t
125	7	4	2023-09-24	8	7	t
126	5	23	2023-10-01	63	70	t
132	10	0	2023-09-24	46	52	t
127	9	6	2023-10-01	45	44	t
128	7	1	2023-10-07	41	43	t
129	13	1	2023-10-07	68	58	t
131	8	7	2023-10-07	46	53	t
133	8	4	2023-10-08	41	39	t
135	10	3	2023-10-08	68	56	t
137	7	5	2023-10-08	55	67	t
139	6	5	2023-10-08	54	40	t
142	13	6	2023-10-08	8	16	t
141	4	2	2023-10-08	6	17	t
140	10	8	2023-10-08	9	7	t
143	10	13	2023-10-08	66	57	t
164	5	3	2023-10-14	15	9	t
144	18	3	2023-10-08	15	18	t
147	8	11	2023-10-08	34	28	t
148	8	3	2023-10-10	53	38	t
146	13	1	2023-10-07	53	45	t
145	7	8	2023-09-30	50	53	t
149	14	10	2023-10-01	34	30	t
152	12	3	2023-10-08	45	48	t
154	8	12	2023-10-08	21	30	t
155	7	14	2023-10-08	24	26	t
165	21	1	2023-10-15	55	58	t
153	9	11	2023-10-01	42	40	t
161	6	6	2023-10-08	44	47	t
158	15	3	2023-10-08	32	33	t
157	6	4	2023-10-08	26	31	t
159	12	17	2023-10-07	20	24	t
160	13	8	2023-10-01	20	19	t
162	7	5	2023-10-08	42	37	t
163	10	2	2023-10-14	41	49	t
167	0	10	2023-10-15	67	57	t
166	11	9	2023-10-15	69	71	t
169	27	7	2023-10-15	64	63	t
168	13	11	2023-10-15	24	31	t
170	10	3	2023-10-15	8	18	t
171	9	4	2023-10-08	63	58	t
172	17	12	2023-10-07	63	62	t
176	17	6	2023-10-15	14	10	t
175	8	3	2023-10-18	41	38	t
174	23	4	2023-10-15	37	73	t
173	20	3	2023-10-15	21	35	t
177	46	5	2023-10-15	59	56	t
178	9	8	2023-10-15	45	39	t
179	8	11	2023-10-11	9	17	t
180	15	6	2023-10-15	53	40	t
181	4	6	2023-10-15	22	28	t
182	8	6	2023-10-14	68	65	t
188	16	9	2023-10-22	69	62	t
184	6	13	2023-10-22	66	67	t
187	8	3	2023-10-22	37	44	t
183	13	15	2023-10-15	60	65	t
191	19	5	2023-10-22	55	70	t
189	8	2	2023-10-22	23	26	t
190	16	11	2023-10-22	18	17	t
192	8	7	2023-10-22	65	57	t
193	12	5	2023-10-21	68	63	t
194	7	6	2023-10-18	11	17	t
196	0	14	2023-10-15	52	44	t
202	2	12	2023-10-22	53	54	t
200	12	8	2023-10-22	45	40	t
201	5	5	2023-10-21	53	41	t
195	15	7	2023-10-21	28	20	t
203	11	14	2023-10-15	42	46	t
204	10	4	2023-10-26	27	21	t
206	17	4	2023-10-28	69	63	t
210	11	9	2023-10-29	8	5	t
205	24	6	2023-10-28	25	35	t
207	13	1	2023-10-28	68	64	t
213	8	4	2023-10-29	23	19	t
211	2	4	2023-10-29	41	37	t
212	6	17	2023-10-22	19	32	t
209	21	3	2023-10-22	47	42	t
208	14	1	2023-10-15	47	48	t
214	10	14	2023-10-28	66	71	t
215	6	5	2023-10-29	59	60	t
216	0	10	2023-10-31	72	68	t
230	0	10	2023-10-31	72	60	t
218	0	10	2023-10-31	72	67	t
219	0	10	2023-10-31	72	70	t
234	17	6	2023-10-29	34	32	t
220	0	10	2023-10-31	72	59	t
263	14	6	2023-11-12	45	50	t
221	0	10	2023-10-31	72	64	t
222	0	10	2023-10-31	72	57	t
223	0	10	2023-10-31	72	65	t
224	0	10	2023-10-31	72	63	t
225	0	10	2023-10-31	72	61	t
226	0	10	2023-10-31	72	71	t
227	0	10	2023-10-31	72	66	t
228	0	10	2023-10-31	72	58	t
229	0	10	2023-10-31	72	56	t
217	0	10	2023-10-31	72	55	t
232	3	10	2023-10-31	38	54	t
239	15	14	2023-11-05	24	30	t
242	7	15	2023-11-05	64	60	t
240	13	16	2023-11-05	65	71	t
236	10	3	2023-11-04	55	62	t
237	4	3	2023-11-04	69	61	t
238	8	5	2023-11-04	37	46	t
241	3	1	2023-11-04	57	68	t
233	7	8	2023-11-02	25	24	t
231	16	4	2023-10-29	65	63	t
243	10	0	2023-11-05	34	33	t
235	25	8	2023-11-03	9	18	t
269	5	4	2023-11-19	69	67	t
266	13	10	2323-11-19	25	20	t
249	12	7	2023-11-05	10	16	t
246	12	5	2023-11-05	53	42	t
247	7	8	2023-11-04	53	47	t
251	6	3	2023-11-05	20	26	t
250	7	8	2023-11-04	20	22	t
245	10	6	2023-11-04	53	52	t
244	7	13	2023-10-29	53	39	t
255	7	3	2023-11-12	41	42	t
257	12	3	2023-11-12	55	65	t
254	7	2	2023-11-12	69	57	t
253	10	7	2023-11-11	69	64	t
258	9	7	2023-11-05	63	56	t
252	16	5	2023-11-09	15	17	t
259	17	14	2023-11-11	19	35	t
256	5	9	2023-11-12	68	70	t
260	12	6	2023-11-12	5	16	t
261	1	14	2023-11-12	27	32	t
262	9	8	2023-11-05	39	47	t
268	8	10	2023-11-19	28	24	t
267	8	4	2023-11-18	55	61	t
265	9	5	2023-11-18	68	60	t
264	4	4	2023-11-16	27	23	t
280	5	8	2023-11-23	30	27	t
279	23	5	2023-11-18	55	63	t
271	21	0	2023-11-19	57	63	t
282	4	8	2023-11-12	19	30	t
273	10	0	2023-11-19	26	32	t
272	19	9	2023-11-19	9	14	t
275	12	10	2923-10-29	44	42	t
277	21	6	2023-11-20	45	52	t
274	7	19	2023-11-18	20	34	t
276	8	5	2023-11-18	44	40	t
278	13	5	2023-11-19	42	39	t
283	7	4	2023-11-25	8	11	t
284	10	5	2023-11-25	34	35	t
281	6	8	2023-10-22	22	30	t
288	10	4	2023-11-26	42	52	t
289	15	7	2023-11-26	54	39	t
286	19	3	2023-11-26	55	59	t
287	6	3	2023-11-26	41	45	t
285	10	8	2023-11-25	22	26	t
291	9	5	2023-11-26	25	21	t
290	4	4	2023-11-05	48	40	t
292	6	4	2023-11-26	47	37	t
295	6	11	2023-11-25	66	60	t
294	15	11	2023-11-26	37	40	t
293	14	15	2023-11-26	24	19	t
296	9	5	2023-12-02	25	26	t
297	11	10	2023-11-26	6	16	t
303	10	0	2023-12-03	14	12	t
305	10	0	2023-12-03	10	12	t
309	10	0	2023-12-03	13	12	t
308	10	0	2023-12-03	18	12	t
306	10	0	2023-12-03	16	12	t
304	10	0	2023-12-03	11	12	t
301	10	0	2023-12-03	6	12	t
302	10	0	2023-12-03	5	12	t
300	10	0	2023-12-03	9	12	t
299	10	0	2023-12-03	15	12	t
298	10	0	2023-12-03	8	12	t
310	10	0	2023-12-03	7	12	t
307	10	0	2023-12-03	17	12	t
311	8	11	2023-12-03	9	10	t
314	16	6	2023-12-10	9	6	t
312	11	4	2023-12-10	65	59	t
313	8	5	2023-12-10	44	41	t
318	9	1	2023-12-17	15	16	t
315	7	8	2023-12-16	10	18	t
316	25	0	2023-11-19	53	43	t
321	6	5	2023-12-16	34	26	t
320	7	1	2023-12-16	68	59	t
323	12	6	2023-12-17	57	55	t
324	4	3	2023-12-17	22	21	t
319	16	2	2023-12-17	54	42	t
322	6	6	2023-12-17	23	24	t
317	6	5	2023-11-26	53	44	t
325	11	8	2023-12-16	59	58	t
328	10	0	2023-12-21	25	31	t
330	5	3	2023-12-23	25	28	t
329	12	2	2023-12-23	54	37	t
327	9	8	2023-12-16	11	7	t
331	11	7	2023-12-23	23	34	t
332	12	8	2023-12-27	64	62	t
333	10	0	2023-12-28	25	36	t
339	10	8	2023-12-30	64	65	t
341	7	6	2023-12-30	25	22	t
334	1	11	2023-12-23	21	26	t
338	23	8	2023-12-17	53	49	t
335	7	7	2023-11-26	58	62	t
337	7	2	2023-12-03	53	37	t
336	10	7	2023-12-23	58	65	t
340	7	3	2023-12-30	15	8	t
342	11	11	2023-12-30	18	6	t
345	0	10	2024-01-01	13	9	t
344	0	10	2024-01-01	13	15	t
347	0	10	2024-01-01	13	5	t
353	0	10	2024-01-01	13	17	t
343	0	10	2024-01-01	13	8	t
349	0	10	2024-01-01	13	18	t
348	0	10	2024-01-01	13	10	t
346	0	10	2024-01-01	13	6	t
352	0	10	2024-01-01	13	16	t
354	0	10	2024-01-01	13	7	t
351	0	10	2024-01-01	13	11	t
350	0	10	2024-01-01	13	14	t
355	10	0	2024-01-01	64	56	t
356	10	5	2023-12-29	23	22	t
363	10	0	2024-01-07	70	65	t
366	10	0	2024-01-07	34	31	t
364	17	3	2024-01-06	70	60	t
367	9	4	2024-01-06	34	25	t
362	11	6	2024-01-06	22	19	t
357	10	0	2024-01-03	54	43	t
368	8	10	2023-12-30	57	58	t
359	10	0	2023-12-22	57	62	t
365	10	9	2024-01-07	64	67	t
370	9	13	2024-01-06	69	58	t
369	12	16	2024-01-07	55	71	t
371	10	0	2024-01-12	34	36	t
372	10	5	2024-01-13	64	66	t
373	10	8	2024-01-13	67	71	t
375	5	2	2024-01-14	54	41	t
358	7	8	2024-01-06	64	59	t
376	12	8	2024-01-07	9	16	t
386	0	10	2024-01-16	29	27	t
385	0	10	2024-01-16	29	30	t
388	0	10	2024-01-16	29	19	t
387	0	10	2024-01-16	29	20	t
389	0	10	2024-01-16	29	21	t
384	0	10	2024-01-16	29	28	t
383	0	10	2024-01-16	29	32	t
382	0	10	2024-01-16	29	22	t
381	0	10	2024-01-16	29	23	t
380	0	10	2024-01-16	29	26	t
379	0	10	2024-01-16	29	24	t
377	0	10	2024-01-16	29	34	t
378	0	10	2024-01-16	29	25	t
399	0	10	2024-01-15	33	20	t
396	0	10	2024-01-15	33	30	t
390	0	10	2024-01-15	33	24	t
391	0	10	2024-01-15	33	25	t
394	0	10	2024-01-15	33	22	t
395	0	10	2024-01-15	33	28	t
403	0	10	2024-01-15	33	35	t
398	0	10	2024-01-15	33	27	t
401	0	10	2024-01-15	33	21	t
400	0	10	2024-01-15	33	19	t
393	0	10	2024-01-15	33	23	t
392	0	10	2024-01-15	33	26	t
404	0	10	2024-01-14	31	23	t
405	0	10	2024-01-14	31	22	t
406	0	10	2024-01-14	31	32	t
407	0	10	2024-01-14	31	28	t
408	0	10	2024-01-14	31	30	t
409	0	10	2024-01-14	31	27	t
410	0	10	2024-01-14	31	20	t
411	0	10	2024-01-14	31	19	t
412	0	10	2024-01-14	31	21	t
413	0	10	2024-01-14	31	35	t
414	0	10	2024-01-09	36	24	t
415	0	10	2024-01-09	36	26	t
416	0	10	2024-01-09	36	23	t
417	0	10	2024-01-09	36	22	t
418	0	10	2024-01-09	36	32	t
419	0	10	2024-01-09	36	28	t
420	0	10	2024-01-09	36	30	t
421	0	10	2024-01-09	36	27	t
422	0	10	2024-01-09	36	20	t
423	0	10	2024-01-09	36	19	t
424	0	10	2024-01-09	36	21	t
425	0	10	2024-01-09	36	35	t
428	10	8	2024-01-14	64	58	t
426	10	8	2023-12-17	40	41	t
427	9	2	2023-11-18	40	47	t
429	0	10	2024-01-20	66	70	t
433	7	5	2024-01-21	55	68	t
435	6	9	2024-01-20	57	59	t
432	10	0	2024-01-21	54	50	t
434	6	3	2024-01-21	9	8	t
431	14	14	2024-01-21	65	67	t
430	12	10	2024-01-21	64	57	t
437	18	6	2024-01-21	23	32	t
436	25	5	2024-01-21	34	24	t
438	5	11	2024-01-21	66	55	t
441	10	0	2024-01-21	47	49	t
442	12	3	2024-01-21	47	45	t
440	10	0	2024-01-25	25	30	t
439	10	0	2024-01-25	25	27	t
443	0	10	2024-01-26	21	23	t
444	0	10	2024-01-26	30	23	t
448	15	6	2024-01-27	8	17	t
451	16	5	2024-01-27	65	62	t
447	10	0	2024-01-27	64	71	t
445	10	0	2024-01-26	70	71	t
449	10	0	2024-01-27	41	46	t
450	10	0	2024-01-27	41	50	t
453	11	5	2024-01-28	23	25	t
452	12	5	2024-01-27	23	20	t
455	31	4	2024-01-28	69	65	t
456	8	4	2024-01-28	54	44	t
457	10	0	2024-01-28	47	43	t
458	7	7	2024-01-28	54	45	t
446	0	10	2024-01-27	56	70	t
454	7	4	2024-01-27	67	61	t
465	0	10	2024-01-29	56	58	t
460	0	10	2024-01-29	56	55	t
462	0	10	2024-01-29	56	67	t
467	0	10	2024-01-29	56	60	t
463	0	10	2024-01-29	56	57	t
466	0	10	2024-01-29	56	71	t
464	0	10	2024-01-29	56	65	t
459	0	10	2024-01-29	56	69	t
468	0	10	2024-01-29	56	61	t
470	8	11	2024-01-28	5	14	t
471	13	21	2024-01-07	11	14	t
469	0	10	2024-01-29	56	66	t
472	6	6	2024-01-28	34	22	t
473	16	3	2024-01-28	47	38	t
476	10	0	2024-02-02	37	43	t
474	10	0	2024-01-31	24	27	t
489	10	0	2024-02-05	69	66	t
485	10	7	2024-02-04	47	41	t
486	12	8	2024-02-04	64	55	t
487	24	3	2024-02-04	69	60	t
488	9	7	2024-02-04	67	68	t
490	10	0	2024-02-04	54	46	t
483	10	2	2024-02-04	8	10	t
484	13	10	2024-02-04	70	59	t
494	0	10	2024-02-03	6	10	t
495	0	10	2024-02-03	6	11	t
496	0	10	2024-02-03	6	7	t
493	0	10	2024-02-03	6	5	t
492	0	10	2024-02-03	6	14	t
491	0	10	2024-02-03	6	15	t
482	8	6	2024-02-03	34	19	t
481	10	0	2024-02-03	23	28	t
478	10	0	2024-02-02	63	71	t
479	10	0	2024-02-02	63	66	t
480	9	17	2024-02-03	64	70	t
498	13	9	2024-02-03	14	16	t
499	10	0	2024-02-04	59	66	t
501	12	8	2024-02-03	5	11	t
500	10	0	2024-02-04	14	17	t
502	10	0	2024-01-31	14	7	t
506	10	8	2024-02-04	22	24	t
509	0	10	2024-02-07	62	67	t
504	10	0	2024-02-05	68	61	t
503	10	0	2024-02-05	68	71	t
512	10	0	2024-02-10	23	35	t
511	10	0	2024-02-07	34	27	t
510	10	0	2024-02-07	34	21	t
508	10	0	2024-02-06	25	32	t
507	10	0	2024-02-06	25	19	t
513	9	4	2024-02-03	37	49	t
514	10	0	2024-02-07	37	52	t
519	10	0	2024-02-09	54	73	t
517	0	10	2024-02-09	73	53	t
516	10	0	2024-02-08	15	7	t
520	10	0	2024-02-09	53	48	t
521	10	0	2024-02-09	67	70	t
524	2	3	2024-02-11	62	70	t
526	14	9	2024-02-11	14	18	t
525	9	8	2024-02-10	14	8	t
522	4	2	2024-02-10	15	11	t
523	19	12	2024-02-10	9	11	t
528	18	2	2024-02-11	9	5	t
529	6	4	2024-02-11	10	5	t
531	10	3	2024-02-11	46	50	t
530	16	9	2024-02-11	20	35	t
532	10	0	2024-02-11	22	27	t
533	11	7	2024-02-11	22	32	t
534	8	8	2024-02-11	11	18	t
535	6	11	2024-02-11	11	16	t
536	8	2	2024-02-11	21	19	f
\.


--
-- Data for Name: main_participation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."main_participation" ("id", "mvpPoints", "goalsScored", "keeperPoints", "matches", "match_id", "player_id") FROM stdin;
2124	0	2	0	1	244	1221
2125	3	5	0	1	244	1220
2126	0	1	0	1	244	262
2127	0	2	0	1	244	266
2128	5	2	0	1	244	265
2129	0	3	0	1	244	263
2130	1	3	0	1	244	260
2131	0	2	0	1	244	272
2132	0	0	9	1	244	268
2133	0	2	0	1	245	1234
2134	5	6	0	1	245	1235
2135	0	0	8	1	245	1226
2136	1	2	0	1	245	1220
2137	3	2	0	1	245	879
2138	0	2	0	1	245	880
2139	0	2	0	1	245	883
2140	0	0	8	1	245	885
4377	0	1	0	1	536	1093
4378	0	1	0	1	536	1088
4379	0	2	0	1	536	1171
4380	0	0	10	1	536	1172
4381	1	1	0	1	536	1176
4382	0	0	0	1	536	1167
4383	0	3	0	1	536	1168
4384	0	1	0	1	536	415
4385	0	0	9	1	536	424
4386	0	1	3	1	536	1441
151	0	2	0	1	70	521
152	0	1	0	1	70	527
153	0	0	0	1	70	530
154	3	5	0	1	70	531
155	0	0	0	1	70	532
156	0	0	10	1	70	535
157	0	0	0	1	70	747
158	0	2	0	1	70	749
159	5	5	0	1	70	751
160	0	1	0	1	70	752
161	1	1	0	1	70	739
162	0	0	10	1	70	741
845	0	1	0	1	145	626
846	0	1	0	1	145	628
847	0	0	9	1	145	632
848	3	4	0	1	145	637
849	0	1	0	1	145	641
850	0	1	0	1	145	1229
851	5	3	0	1	145	1230
852	0	2	0	1	145	1231
853	0	2	0	1	145	1235
854	1	0	9	1	145	1212
855	1	0	0	1	145	1215
\.


--
-- Data for Name: main_player; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."main_player" ("id", "name", "surname", "role", "goalsScored", "mvpPoints", "matches", "keeperPoints", "team_id") FROM stdin;
1228	Mateusz	Dziża	Player	0	0	0	0	53
55	Bartek	Buczak	Zawodnik z pola	0	0	0	0	10
57	Dariusz	Barcik	Zawodnik z pola	0	0	0	0	10
63	Michał	Nowak	Zawodnik z pola	0	0	0	0	10
69	Wojciech	Łojszczyk	Zawodnik z pola	0	0	0	0	10
70	Bartek	Kasztelewicz	Zawodnik z pola	0	0	0	0	10
71	Andrzej	Szaroń	Zawodnik z pola	0	0	0	0	10
72	Dominik	Kurzępa	Zawodnik z pola	0	0	0	0	10
73	Tomasz	Błoński	Zawodnik z pola	0	0	0	0	10
80	Bartosz	Urbańczyk	Zawodnik z pola	0	0	0	0	24
15	Dawid	Czechowicz	Zawodnik z pola	0	0	0	0	15
19	Karol	Kustal	Zawodnik z pola	0	0	0	0	15
43	Kuba	Michalik	Zawodnik z pola	0	0	0	0	18
81	Jakub	Roś	Zawodnik z pola	0	0	0	0	24
83	Jan	Robak	Zawodnik z pola	0	0	0	0	24
91	Jan	Kaniowski	Zawodnik z pola	0	0	0	0	24
87	Dawid	Staśko	Za	13	2	8	0	24
45	Filip	Poręba	Zawodnik z pola	3	0	6	0	18
40	Daniel	Tabor	Zawodnik z pola	0	3	6	0	18
13	Stanisław	Boczarski	Zawodnik z pola	3	0	5	0	15
39	Eryk	Wesołowski	zaw	3	3	6	0	18
42	Bartek	Everard	Zawodnik z pola	4	3	6	0	18
84	Jan	Van Der Brug	Zawodnik z pola	3	1	6	0	24
30	Maurycy	Jakubiec	Zawodnik z pola	9	4	5	0	17
11	Jakub	Kleczar	Zawodnik z pola	4	2	5	0	15
20	Łukasz	Różycki	Zawodnik z pola	1	0	6	0	15
18	Filip	Grzonka	Zawodnik z pola	5	0	4	0	15
12	Filip	Kreczmer	Zawodnik z pola	5	0	5	0	15
14	Karol	Sapiński	Zawodnik z pola	2	0	1	0	15
16	Karol	Kozuba	Zawodnik z pola	1	0	2	0	15
77	Michał	Dutkowski	Zawodnik z pola	0	0	1	0	24
50	Patryk	Michalik	Zawodnik z pola	0	0	1	0	18
64	Patryk	Kustosz	Zawodnik z pola	5	0	6	0	10
47	Grzegorz	Monsurek	Zawodnik z pola	3	0	1	0	18
90	Ignacy	Bujak	Zawodnik z pola	4	3	1	0	24
82	Jan	Kelpka	za	0	0	5	0	24
94	Hubert	Waś	Zawodnik z pola	2	0	2	0	26
25	Karol	Luźyński	Zawodnik z pola	2	0	6	0	17
86	Mateusz	Sikora	Zawodnik z pola	21	6	8	0	24
78	Tomasz	Jesionek	Zawodnik z pola	0	0	4	16	24
54	Amadeusz	Bufnal	Zawodnik z pola	5	10	4	0	10
79	Wojtek	Fenc	Zawodnik z pola	12	1	7	0	24
89	Franek	Rokowski	Zawodnik z pola	6	0	6	0	24
62	Maciej	Postek	Zawodnik z pola	4	0	5	0	10
34	Stanisław	Tynor	Zawodnik z pola	13	9	5	0	17
23	Jasiek	Jablonka	Zawodnik z pola	0	0	2	0	17
74	Antoni	Adamczyk	kapitan	4	0	4	0	24
88	Jasiek	Suberlak	Zawodnik z pola	2	0	1	0	24
85	Wiktor	Filipczyk	Zawodnik z pola	30	34	9	0	24
51	Patryk	Rakoczy	Zawodnik z pola	0	4	3	0	18
53	Adrian	Kołodziejczyk	Zawodnik z pola	0	0	1	0	10
61	Karol	Kitliński	Zawodnik z pola	2	0	2	0	10
67	Robert	Smyrak	Zawodnik z pola	3	5	4	0	10
60	Kacper	Kasprzyk	Zawodnik z pola	0	0	3	0	10
52	Łukasz	Litwin	kapitan	12	6	5	0	10
66	Przemysław	Wojdak	Zawodnik z pola	3	3	5	0	5
58	Jan	Zawiliński	Zawodnik z pola	0	0	0	0	10
75	Krzysztof	Boryczko	Zawodnik z pola	1	0	1	0	24
36	Tadeusz	Pieczarkowski	Zawodnik z pola	5	0	4	0	17
29	Mateusz	Ostrowski	Zawodnik z pola	1	0	2	0	17
37	Tadeusz	Pitera	Zawodnik z pola	1	3	5	28	17
33	Stanisław	Kosch	kapitan	0	0	2	0	17
95	Iwo	Szlachetko	Zawodnik z pola	0	0	1	0	26
38	Tomasz	Strach	Zawodnik z pola	0	0	2	0	17
35	Szymon	Olajossy	Zawodnik z pola	1	0	3	0	17
76	Maciek	Dynia	Zawodnik z pola	0	0	6	48.5	24
44	Jakub	Poręba	Zawodnik z pola	5	2	6	0	18
65	Paweł	Cerazy	Zawodnik z pola	0	0	6	49	10
21	Tomek	Tychoniak	Zawodnik z pola	20	15	5	0	15
93	Filip	Majka	Zawodnik z pola	14	10	5	0	26
17	Wiktor	Karcz	Zawodnik z pola	0	0	1	0	15
96	Kacper	Matwijewski	Zawodnik z pola	2	0	4	0	26
41	Szymon	Everard	kapitan	1	5	8	68.5	18
31	Michał	Kobierzynski	Zawodnik z pola	0	0	1	0	17
24	Kacper	Galek	Zawodnik z pola	0	0	2	0	17
26	Karol	Walczak	Zawodnik z pola	0	0	2	0	17
32	Piotr	Pyka	Zaw	0	0	3	23	17
56	Maurycy	Tokajuk	Zawodnik z pola	3	0	4	0	10
113	Kuba	Kopeć	Zawodnik z pola	0	0	0	0	25
115	Maciej	Bryg	Zawodnik z pola	0	0	0	0	25
117	Michał	Bryg	Zawodnik z pola	0	0	0	0	25
124	Marek	Górecki	Zawodnik z pola	0	0	0	0	25
128	Łukasz	Sumara	Zawodnik z pola	0	0	0	0	25
129	Mateusz	Kuś	Zawodnik z pola	0	0	0	0	25
134	Filip	Puchała	Zawodnik z pola	0	0	0	0	25
135	Dominik	Powierża	Zawodnik z pola	0	0	0	0	25
147	Maciek	Wiszniewski	za	0	0	0	0	23
151	Wojtek	Jaszcz	Zawodnik z pola	0	0	0	0	23
154	Sebastian	Zięba	Zawodnik z pola	0	0	0	0	27
157	Marek	Żukowski	Zawodnik z pola	0	0	0	0	27
161	Dawid	Porwański	Zawodnik z pola	0	0	0	0	27
162	Paweł	Żak	Zawodnik z pola	0	0	0	0	27
164	Mariusz	Klejdysz	Zawodnik z pola	0	0	0	0	27
169	Wojciech	Żuk	Zawodnik z pola	0	0	0	0	27
92	Dawid	Marzec	kapitan	11	18	7	0	26
173	Yauhen	Kavalueski	Zawodnik z pola	1	0	4	0	38
98	Kamil	Bieńko	za	12	1	7	0	26
156	Paweł	Cichoń	Zawodnik z pola	0	1	2	18	27
172	Konstantin	Runets	Zawodnik z pola	0	0	2	0	38
120	Oskar	Stoczek	Zawodnik z pola	8	0	5	0	25
150	Jakub	Kotyza	Zawodnik z pola	0	0	6	0	23
166	Daniel	Walenciak	Zawodnik z pola	0	0	2	0	27
141	Michał	Jasik	Zawodnik z pola	1	0	3	0	23
145	Kacper	Grudziński	za	0	0	3	0	23
148	Daniel	Wojtaszkiewicz	Zawodnik z pola	1	0	3	0	23
143	Szymon	Sikora	Zawodnik z pola	16	13	9	0	23
144	Gabriel	Zawałkiewicz	Zawodnik z pola	0	0	1	0	23
175	Anton	Pashkevich	Zawodnik z pola	0	0	2	0	38
138	Krzysztof	Jaszcz	Zawodnik z pola	3	2	5	0	23
140	Adrian	Ochalik	Zawodnik z pola	2	5	8	0	23
163	Jacek	Kogut	Zawodnik z pola	0	0	2	0	27
159	Łukasz	Matyjasz	Zawodnik z pola	0	0	1	0	27
170	Krystian	Filipek	Zawodnik z pola	4	1	3	0	27
155	Łukasz	Pieczara	Zawodnik z pola	0	0	2	0	27
168	Emanuel	Wściubiak	Zawodnik z pola	0	0	2	17	27
167	Paweł	Kozieł	Zawodnik z pola	1	0	1	0	27
139	Antek	Ochalik	Zawodnik z pola	2	0	10	0	23
109	Arkadiusz	Górecki	Zawodnik z pola	5	1	8	0	25
131	Krzysztof	Baran	Zawodnik z pola	8	3	6	0	25
137	Kuba	Kobylarczyk	kap	0	1	10	92	23
122	Wiktor	Giętka	Zawodnik z pola	0	0	5	45	25
130	Benedykt	Krawczuk	Zawodnik z pola	1	0	5	0	25
116	Mateusz	Gajda	Zawodnik z pola	4	1	5	0	25
133	Bartłomiej	Tokarz	Zawodnik z pola	5	5	4	0	25
110	Dawid	Pindel	Zawodnik z pola	8	10	7	0	25
99	Kamil	Klimas	zaw	0	0	2	0	26
121	Mateusz	Woźniak	Zawodnik z pola	1	5	2	0	25
149	Mateusz	Kasprzyk	Zawodnik z pola	4	0	1	0	23
180	Alexander	Tatulchankau	Zawodnik z pola	3	3	5	0	38
114	Łukasz	Dziuba	Zawodnik z pola	3	0	8	0	25
119	Michał	Mucha	Zawodnik z pola	0	0	1	8	25
176	Roman	Ledak	Zawodnik z pola	0	0	2	0	38
178	Aliaksei	Mandryk	Zawodnik z pola	1	0	2	8	38
179	Pawel	Mandryk	Zawodnik z pola	0	0	3	0	38
152	Bartek	Bogusz	za	3	0	7	0	23
126	Mateusz	Łabuś	Zawodnik z pola	5	3	3	0	25
118	Michał	Kękuś	Zawodnik z pola	1	1	9	0	25
158	Paweł	CHałubek	Zawodnik z pola	0	0	1	0	27
112	Krystian	Opach	Zawodnik z pola	16	0	7	0	25
125	Wojciech	Piwko	Zawodnik z pola	5	6	9	0	25
107	Oskar	Bodek	Zawodnik z pola	3	1	4	0	26
132	Krystian	Nowak	Zawodnik z pola	0	0	1	0	25
160	Mateusz	Długosz	Zawodnik z pola	1	3	2	17	27
123	Krzysztof	Zachwieja	Zawodnik z pola	0	0	1	0	25
153	Maciej	Pala	kapitan	1	0	3	0	27
127	Szymon	Bończyk	Zawodnik z pola	0	0	1	8	25
28	Marcin	Dud	Zawodnik z pola	0	0	2	0	17
97	Kacper	Suchowski	Zawodnik z pola	0	0	1	0	26
100	Konrad	Kasperczyk	Zawodnik z pola	0	0	1	0	26
101	Konrad	Strzałka	Zawodnik z pola	0	0	1	0	26
104	Marcin	Szuberla	Zawodnik z pola	1	0	1	0	26
106	Michał	Sodo	Zawodnik z pola	0	0	1	0	26
103	Maks	Krawczyk	Zawodnik z pola	0	1	2	0	26
108	Tomek	Słupski	Zawodnik z pola	4	0	4	0	26
136	Oskar	Adamczyk	kapitan	4	1	6	0	23
142	Mikołaj	Wójcik	Zawodnik z pola	39	29	8	0	23
111	Dymitr	Krawczuk	Zawodnik z pola	12	6	9	0	25
200	Jacek	Niemiec	Zawodnik z pola	0	0	0	0	48
201	Jakub	Deląg	Zawodnik z pola	0	0	0	0	48
202	Jakub	Gocał	Zawodnik z pola	0	0	0	0	48
203	Jakub	Miazga	Zawodnik z pola	0	0	0	0	48
206	Kamil	Cisło	Zawodnik z pola	0	0	0	0	48
207	Krzysztof	Baran	Zawodnik z pola	0	0	0	0	48
209	Marcin	Fabisiewicz	Zawodnik z pola	0	0	0	0	48
211	Mateusz	Różkowski	Zawodnik z pola	0	0	0	0	48
212	Michał	Bielawski	Zawodnik z pola	0	0	0	0	48
215	Michał	Mróz	Zawodnik z pola	0	0	0	0	48
216	Miłosz	Rzyczniak	Zawodnik z pola	0	0	0	0	48
217	Paweł	Pelczar	Zawodnik z pola	0	0	0	0	48
218	Piotr	Badura	Zawodnik z pola	0	0	0	0	48
219	Piotr	Karola	Zawodnik z pola	0	0	0	0	48
222	Piotr	Słowakiewicz	Zawodnik z pola	0	0	0	0	48
223	Stanisław	Czubek	Zawodnik z pola	0	0	0	0	48
225	Szymon	Pyzik	Zawodnik z pola	0	0	0	0	48
227	Tadeusz	Zalewski	Zawodnik z pola	0	0	0	0	48
228	Tom	Tom	Zawodnik z pola	0	0	0	0	48
230	Wojtek	Popławski	Zawodnik z pola	0	0	0	0	48
231	Wojtek	Zalewski	Zawodnik z pola	0	0	0	0	48
232	Tomasz	Smołka	Zawodnik z pola	0	0	0	0	48
233	Jakub	Podsiadło	Zawodnik z pola	0	0	0	0	48
234	Filip	Derda	Zawodnik z pola	0	0	0	0	48
208	Maksymilina	Wojczuk	Zawodnik z pola	1	0	1	0	48
210	Mateusz	Baran	Zawodnik z pola	0	0	1	0	48
226	Szymon	Spiradek	Zawodnik z pola	1	0	1	0	48
187	Andrzej	Dorobisz	Zawodnik z pola	0	0	1	0	48
188	Andrzej	Dumanowski	Zawodnik z pola	0	0	1	0	48
189	Arkadiusz	Micek	Zawodnik z pola	0	0	1	0	48
190	Arkadiusz	Wójcik	Zawodnik z pola	0	0	1	0	48
196	Franek	Rychlak	Zawodnik z pola	2	0	1	0	48
198	Jacek	Bazan	Zawodnik z pola	0	0	1	0	48
199	Jacek	Kulakowski	Zawodnik z pola	0	0	1	0	48
205	Jakub	Wolski	Zawodnik z pola	0	0	2	13	48
192	Bohdan	Sobiecki	Zawodnik z pola	0	0	2	10	48
204	Jakub	Palczewski	Zawodnik z pola	0	0	2	0	48
213	Michał	Drzewiej	Zawodnik z pola	0	0	2	0	48
221	Piotr	Mróz	Zawodnik z pola	3	3	1	0	48
220	Piotr	Kulis	Zawodnik z pola	0	1	2	0	48
191	Augustyn	Moskal	Zawodnik z pola	0	0	3	0	48
214	Michał	Kruk	Zawodnik z pola	1	0	4	16	48
181	Ivan	Dantsevich	Zawodnik z pola	0	0	3	0	38
195	Filip	Kowalewski	Zawodnik z pola	2	0	2	0	48
229	Wojciech	Palczewski	Zawodnik z pola	0	0	2	0	48
193	Damian	Świerk	Zawodnik z pola	2	0	2	8	48
197	Hubert	Dziadzio	Zawodnik z pola	3	3	3	9	48
182	Renis	Hodo	Zawodnik z pola	2	0	3	0	38
183	Zmicier	Ramancou	Zawodnik z pola	1	0	3	0	38
174	Alex	Grasievich	Zawodnik z pola	1	0	4	0	38
177	Aliaksei	Shydlouski	Zawodnik z pola	3	3	4	0	38
185	Illia	Pigusov	Zawodnik z pola	1	0	4	0	38
264	Jakub	Bednar	Zawodnik z pola	0	0	2	0	39
262	Adrian	Klimas	Zawodnik z pola	1	0	4	0	39
259	Rafał	Pomykała	Zawodnik z pola	0	0	4	0	39
224	Stanisław	Zieliński	Zawodnik z pola	4	8	2	0	48
171	Dmitrij	Malczik	Kapitan	0	4	5	35	38
290	Mateusz	Nasuto	Zawodnik z pola	0	0	0	0	49
317	Hubert	Gąsior	Zawodnik z pola	0	0	0	0	41
320	Kacper	Górecki	Zawodnik z pola	0	0	0	0	41
322	Kuba	Barber	Zawodnik z pola	0	0	0	0	41
324	Maciej	Dworakowski	Zawodnik z pola	0	0	0	0	41
302	Patryk	Bąk	Zawodnik z pola	8	0	5	0	45
260	Roman	Klimas	Kapitan	8	4	7	0	39
267	Karol	Malinowski	Zawodnik z pola	1	0	4	0	39
271	Mateusz	Hendzel	Zawodnik z pola	2	0	5	0	39
261	Michał	Stawowski	Zawodnik z pola	1	0	6	13	39
272	Mateusz	Kużdżal	Zawodnik z pola	0	0	4	0	39
268	Patryk	Przęczek	Zawodnik z pola	0	3	7	34	39
270	Michał	Kardasz	Zawodnik z pola	0	0	3	0	39
291	Jakub	Bugaj	Kapitan	3	3	7	0	45
296	Szymon	Wesołowski	Zawodnik z pola	2	0	4	0	45
300	Maks	Ślusarczyk	Zawodnik z pola	2	0	4	0	45
303	Michał	Dykacz	Zawodnik z pola	2	5	3	0	45
339	Olek	Czop	Zawodnik z pola	1	0	6	0	42
305	Jakub	Warchał	Zawodnik z pola	0	0	4	38	45
326	Mateusz	Rożek	Zawodnik z pola	6	3	9	0	41
307	Karol	Gzyl	Zawodnik z pola	1	0	2	0	45
306	Kacper	Zacharski	Zawodnik z pola	2	0	6	9	45
299	Dawid	Ciuba	Zawodnik z pola	2	4	7	0	45
334	Michał	Hajdo	Zawodnik z pola	1	0	6	0	42
328	Michał	Pardygał	Zawodnik z pola	7	1	12	0	41
319	Mateusz	Stawik	Zawodnik z pola	1	0	2	9	41
325	Maks	Kruszec	Zawodnik z pola	1	0	2	0	41
316	Damian	Świca	Zawodnik z pola	0	0	4	0	41
311	Kacper	Piszczek	Zawodnik z pola	1	1	7	0	41
323	Kuba	Uchacz	Zawodnik z pola	1	0	4	0	41
273	Janek	Gręda	Zawodnik z pola	0	0	2	0	39
327	Michał	Najder	Zawodnik z pola	0	0	3	0	41
318	Jędrzej	Ściegienny	Zawodnik z pola	0	0	2	0	41
313	Adam	Wątor	Zawodnik z pola	14	20	8	0	41
276	Łukasz	Arłamowski	Zawodnik z pola	2	3	1	0	49
354	Maciek	Sitarski	Zawodnik z pola	0	0	1	0	37
315	Bartek	Gąsior	Zawodnik z pola	3	1	2	0	41
298	Jakub	Markiewicz	Zawodnik z pola	10	1	5	0	45
331	Piotr	Broda	Zawodnik z pola	11	10	11	0	41
321	Kacper	Kalita	Zawodnik z pola	3	5	9	0	41
348	Maks	Kawiorski	Zawodnik z pola	7	0	6	0	42
310	Mateusz	Śmiech	Kapitan	18	9	12	0	41
330	Patryk	Torba	Zawodnik z pola	1	3	4	0	41
329	Mikołaj	Wnuk	Zawodnik z pola	0	0	2	0	41
345	Mateusz	Marszałek	Zawodnik z pola	1	1	5	0	42
338	Daniel	Kruk	Zawodnik z pola	1	0	6	0	42
346	Maciek	Sawicki	Zawodnik z pola	2	0	5	0	42
282	Szymon	Celejewski	Zawodnik z pola	0	0	2	14	49
275	Jakub	Bąkowski	Kapitan	0	0	1	0	49
287	Patryk	Jackowicz	Zawodnik z pola	0	0	1	0	49
288	Szymon	Wcisło	Zawodnik z pola	0	0	1	0	49
289	Przemysław	Rychlik	Zawodnik z pola	0	0	1	0	49
347	Filip	Kucharczyk	Zawodnik z pola	0	0	5	0	42
353	Szymon	Barasz	Zawodnik z pola	3	0	1	0	37
352	Damian	Pstruś	Zawodnik z pola	2	0	2	0	37
294	Patryk	Daniec	Zawodnik z pola	5	0	6	0	45
349	Marcel	Zając	Zawodnik z pola	0	0	5	0	42
333	Mateusz	Niżnik	Zawodnik z pola	1	3	6	35	42
312	Mateusz	Torba	Zawodnik z pola	0	0	4	0	41
263	Dominik	Kasznik	Zawodnik z pola	6	1	6	0	39
274	Marian	Rybak	Zawodnik z pola	0	0	4	0	39
266	Arek	Pol	Zawodnik z pola	10	0	6	0	39
355	Hubert	Szewczyk	Zawodnik z pola	3	0	3	0	37
295	Adam	Tran Thi Thu	Zawodnik z pola	4	1	3	0	45
280	Kacper	Szydło	Zawodnik z pola	2	0	1	0	49
337	Staszek	Szajding	Zawodnik z pola	1	0	6	0	42
265	Josef	--------	Zawodnik z pola	9	8	6	0	39
286	Tomasz	Lipieta	Zawodnik z pola	3	3	1	0	49
279	Dariusz	Skalski	Zawodnik z pola	3	0	2	0	49
304	Adrian	Maślanka	Zawodnik z pola	0	0	1	0	45
297	Kacper	Matwijewski	Zawodnik z pola	2	0	3	0	45
301	Krystian	Opach	Zawodnik z pola	4	0	2	0	45
293	Szymon	Muniak	Zawodnik z pola	1	0	3	0	45
277	Jakub	Kukla	Zawodnik z pola	0	0	1	0	49
278	Marcin	Pulnar	Zawodnik z pola	3	3	1	0	49
281	Łukasz	Nowak	Zawodnik z pola	1	0	1	0	49
283	Kamil	Gołębiowski	Zawodnik z pola	0	0	1	0	49
284	Jakub	Maj	Zawodnik z pola	0	0	1	0	49
357	Kerim	Jemaaoui	Zawodnik z pola	0	0	0	0	37
359	Oskar	Midera	Zawodnik z pola	0	0	0	0	37
377	Piotr	Hanusiak	Zawodnik z pola	0	0	0	0	34
380	Adrian	Poźniak	Zawodnik z pola	0	0	0	0	34
386	Michał	Dudek	Zawodnik z pola	0	0	0	0	34
388	Wojciech	Gucwa	Zawodnik z pola	0	0	0	0	34
389	Marcel	Mazur	Zawodnik z pola	0	0	0	0	34
393	Oskar	Świątek	Zawodnik z pola	0	0	0	0	34
394	Szymon	Synowiecki	Zawodnik z pola	0	0	0	0	34
395	Darek	Nowak	Zawodnik z pola	0	0	0	0	34
397	Dawid	Wasserman	Zawodnik z pola	0	0	0	0	34
401	Kamil	Wypartowicz	Zawodnik z pola	0	0	0	0	33
403	Jacek	Wypartowicz	Zawodnik z pola	0	0	0	0	33
404	Bartek	Wypartowicz	Zawodnik z pola	0	0	0	0	33
405	Kamil	Tyczyński	Zawodnik z pola	0	0	0	0	33
407	Damian	Piąstka	Zawodnik z pola	0	0	0	0	33
408	Michał	Mitoński	Zawodnik z pola	0	0	0	0	33
409	Mateusz	Grochowski	Zawodnik z pola	0	0	0	0	33
410	Łukasz	Hojol	Zawodnik z pola	0	0	0	0	33
428	Rafał	Roczniak	Zawodnik z pola	0	0	0	0	19
432	Kacper	Kruczek	Zawodnik z pola	0	0	0	0	28
433	Bartosz	Woźniak	Zawodnik z pola	0	0	0	0	28
437	Kamil	Włodarski	Zawodnik z pola	0	0	0	0	28
440	Oskar	Kiepura	Zawodnik z pola	0	0	0	0	28
441	Adam	Gierasiński	Zawodnik z pola	0	0	0	0	28
356	Kacper	Podlewski	Zawodnik z pola	5	0	5	0	37
367	Dawid	Nowicki	Zawodnik z pola	7	0	4	0	35
369	Karol	Waz	Zawodnik z pola	0	0	5	24	35
365	Mateusz	Psica	kapitan	14	3	5	0	35
372	Michał	Capik	Zawodnik z pola	4	0	4	0	35
371	Arkadiusz	Baran	Zawodnik z pola	12	1	3	0	35
366	Miłosz	Śmiały	Zawodnik z pola	5	0	5	7	35
373	Michał	Kurowski	Zawodnik z pola	0	0	3	0	35
374	Eryk	Nowicki	Zawodnik z pola	0	0	2	0	35
335	Szymon	Pyrcz	Zawodnik z pola	7	1	9	0	42
398	Tomasz	Lipieta	Zawodnik z pola	12	6	8	0	34
399	Michał	Szarlej	Zawodnik z pola	3	1	6	0	34
384	Łukasz	Krawczyk	Zawodnik z pola	0	0	2	15	34
376	Szymon	Wcisło	kapitan	1	0	6	0	34
383	Bartłomiej	Sitek	Zawodnik z pola	12	5	4	0	34
332	Shun	Ishikawa	Zawodnik z pola	0	0	6	16	42
385	Jan	Kępa	Zawodnik z pola	52	38	9	0	34
378	Kamil	Gołębiowski	Zawodnik z pola	4	2	2	0	34
439	Patryk	Gawin	Zawodnik z pola	8	2	4	0	28
430	Bartłomiej	Bugaj	kapitan	0	0	4	0	28
431	Jakub	Swatowski	Zawodnik z pola	7	11	3	0	28
436	Adrian	Włodarski	Zawodnik z pola	2	3	4	0	28
358	Mateusz	Iwaniec	Zawodnik z pola	5	0	4	0	37
336	Olaf	Nowak	Zawodnik z pola	1	0	6	0	42
342	Jeremi	Kowalski	Zawodnik z pola	0	0	11	55	42
343	Jan	Drochliński	Zawodnik z pola	2	3	6	0	42
420	Paweł	Juszczyk	Zawodnik z pola	3	1	2	0	19
434	Maciek	Markiewicz	Zawodnik z pola	2	0	4	0	28
400	Radosław	Dachowski	kapitan	2	3	1	0	33
402	Daniel	Wypartowicz	Zawodnik z pola	0	0	1	7	33
406	Tomek	Piąstka	Zawodnik z pola	1	0	1	0	33
364	Filip	Kreczmer	Zawodnik z pola	8	0	5	0	37
419	Piotr	Sucharski	Zawodnik z pola	0	0	1	8	19
425	Igor	Włodarz	Zawodnik z pola	1	0	3	9	19
370	Mateusz	Bajak	Zawodnik z pola	0	0	2	0	35
422	Dominik	Tomaszewski	Zawodnik z pola	15	6	4	0	19
363	Jakub	Kleczar	Zawodnik z pola	1	1	7	0	37
309	Jakub	Wierzchowski	Zawodnik z pola	0	0	6	52	45
396	Norbert	Uchacz	Zawodnik z pola	0	0	2	0	34
368	Nataniel	Borek	Zawodnik z pola	4	0	5	0	35
387	Kacper	Okulski	Zawodnik z pola	0	0	2	0	34
391	Damian	Serafin	Zawodnik z pola	12	10	5	0	34
438	Kacper	Federowicz	Zawodnik z pola	0	0	1	0	28
427	Łukasz	Pawlik	Zawodnik z pola	0	0	1	0	19
392	Maciej	Federowicz	Zawodnik z pola	4	0	9	0	34
344	Mateusz	Pulchny	Kapitan	17	10	10	0	42
341	Franek	Wiehle	Zawodnik z pola	6	0	7	0	42
418	Mateusz	Niedopytalski	Zawodnik z pola	0	3	4	36	19
379	Mikołaj	Batko	Zawodnik z pola	0	0	3	0	34
381	Mateusz	Nasuto	Zawodnik z pola	0	0	1	9	34
390	Arkadiusz	Nosal	Zawodnik z pola	4	0	6	0	34
1229	Adrian	Czarnecki	Player	6	0	4	0	53
413	Sebastian	Firlej	kapitan	10	3	6	0	19
435	Fabian	Kiepura	Zawodnik z pola	0	0	6	53	28
423	Maciek	Boguta	Zawodnik z pola	0	0	1	0	19
426	Jacek	Brzegowy	Zawodnik z pola	0	0	1	0	19
429	Maciej	Stuhr	Zawodnik z pola	1	0	1	0	19
448	Kacper	Windak	Zawodnik z pola	0	0	0	0	28
457	Tymoteusz	Policha	Zawodnik z pola	0	0	0	0	64
475	Jan	Cybulski	Zawodnik z pola	0	0	0	0	55
483	Radek	Kubacki	Zawodnik z pola	0	0	0	0	66
485	Marek	Hessel	Zawodnik z pola	0	0	0	0	66
486	Konrad	Śmietana	Zawodnik z pola	0	0	0	0	66
488	Jakub	Ptak	Zawodnik z pola	0	0	0	0	66
509	Maksymilian	Sobociński	Zawodnik z pola	0	0	0	0	60
489	Mateusz	Rybicki	Zawodnik z pola	3	0	2	8	66
463	Kacper	Sirko	Zawodnik z pola	2	1	8	0	64
518	Adam	Koprowski	Zawodnik z pola	0	0	0	0	69
522	Szymon	Antończyk	Zawodnik z pola	0	0	0	0	57
523	Natalia	Bania	Zawodnik z pola	0	0	0	0	57
524	Jakub	Biernacki	Zawodnik z pola	0	0	0	0	57
470	Tomasz	Poradzisz	Zawodnik z pola	0	0	6	48	55
466	Adam	Nowak	Zawodnik z pola	29	41	15	0	55
461	Daniel	Tkaczuk	Zawodnik z pola	4	0	8	0	64
476	Antek	Sędzimir	Zawodnik z pola	0	0	4	18	55
464	Konrad	Rudziński	kapitan	11	2	15	0	55
474	Oskar	Zaręba	Zawodnik z pola	3	0	3	0	55
525	Bartłomiej	Bogdewicz	Zawodnik z pola	0	1	2	19	57
362	Karol	Sapiński	Zawodnik z pola	3	6	6	0	37
454	Aron	Król	Zawodnik z pola	1	13	5	3	64
455	Krzysztof	Malina	Zawodnik z pola	20	0	12	0	64
462	Mateusz	Krzak	Zawodnik z pola	40	14	11	0	64
456	Jakub	Chruszcz	Zawodnik z pola	14	6	6	0	64
472	Filip	Kolasa	Zawodnik z pola	22	3	12	0	55
458	Piotr	Sucharski	Zawodnik z pola	4	0	2	0	64
412	Kamil	Gawęda	kapitan	3	0	5	0	19
452	Igor	Maślej	Zawodnik z pola	2	0	8	0	64
503	Oliwier	Kłyś	Zawodnik z pola	8	6	6	0	60
471	Jan	Nowacki	Zawodnik z pola	6	0	11	0	55
469	Patryk	Drobniak	Zawodnik z pola	76	19	15	0	55
451	Theodore	Townsend	Zawodnik z pola	5	0	9	0	64
473	Arkadiusz	Rudziński	Zawodnik z pola	3	0	2	0	55
478	Grzegorz	Rybicki	Bramkarz	2	3	3	10	66
460	Damian	Głogowski	Zawodnik z pola	6	1	9	0	64
450	Mateusz	Łabuś	Zawodnik z pola	9	11	5	0	64
528	Jan	Kotyła	Zawodnik z pola	0	0	2	0	57
453	Filip	Kowalski	Zawodnik z pola	1	9	14	116	64
449	Jakub	Brzozowski	kapitan	22	8	10	0	64
496	Jan	Puchała	Zawodnik z pola	11	2	6	11	60
361	Jakub	Prostak	Kapitan	7	5	9	0	37
495	Kuba	Badowski	Zawodnik z pola	0	0	2	0	60
482	Sebastian	Kaczor	Zawodnik z pola	1	0	1	0	66
507	Stefek	Barylski	Zawodnik z pola	10	0	3	0	60
499	Tymon	Budyń	Zawodnik z pola	1	0	2	0	60
502	Tadeusz	Mularczyk	Zawodnik z pola	0	0	2	0	60
506	Jan	Jodłowski	Zawodnik z pola	1	0	2	0	60
500	Eryk	Gucio	Zawodnik z pola	1	0	5	0	60
494	Marcin	Dudek	Zawodnik z pola	1	0	3	0	60
468	Artur	Nowak	Zawodnik z pola	2	3	12	23	55
497	Leon	Hołda	Zawodnik z pola	1	0	3	0	60
527	Jan	Jędrusiak	Zawodnik z pola	5	0	9	36	57
415	Łukasz	Janiszewski	Zawodnik z pola	9	5	4	0	19
480	Krzysztof	Goldman	Bramkarz	3	0	1	0	66
459	Piotr	Sucharski	Zawodnik z pola	0	0	1	0	64
360	Staszek	Boczarski	Zawodnik z pola	10	11	29	0	37
444	Kuba	Nowak	Zawodnik z pola	8	0	4	0	28
411	Sylewster	Koza	kapitan	0	0	2	0	19
445	Wiktor	Pompka	Zawodnik z pola	0	0	2	0	28
447	Tymek	Leśniak	Zawodnik z pola	1	0	1	0	28
491	Karol	Strączyński	Zawodnik z pola	0	0	3	0	60
479	Jakub	Polus	Bramkarz	0	0	3	20	66
481	Witek	Łuszcz	Zawodnik z pola	4	3	3	0	66
501	Patryk	Bobak	Zawodnik z pola	1	0	1	0	60
526	Miłosz	Hańczyk	Zawodnik z pola	0	0	3	0	57
484	Jacek	Hessel	Zawodnik z pola	1	3	1	0	66
442	Franciszek	Godfrajów	Zawodnik z pola	0	0	1	0	28
421	Szymon	Wojtaszek	Zawodnik z pola	5	1	4	0	19
424	Adrian	Żurowicz	Zawodnik z pola	0	0	4	34	19
487	Łukasz	Wojtal	Zawodnik z pola	1	0	1	0	66
477	Michał	Derdaś	kapitan	9	6	4	0	66
417	Jakub	Tabor	za	9	8	6	0	19
492	Paweł	Cichoń	Zawodnik z pola	0	0	2	0	60
443	Andrzej	Bugaj	Zawodnik z pola	0	0	2	0	28
588	Jan	Wydziałkiewicz	Zawodnik z pola	0	1	4	35	44
519	Paweł	Cieśl	Zawodnik z pola	0	0	1	0	69
493	Janek	Lepak	Zawodnik z pola	8	6	2	0	60
541	Jakub	Puto	Zawodnik z pola	0	0	0	0	20
544	Filip	Gwiźdź	Zawodnik z pola	0	0	0	0	20
546	Mateusz	Gajewski	Zawodnik z pola	0	0	0	0	20
547	Oleksii	Soldatenko	Zawodnik z pola	0	0	0	0	20
548	Grzegorz	Synowiec	Zawodnik z pola	0	0	0	0	20
550	Gabriel	Kruba	Zawodnik z pola	0	0	0	0	20
559	Hubert	Biedermann	Zawodnik z pola	0	0	0	0	63
562	Tymoteusz	Grabowski	Zawodnik z pola	0	0	0	0	63
564	Michał	Magiera	Zawodnik z pola	0	0	0	0	63
565	Jan	Doerre	Zawodnik z pola	0	0	0	0	63
568	Jan	Olejniczak	Zawodnik z pola	0	0	0	0	63
577	Mikołaj	Piętak	Zawodnik z pola	0	0	0	0	63
591	Kacper	Wydziałkiewicz	Zawodnik z pola	0	0	1	0	44
581	Łukasz	Dziuba	Zawodnik z pola	0	0	0	0	44
582	Dawid	Pindel	Zawodnik z pola	0	0	0	0	44
584	Oskar	Stoczek	Zawodnik z pola	0	0	0	0	44
602	Michał	Latinek	Zawodnik z pola	0	0	0	0	43
606	Jakub	Wolkowicz	Zawodnik z pola	0	0	0	0	43
607	Antoni	Skowron	Zawodnik z pola	0	0	0	0	43
608	Bruno	Kijowski	Zawodnik z pola	0	0	0	0	43
609	Iwo	Frankiewicz	Zawodnik z pola	0	0	0	0	43
575	Paweł	Myszkowski	Zawodnik z pola	0	0	1	0	63
515	Paweł	Kulczak	Zawodnik z pola	16	5	16	0	69
574	Maksymilian	Baran	Zawodnik z pola	0	0	1	0	63
513	Maciej	Woś	Zawodnik z pola	36	20	11	0	69
603	Józek	Kowalski	Zawodnik z pola	0	0	2	0	43
601	Jędrek	Krupiński	Zawodnik z pola	0	0	1	0	43
604	Michał	Rejszek	Zawodnik z pola	0	0	2	0	43
605	Wiktor	Sierant	Zawodnik z pola	0	0	2	0	43
611	Szymon	Kumorek	Zawodnik z pola	0	0	2	0	43
612	Michał	Fundament	Zawodnik z pola	0	0	2	7	43
613	Mateusz	Guzowski	Zawodnik z pola	3	3	2	0	43
560	Łukasz	Janeczko	Zawodnik z pola	0	0	2	0	63
614	Marcel	Turaj	Zawodnik z pola	0	0	1	0	43
543	Mateusz	Filipek	Zawodnik z pola	0	3	1	6	63
570	Sebastian	Wójcik	Zawodnik z pola	0	11	6	38	63
566	Michał	Studziżba	Zawodnik z pola	2	0	4	0	63
572	Rafał	Bochenek	Zawodnik z pola	6	0	3	0	63
561	Jakub	Maczeński	Zawodnik z pola	0	0	3	0	63
498	Wiktor	Banachowicz	Zawodnik z pola	7	19	7	0	60
539	Paweł	Ptaśnik	Zawodnik z pola	0	0	3	26	20
557	Damian	Horosin	Zawodnik z pola	1	0	3	8	20
610	Kamil	Kaczmarczyk	Zawodnik z pola	0	0	1	0	43
533	Kacper	Śliwa	Zawodnik z pola	15	2	6	0	57
556	Adrian	Kruba	za	12	6	5	0	20
536	Patryk	Hajduk	Zawodnik z pola	5	3	1	0	20
555	Hubert	Wasilewski	Zawodnik z pola	3	0	4	0	20
580	Kuba	Wiśniewski	Zawodnik z pola	2	0	2	0	20
508	Mateusz	Ponczek	Zawodnik z pola	1	0	3	0	60
540	Rafał	Kościółek	Zawodnik z pola	9	1	5	0	20
545	Oskar	Adamczyk	Zawodnik z pola	1	0	2	0	20
553	Damian	Leśniak	Zawodnik z pola	37	19	7	0	20
490	Olek	Dziedzic	Zawodnik z pola	0	0	6	47	60
592	Miłosz	Borowicki	Zawodnik z pola	0	3	9	0	44
576	Krzysztof	Kazibudzki	Zawodnik z pola	0	1	6	0	63
516	Adrian	Juraś	Zawodnik z pola	16	3	12	0	69
529	Franciszek	Kwinta	Zawodnik z pola	1	0	2	0	57
549	Grzegorz	Jabłoński	Zawodnik z pola	4	0	3	0	20
578	Adrian	Kruba	Zawodnik z pola	0	0	1	0	63
537	Mateusz	Cierpik	Zawodnik z pola	0	0	1	0	20
505	Filip	Adamczyk	Zawodnik z pola	5	0	4	0	60
504	Patryk	Galas	Zawodnik z pola	2	0	3	0	60
1233	Patryk	Likus	Player	3	0	3	0	53
542	Tomasz	Kozak	Zawodnik z pola	0	1	5	45	63
571	Kamil	Zdeb	Zawodnik z pola	7	0	4	0	63
567	Michał	Pilch	Zawodnik z pola	2	0	1	0	63
552	Mateusz	Hrones	Zawodnik z pola	5	0	4	0	20
551	Eryk	Iwaszko	kapitan	3	0	5	0	20
600	Wiktor	Waligóra	Zawodnik z pola	2	6	3	8	43
596	Wojciech	Socha	Zawodnik z pola	6	3	5	0	44
510	Tomasz	Zwoliński	Zawodnik z pola	18	34	14	0	69
573	Norbert	Polak	kapitan	7	0	8	0	63
538	Wiktor	Pietrzykowski	Zawodnik z pola	1	0	2	0	20
534	Bartłomiej	Świtalski	kapitan	1	0	6	0	57
520	Renan	Primo	Nunes	1	4	15	141	69
616	Adam	Ledwon	Zawodnik z pola	0	0	0	0	43
617	Hubert	Waś	Zawodnik z pola	0	0	0	0	43
619	Wiktor	Gajoch	Zawodnik z pola	0	0	0	0	43
620	Maciek	Laidler	Kapitan	0	0	0	0	43
621	Marcin	Rajtar	Zawodnik z pola	0	0	0	0	50
622	Anatol	Strąk	Zawodnik z pola	0	0	0	0	50
624	Dawid	Machno	Zawodnik z pola	0	0	0	0	50
625	Eryk	Włodek	Zawodnik z pola	0	0	0	0	50
627	Filip	Morgun	Zawodnik z pola	0	0	0	0	50
628	Filip	Zięcina	Kapitan	0	0	0	0	50
629	Igor	Wałęga	Zawodnik z pola	0	0	0	0	50
630	Jan	Doniec	Zawodnik z pola	0	0	0	0	50
631	Janusz	Jagiełło	Zawodnik z pola	0	0	0	0	50
632	Kuba	Kobylarczyk	Zawodnik z pola	0	0	0	0	50
633	Maciek	Kosydar	Zawodnik z pola	0	0	0	0	50
634	Mateusz	Adamski	Zawodnik z pola	0	0	0	0	50
635	Mateusz	Wójcik	Zawodnik z pola	0	0	0	0	50
636	Michał	Przybyło	Zawodnik z pola	0	0	0	0	50
637	Norbert	Kasperek	Zawodnik z pola	0	0	0	0	50
638	Piotr	Langier	Zawodnik z pola	0	0	0	0	50
639	Stachu	Kiepura	Zawodnik z pola	0	0	0	0	50
657	Jakub	Podraza	Zawodnik z pola	0	0	0	0	68
664	Piotr	Pęczak	Zawodnik z pola	0	0	0	0	68
684	Stanisław	Smoczyński	Zawodnik z pola	0	0	0	0	72
686	Michał	Stopa	Zawodnik z pola	0	0	0	0	72
687	Jakub	Przedlacki	Zawodnik z pola	0	0	0	0	72
689	Bartłomiej	Gostyński	Zawodnik z pola	0	0	0	0	72
690	Dawid	Markowski	Zawodnik z pola	0	0	0	0	72
691	Dawid	Malik	Zawodnik z pola	0	0	0	0	72
693	Zuza	Sołonczak	Zawodnik z pola	0	0	0	0	72
694	Oliwier	Lassota	Zawodnik z pola	0	0	0	0	72
696	Filip	Filipczyk	Zawodnik z pola	0	0	0	0	72
590	Maciej	Serafin	Zawodnik z pola	4	0	8	0	44
682	Eryk	Iwaszko	Kapitan	0	0	1	0	72
683	Bartek	Więcek	Zawodnik z pola	0	0	1	0	72
697	Kacper	Korbiel	Zawodnik z pola	1	0	1	0	72
618	Jan	Borkowski	Zawodnik z pola	4	0	1	0	43
646	Hubert	Januszek	Zawodnik z pola	1	1	7	8	67
585	Oskar	Żółciński	Zawodnik z pola	13	1	9	0	44
652	Wojciech	Tyberiusz	Zawodnik z pola	1	1	1	0	67
563	Filip	Janowski	Zawodnik z pola	10	8	8	0	63
589	Krzysztof	Baran	Kapitan	10	0	10	0	44
593	Igor	Jędrzejczyk	Zawodnik z pola	1	0	5	0	44
594	Jakub	Ptak	Zawodnik z pola	0	0	5	0	44
579	Damian	Horosin	kapitan	10	10	8	9	63
595	Jakub	Klupa	Zawodnik z pola	3	0	4	0	44
669	Szymon	Tylek	Zawodnik z pola	2	1	6	0	68
665	Piotr	Szymura	Zawodnik z pola	0	0	9	9	68
675	Michał	Radożycki	Zawodnik z pola	1	1	3	0	65
615	Szymon	Wołoszyn	Zawodnik z pola	0	0	1	8	43
659	Marcin	Barniak	Zawodnik z pola	2	0	9	0	68
661	Max	Koniorczyk	Zawodnik z pola	2	0	7	0	68
663	Nicholas	Rusinek	Zawodnik z pola	2	0	7	0	68
654	Jakub	Kasprzyk	Kapitan	3	1	11	0	68
668	Szymon	Seredyński	Zawodnik z pola	6	8	7	0	68
623	Bartek	Sosin	Zawodnik z pola	1	0	1	0	50
673	Sebastian	Tyka	Zawodnik z pola	0	13	4	35	65
586	Krystian	Nowak	Zawodnik z pola	7	1	9	0	44
678	Jakub	Duniec	Zawodnik z pola	4	3	4	0	65
532	Hubert	Salwach	Zawodnik z pola	2	0	6	0	57
672	Szymon	Nastały	Kapitan	27	6	11	0	65
662	Mikołaj	Bereza	Zawodnik z pola	0	0	1	0	68
674	Illia	Bubnov	Zawodnik z pola	9	4	7	0	65
677	Wiktor	Wrona	Zawodnik z pola	23	8	12	29	65
680	Mikołaj	Wójcik	Zawodnik z pola	1	0	3	6	65
681	Dawida	Gębuś	Zawodnik z pola	0	0	1	0	65
653	Wojciech	Wais	Zawodnik z pola	7	0	3	0	67
647	Karol	Kus	Zawodnik z pola	13	6	5	0	67
535	Szymon	Zimny	Zawodnik z pola	0	0	3	18	57
658	Karol	Kawalec	Zawodnik z pola	1	1	1	0	68
679	Kacper	Łudzik	Zawodnik z pola	6	0	9	0	65
1234	Szymon	Wysowski	Player	4	0	2	0	53
667	Szymon	Haligowski	Zawodnik z pola	0	0	4	0	68
583	Dymitr	Krawczuk	Zawodnik z pola	1	0	2	0	44
676	Szymon	Zieliński	Zawodnik z pola	5	0	4	0	65
626	Filip	Gil	Zawodnik z pola	2	3	1	0	50
640	Szymon	Zięcina	Zawodnik z pola	0	0	1	8	50
641	Łukasz	Kazała	Zawodnik z pola	3	0	1	0	50
587	Damian	Kudlek	Zawodnik z pola	2	0	10	52	44
1236	Damian	Horosin	Dwuzespolowiec	0	0	0	0	53
777	Jakub	Cichy	Zawodnik z pola	0	0	1	0	8
716	Karol	Henrych	Zawodnik z pola	0	0	0	0	62
717	Dominik	Gawlik	Zawodnik z pola	0	0	0	0	62
721	Antoni	Tyl	Zawodnik z pola	0	0	0	0	62
734	Adam	Jędrzejek	Zawodnik z pola	0	0	0	0	61
745	Robert	Gleń	Zawodnik z pola	0	0	0	0	70
748	Maciej	Musiał	Zawodnik z pola	0	0	0	0	70
750	Michael	Ksishgree	Zawodnik z pola	0	0	0	0	70
755	Mateusz	Płachta	Zawodnik z pola	0	0	0	0	70
756	Filip	Jeżak	Zawodnik z pola	0	0	0	0	70
757	Patryk	Chmolowski	Zawodnik z pola	0	0	0	0	70
771	Grzegorz	Gracz	Zawodnik z pola	0	0	0	0	8
774	Sebastian	Rozkrut	Zawodnik z pola	0	0	0	0	8
775	Sławomir	Rozkrut	Zawodnik z pola	0	0	0	0	8
776	Damian	Przygoński	Zawodnik z pola	0	0	0	0	8
729	Kacper	Małek	Zawodnik z pola	3	3	1	0	61
698	Jan	Kuc	Zawodnik z pola	0	0	2	15.5	72
692	Sebastian	Saładyga	Zawodnik z pola	1	0	1	0	72
730	Marcin	Sobczyk	Zawodnik z pola	1	1	5	32	61
740	Jakub	Grot	Zawodnik z pola	5	5	3	10	70
685	Maciej	Maź	Zawodnik z pola	4	0	2	0	72
707	Norbert	Wójcik	Zawodnik z pola	0	0	5	8	59
727	Konrad	Marzec	Zawodnik z pola	1	0	4	0	61
728	Michał	Gądek	Zawodnik z pola	6	0	4	0	61
732	Adrian	Kucab	Zawodnik z pola	2	0	4	0	61
736	Łukasz	Głowa	Zawodnik z pola	8	8	4	0	61
762	Krzysztof	Woźniak	Zawodnik z pola	0	0	7	0	8
643	Joachim	Bogacki	Zawodnik z pola	0	4	10	88	67
650	Tobiasz	Poltorak	Zawodnik z pola	18	9	6	0	67
670	Tomek	Fryczek	Zawodnik z pola	5	0	9	0	68
753	Kamil	Berniak	Zawodnik z pola	1	0	4	0	70
778	Norbert	Kawa	kapitan	0	13	9	83	8
699	Patryk	Pomykała	Kapitan	8	0	9	0	59
710	Zbigniew	Kieć	Zawodnik z pola	0	0	4	0	59
766	Filip	Żak	Zawodnik z pola	5	6	6	0	8
706	Kacper	Adamczyk	Zawodnik z pola	6	0	7	0	59
719	Kuba	Ochwat	Zawodnik z pola	4	0	3	0	62
700	Bartłomiej	Gruca	Zawodnik z pola	10	9	9	57	59
761	Mateusz	Nowak	Zawodnik z pola	20	1	11	0	8
772	Tomasz	Mączyński	Zawodnik z pola	0	1	5	0	8
744	Grzegorz	Krasicki	Zawodnik z pola	7	1	8	0	70
648	Kuba	Chwedyk	Zawodnik z pola	1	0	4	0	67
733	Krzysztof	Miodoński	Zawodnik z pola	0	0	1	0	61
737	Kamil	Lichwała	Zawodnik z pola	0	0	1	0	61
656	Dominik	Bant	Zawodnik z pola	2	0	7	0	68
655	Adam	Kuśmider	Zawodnik z pola	5	7	12	106	68
746	Wojtek	Woźny	Zawodnik z pola	0	0	2	0	70
765	Filip	Tekiela	Zawodnik z pola	2	0	4	0	8
644	Bartłomiej	Wierzba	Zawodnik z pola	1	0	4	0	67
768	Karol	Walkowiak	Zawodnik z pola	2	9	6	29	8
666	Szymon	Synowiec	Zawodnik z pola	2	0	4	0	68
741	Michał	Wyżga	Zawodnik z pola	1	0	5	10	70
723	Dawid	Sawa	Zawodnik z pola	0	0	3	16	62
767	Karol	Kuraś	Zawodnik z pola	29	5	11	0	8
760	Michał	Szarlej	Zawodnik z pola	8	1	10	0	8
773	Dawid	Źródlewski	Zawodnik z pola	2	1	3	0	8
649	Stefek	Barylski	Zawodnik z pola	18	13	11	0	67
764	Oliwier	Świątek	Zawodnik z pola	11	1	7	0	8
725	Jakub	Miechowicz	Zawodnik z pola	1	0	1	8	62
1235	Kuba	Legut	Player	14	2	5	0	53
731	Michał	Tomsiński	Zawodnik z pola	2	0	1	0	61
705	Kacper	Jednaki	Zawodnik z pola	0	0	4	0	59
742	Patryk	Hajduk	Zawodnik z pola	43	2	9	0	70
738	Jakub	Bednar	Zawodnik z pola	0	7	8	75	70
743	Rafał	Krasicki	Zawodnik z pola	6	0	4	0	70
735	Konrad	Laskowski	Zawodnik z pola	0	0	1	0	61
718	Emil	Szałankiewicz	Zawodnik z pola	5	0	3	0	62
642	Wojtek	Drwota	Kapitan	12	5	5	0	67
671	Wiktor	Partyka	Zawodnik z pola	37	13	11	0	68
22	Aleksander	Gregoraszczuk	Zawodnik z pola	0	0	3	0	17
704	Bartłomiej	Wilusz	Zawodnik z pola	5	3	5	0	59
726	Mikołaj	Batko	Kapitan	10	4	6	0	61
763	Bartosz	Soja	Zawodnik z pola	2	0	6	0	8
720	Alek	Szafraniec	Zawodnik z pola	0	0	3	24	62
758	Michał	Chmiel	Zawodnik z pola	1	0	2	0	62
759	Piotr	Piszczek	Zawodnik z pola	1	3	2	0	62
724	Dominik	Gawlik	Zawodnik z pola	1	0	2	0	62
782	Paweł	Węgrzyn	Zawodnik z pola	0	0	0	0	32
786	Maciek	Ulh	Zawodnik z pola	0	0	0	0	32
790	Paweł	Kmieć	Zawodnik z pola	0	0	0	0	32
794	Maciej	Gazeł	Zawodnik z pola	0	0	0	0	70
795	Nikodem	Surmacz	Zawodnik z pola	0	0	0	0	70
796	Michał	Balak	Zawodnik z pola	0	0	0	0	70
797	Maciek	Korban	Zawodnik z pola	0	0	0	0	70
805	Paweł	Paszcza	Zawodnik z pola	0	0	0	0	22
810	Karol	Chmura	Zawodnik z pola	0	0	0	0	22
814	Mateusz	Wojkowski	Zawodnik z pola	0	0	0	0	56
780	Filip	Więckowski	Kapitan	6	3	5	8	32
829	Aleksander	Kabalak	Zawodnik z pola	0	0	0	0	58
835	Illia	Kabanov	Zawodnik z pola	0	0	0	0	58
839	Marek	Solarz	Zawodnik z pola	0	0	0	0	58
824	Benek	Kalisz	Zawodnik z pola	3	3	3	0	58
830	Antoni	Garbacz	Zawodnik z pola	0	0	1	0	58
832	Filip	Kałuża	Zawodnik z pola	2	0	10	54	58
808	Dawid	Giza	Zawodnik z pola	0	0	1	0	22
825	Filip	Szymus	Zawodnik z pola	5	0	5	0	58
811	Michał	Skwara	Kapitan	0	0	3	15	56
789	Szymon	Wirtel	Zawodnik z pola	9	3	3	0	32
833	Franek	Czeczot	Kapitan	3	1	7	17	58
826	Szymon	Hulanicki	Zawodnik z pola	6	0	4	0	58
784	Janusz	Janik	Zawodnik z pola	18	2	6	0	32
708	Wojtek	Wielgus	Zawodnik z pola	2	0	6	0	59
703	Jerzy	Skwarło	Zawodnik z pola	6	1	9	5	59
711	Arkadiusz	Biegan	Zawodnik z pola	4	0	7	0	59
818	Kazik	Rymut	Zawodnik z pola	0	0	2	0	56
701	Jakub	Musiał	Zawodnik z pola	72	28	12	0	59
840	Mateusz	Dańko	Zawodnik z pola	16	5	7	0	58
793	Michał	Bryg	Zawodnik z pola	4	5	4	0	70
751	Mateusz	Sumera	Zawodnik z pola	6	5	4	0	70
804	Mikołaj	Borczuch	Zawodnik z pola	2	0	11	84	22
838	Marcel	Zając	Zawodnik z pola	12	9	4	0	58
841	Mateusz	Nalepka	Zawodnik z pola	6	5	6	0	58
816	Filip	Cieślik	Zawodnik z pola	3	0	2	0	56
815	Jakub	Młynarczyk	Zawodnik z pola	0	0	1	0	56
819	Kamil	Janowski	Zawodnik z pola	2	0	2	0	56
802	Kuba	Oś	Zawodnik z pola	9	2	8	0	22
651	Tymek	Piotrowicz	Zawodnik z pola	17	5	8	0	67
800	Łukasz	Arłamowski	Zawodnik z pola	18	6	11	0	22
803	Maciek	Sluja	Zawodnik z pola	0	0	2	0	22
837	Kajetan	Kułakowski	Zawodnik z pola	17	6	9	0	58
787	Jakub	Sederowski	Zawodnik z pola	0	0	2	4	32
788	Artur	Ślusarczyk	Zawodnik z pola	4	5	2	0	32
781	Tomasz	Więckowski	Zawodnik z pola	1	0	4	27	32
792	Batsuren	Batsuren	Zawodnik z pola	0	1	3	0	70
822	Mikołaj	Mrówka	Zawodnik z pola	0	0	2	0	58
752	Arkadiusz	Majoch	Zawodnik z pola	3	0	2	0	70
783	Tomasz	Janik	Zawodnik z pola	7	0	5	0	32
807	Dominik	Moryc	Zawodnik z pola	0	0	2	0	22
799	Kamil	Solecki	Zawodnik z pola	30	29	10	0	22
798	Jakub	Kowal	Kapitan	1	0	8	0	22
709	Patryk	Aksamit	Zawodnik z pola	11	9	11	16	59
806	Szymon	Celejewski	Zawodnik z pola	0	5	3	27	22
102	Maciek	Pohl	Zawodnik z pola	0	3	7	63	26
836	Joachim	Matuszczak	Zawodnik z pola	1	6	5	0	58
521	Józef	Adamczyk	Zawodnik z pola	2	0	3	0	57
791	Grzegorz	Kowalczyk	Zawodnik z pola	3	0	2	0	32
712	Maciej	Wójcik	Kapitan	6	0	6	0	62
558	Mateusz	Studziżba	Zawodnik z pola	8	3	5	0	63
739	Paweł	Karpiński	Zawodnik z pola	20	27	10	0	70
813	Michał	Szefer	Zawodnik z pola	3	0	1	0	56
817	Kamil	Hamowski	Zawodnik z pola	1	0	1	0	56
820	Dawid	Laskowski	Zawodnik z pola	0	0	1	0	56
812	Kacper	Jaworski	Zawodnik z pola	6	9	3	0	56
530	Adam	Odrzywołek	Zawodnik z pola	1	0	15	0	57
801	Filip	Gurdek	Zawodnik z pola	24	11	12	0	22
823	Gustaw	Bąbel	Zawodnik z pola	0	0	1	0	58
834	Igor	Tetłak	Zawodnik z pola	0	0	1	0	58
827	Jan	Szkaradek	Zawodnik z pola	0	0	1	0	58
747	Kacper	Kmera	Zawodnik z pola	1	0	2	0	70
785	Jakub	Janik	Zawodnik z pola	8	5	3	0	32
831	Filip	Goczał	Zawodnik z pola	4	0	2	0	58
809	Aleks	Czulak	Zawodnik z pola	0	0	1	0	22
702	Mateusz	Domagała	Zawodnik z pola	4	0	6	0	59
821	Jan	Piekar	Zawodnik z pola	0	0	4	0	58
713	Igor	Szpyt	Zawodnik z pola	9	4	4	0	62
749	Michał	Luzar	Zawodnik z pola	10	7	6	0	70
843	Miłosz	Kłonica	Zawodnik z pola	0	0	0	0	58
848	Szymon	Forystek	Zawodnik z pola	0	0	0	0	58
849	Tadeusz	Kobylański	Zawodnik z pola	0	0	0	0	58
851	Tytus	Kijowski	Zawodnik z pola	0	0	0	0	58
853	Wojciech	Wiącek	Zawodnik z pola	0	0	0	0	58
864	Andrzej	Kończyk	zawodnik	0	0	0	0	37
866	Kamil	Sosenko	zawodnik	0	0	0	0	37
867	Ivan	Milenin	zawodnik	0	0	0	0	37
688	Kamil	Cygan	Zawodnik z pola	2	0	1	0	72
860	Kamil	Mitka	zawodnik	2	1	3	0	69
854	Tomasz	Woźnica	Zawodnik z pola	1	3	4	0	68
897	Nikodem	Capek	zawodnik	0	0	1	0	16
194	Dominik	Baran	Kapitan	0	0	3	0	48
695	Oliwier	Jarosz	Zawodnik z pola	4	3	2	0	72
875	Galacticos Kraków 2023	Bartosz	Nastały	0	0	0	0	65
292	Tomasz	Gola	Zawodnik z pola	4	0	6	0	45
908	Adam	Pieniądz	zawodnik	0	0	0	0	11
913	Filip	Gwiźdż	zawodnik	0	0	0	0	11
915	Jakub	Piekarski	zawodnik	0	0	0	0	11
895	Mariusz	Mosur	zawodnik	3	0	4	0	16
842	Mattia	Marzocchi	Zawodnik z pola	0	0	1	0	58
905	Mateusz	Waremczuk	zawodnik	5	1	6	0	11
893	Kuba	Pietrawas	zawodnik	6	5	4	0	16
847	Sebastian	Lipiarz	Zawodnik z pola	0	0	1	0	58
852	Wiktor	Wiśniewski	Zawodnik z pola	0	0	1	0	58
907	Dominik	Iniarski	zawodnik	6	0	5	0	11
874	Igor	Jasiówka	zawodnik	1	0	2	0	65
899	Eryk	Jurek	zawodnik	1	0	7	57	16
890	Kuba	Jasiński	zawodnik	0	0	2	0	16
1238	Oliwier	Soboń	Player	2	0	2	0	53
894	Mateusz	Pabian	zawodnik	4	4	2	0	16
871	Oskar	Słaby	zawodnik	0	0	2	0	39
896	Dominika	Mosur	zawodnik	0	0	1	0	16
898	Radek	Piotrowski	zawodnik	1	0	1	0	16
903	Olaf	Pomykalski	Bramkarz	7	19	6	53	11
900	Mariusz	Orczewski	zawodnik	0	0	1	0	16
906	Jakub	Bartuś	zawodnik	5	0	4	0	11
845	Radek	Malicki	Zawodnik z pola	0	0	1	0	58
855	Jakub	Gałuszka	Zawodnik z pola	4	8	3	5	68
846	Roman	Kolompar	Zawodnik z pola	4	3	4	0	58
861	Kuba	Burakowski	zawodnik	0	0	1	0	60
844	Piotr	Wojciechowski	Zawodnik z pola	0	0	3	0	58
869	Łukasz	Bardaliński	zawodnik	0	1	1	0	37
877	Marcin	Jania	zawodnik	1	0	2	0	52
910	Patryk	Hajduk	zawodnik	1	0	1	0	11
862	Piotr	Kazimierczak	zawodnik	12	1	10	0	37
511	Łukasz	Zwoliński	Zawodnik z pola	7	0	13	0	69
873	Micha	Olech	zawodnik	0	0	1	0	65
892	Marcin	Pabian	zawodnik	3	3	2	0	16
911	Kacper	Szostak	zawodnik	5	4	3	0	11
901	Sebastian	Piskorz	zawodnik	1	0	6	0	11
912	Daniel	Chyc	zawodnik	12	1	8	0	11
909	Jakub	Puto	zawodnik	11	8	7	0	11
914	Wiktor	Rosiński	zawodnik	2	0	2	0	11
880	Szymon	Jastrzębski	zawodnik	2	0	3	7	52
904	Szymon	Szostak	zawodnik	9	0	8	0	11
878	Ignacy	Gawron	zawodnik	1	0	2	0	52
879	Jan	Mróz	Zawodnik	0	0	2	0	52
883	Michał	Mróz	zawodnik	2	0	3	0	52
881	Jakub	Bębenek	zawodnik	0	0	2	0	52
882	Kacper	Wygaś	zawodnik	0	0	2	0	52
884	Kamil	Kulma	zawodnik	1	3	3	0	52
885	Bartosz	Soja	Zawodnik	1	3	3	0	52
886	Aleksander	Janik	Bramkarz	0	0	3	14	52
887	Krzysztof	Pulak	zawodnik	0	0	2	0	52
269	Maciek	Musiał	Zawodnik z pola	0	0	2	0	39
859	Tomasz	Mucha	zawodnik	1	0	1	0	69
868	Micha	Kazimierczak	zawodnik	0	0	1	0	37
863	Konrad	Koptyś	zawodnik	0	0	2	0	37
714	Przemysław	Sikora	Zawodnik z pola	14	0	7	0	62
865	Michał	Wiącek	zawodnik	1	0	3	0	37
870	Karol	Wszoła	zawodnik	3	8	3	0	39
858	Bartek	Wideł	zawodnik	1	0	3	0	69
889	Daniel	Wiącek	zawodnik	3	3	5	0	16
857	Patryk	Daniec	Zawodnik z pola	0	0	1	0	62
902	Ivan	Gnatyszen	Bramkarz	5	0	6	50	11
184	Yaroslav	Myroniuk	Zawodnik z pola	1	0	4	0	38
850	Tomasz	Cieślak	Zawodnik z pola	0	0	1	0	58
888	Arkadiusz	Kudzia	zawodnik	10	5	6	0	16
876	Korneliusz	Bem	zawodnik	11	0	6	0	60
856	Bartosz	Noga	Zawodnik z pola	1	0	2	0	62
722	Borys	Soliński	Zawodnik z pola	1	1	6	26.5	62
916	Michał	Proć	zawodnik	0	0	0	0	11
917	Patryk	Toczek	zawodnik	0	0	0	0	11
918	Maciek	Makulski	zawodnik	0	0	0	0	11
922	Mateusz	Wrona	zawodnik	0	0	0	0	6
927	Maks	Sosin	zawodnik	0	0	0	0	6
932	Filip	Hołuj	zawodnik	0	0	0	0	6
933	Adrian	Grabowski	zawodnik	0	0	0	0	13
934	Antek	Pisarczyk	zawodnik	0	0	0	0	13
935	Bartek	Bogusz	zawodnik	0	0	0	0	13
936	Bartek	Żakieta	zawodnik	0	0	0	0	13
937	Bartłomiej	Broś	zawodnik	0	0	0	0	13
938	Daniel	Pituch	zawodnik	0	0	0	0	13
939	Igor	Chlebowski	zawodnik	0	0	0	0	13
940	Jacek	Waligóra	zawodnik	0	0	0	0	13
941	Kacper	Mochal	zawodnik	0	0	0	0	13
942	Kacper	Pituch	zawodnik	0	0	0	0	13
943	Kamil	Kozak	zawodnik	0	0	0	0	13
944	Krzysiek	Wieciołkowski	zawodnik	0	0	0	0	13
945	Maciej	Salasa	zawodnik	0	0	0	0	13
946	Mateusz	Kawa	zawodnik	0	0	0	0	13
947	Oskar	Bulczyński	zawodnik	0	0	0	0	13
948	Patryk	Gajda	zawodnik	0	0	0	0	13
949	Patryk	Kawa	zawodnik	0	0	0	0	13
950	Szymon	Chowaniec	zawodnik	0	0	0	0	13
951	Szymon	Pelson	zawodnik	0	0	0	0	13
952	Tomek	Stala	kapitan	0	0	0	0	13
953	Vova	Suchowski	zawodnik	0	0	0	0	13
954	Mateusz	Pulnik	zawodnik	0	0	0	0	5
957	Michał	Głowacki	zawodnik	0	0	0	0	5
962	Filip	Czekaj	zawodnik	0	0	0	0	5
964	Daniel	Kowalski	Zawodnik z pola	0	0	0	0	5
965	Wojtek	Dudzińśki	zawodnik	0	0	0	0	5
967	Szymon	Hajduk	zawodnik	0	0	0	0	5
968	Bartłomiej	Niedzielski	zawodnik	0	0	0	0	5
969	Artur	Pępkowski	zawodnik	0	0	0	0	5
970	Kuba	Skoczek	zawodnik	0	0	0	0	5
971	Arkadiusz	Pępkowski	zawodnik	0	0	0	0	5
974	Kacper	Gajda	zawodnik	0	0	0	0	5
975	Mark	Shevchyshyn	zawodnik	0	0	0	0	5
982	Jakub	Krzywiński	zawodnik	0	0	0	0	14
985	Olaf	Tyrkalski	zawodnik	0	0	0	0	14
986	Olek	Janik	zawodnik	0	0	0	0	14
994	Adrian	Mach	zawodnik	0	0	0	0	14
995	Dawid	Ogarek	zawodnik	0	0	0	0	14
997	Kuba	Tarach	zawodnik	0	0	0	0	14
1000	Maciek	Townsend	zawodnik	0	0	0	0	14
517	Krzysiek	Giba	Zawodnik z pola	1	0	1	0	69
923	Szymon	Bończyk	zawodnik	0	1	4	34.5	6
983	Wiktor	Chudy	kapitan	2	0	2	0	14
926	Piotr	Powałka	zawodnik	2	0	3	0	6
929	Jakub	Dyl	zawodnik	1	0	3	0	6
931	Mateusz	Łabuś	zawodnik	10	10	3	0	6
920	Patryk	Bąk	zawodnik	10	7	5	0	6
959	Piotrek	Rajnert	zawodnik	2	0	2	0	5
930	Paweł	Dużyk	zawodnik	4	0	4	0	6
963	Mateusz	Frenc	zawodnik	3	3	1	0	5
928	Bartek	Siembak	zawodnik	2	0	1	0	6
921	Dominik	Tomaszewski	zawodnik	0	0	1	0	6
955	Sebastian	Twardy	zawodnik	5	0	2	0	5
991	Krzysiek	Macek	zawodnik	2	1	5	18	14
993	Roman	Biloval	zawodnik	2	0	3	0	14
989	Jakub	Najda	zawodnik	2	0	2	9	14
992	Piotr	Sobieski	zawodnik	0	0	2	0	14
987	Jan	Dzierwa	zawodnik	3	2	2	0	14
999	Dawid	Gruszkowski	zawodnik	1	0	1	0	14
990	Dawid	Kokośiński	zawodnik	3	0	3	0	14
973	Rafał	Dobosz	zawodnik	2	0	1	0	5
976	Lahoucine	Benhera	zawodnik	0	0	1	0	5
984	Michał	Mróz	zawodnik	17	4	7	0	14
978	Kiryl	Shashura	zawodnik	0	0	1	0	5
512	Kamil	Calik	Zawodnik z pola	5	0	9	0	69
958	Bartek	Janicki	zawodnik	0	0	2	0	5
514	Krystian	Grabowski	Zawodnik z pola	6	3	6	0	69
960	Mateusz	Klimek	zawodnik	2	0	1	0	5
981	Piotr	Ptak	zawodnik	12	5	7	0	8
998	Maciej	Stolarski	zawodnik	1	6	5	44	14
956	Krzysztof	Tondera	zawodnik	0	0	1	0	5
925	Szymon	Powałka	zawodnik	5	0	3	0	6
924	Konrad	Strzałka	zawodnik	3	0	3	0	6
972	Grzegorz	Olesiejuk	zawodnik	1	0	1	0	5
979	Jan	Bielecki	zawodnik	19	9	5	0	5
996	Jan	Mróz	zawodnik	2	0	1	0	14
980	Sebastian	Wójcik	zawodnik	0	3	5	43	5
961	Jan	Pieczarkowski	zawodnik	0	0	1	0	5
977	Wiesław	Kulpa	kapitan	0	0	3	9	5
1006	Filip	Janik	zawodnik	0	0	0	0	40
1011	Antoni	Grzyb	zawodnik	0	0	0	0	40
1012	Kuba	Konopka	zawodnik	0	0	0	0	40
1014	Wojtek	Flis	zawodnik	0	0	0	0	40
1015	Łukasz	Ślisz	zawodnik	0	0	0	0	40
1016	Jan	Ślisz	zawodnik	0	0	0	0	40
1019	Kamil	Dojko	zawodnik	0	0	0	0	40
1020	Kacper	Kitliński	zawodnik	0	0	0	0	40
1022	Roma	Roma	zawodnik	0	0	0	0	40
1023	Radek	Woźniak	zawodnik	0	0	0	0	40
1024	Piotek	Pabian	zawodnik	0	0	0	0	40
1027	Oskar	Adamczyk	zawodnik	0	0	0	0	40
1028	Karol	Włodarski	zawodnik	0	0	0	0	40
1030	Konrad	Warzecha	zawodnik	0	0	0	0	40
645	Dominik	Bąbol	Zawodnik z pola	8	0	2	0	67
1040	Kacper	Kalinowski	zawodnik	0	0	0	0	66
1240	Wojciech	Baranek	Player	3	0	1	0	53
1046	Grzegorz	Rybicki	Zawodnik	0	0	0	0	34
1047	Konrad	Śmietan	zawodnik	0	0	0	0	34
1051	Radosław	Jarosz	zawodnik	0	0	0	0	8
1059	Radek	Michalczyk	zawodnik	8	14	8	0	47
919	Grzegorz	Szafraniec	zawodnik	9	8	5	0	6
1034	Maciek	Bryg	zawodnik	3	0	1	0	70
1045	Jakub	Maj	zawodnik	0	0	3	0	34
1057	Dawid	Gdula	zawodnik	9	0	8	0	47
1074	Michał	Florkiewicz	zawodnik	0	5	3	26	46
1078	Wiktor	Grabiec	zawodnik	2	0	3	0	46
1081	Henryk	Kochan	zawodnik	0	0	3	0	46
1068	Antek	Jedynak	zawodnik	0	0	2	0	46
1056	Dawid	Kucia	zawodnik	2	0	6	0	47
1042	Jakub	Jagielski	zawodnik	0	3	3	22	63
1053	Konrad	Klita	zawodnik	3	0	6	7	47
1066	Jakub	Stachowski	zawodnik	8	5	6	0	47
1038	Tomasz	Degórski	zawodnik	0	0	0	0	20
1021	Mikołaj	Purol	zawodnik	13	11	3	0	40
1001	Mateusz	Mroczka	zawodnik	7	3	6	16	40
1026	Igor	Sobolewski	zawodnik	1	0	5	0	40
1029	Konrad	Zawadzki	zawodnik	2	0	2	0	40
1002	Tomasz	Kłak	zawodnik	14	10	7	42	40
1065	Wojtek	Czyrnek	zawodnik	1	8	6	46	47
350	Igor	Gajda	Zawodnik z pola	0	7	12	107.5	37
1048	Kamil	Kus	zawodnik	4	0	1	0	67
1005	Jan	Janik	zawodnik	3	0	2	0	40
1044	Denis	Denis	zawodnik	3	0	5	0	70
1049	Maciej	Węgrzyn	zawodnik	0	0	1	0	30
1050	Hubert	Szczepanik	zawodnik	1	0	2	0	30
1003	Eryk	Radwan	zawodnik	9	4	6	0	40
1063	Szymon	Kuc	zawodnik	5	1	6	0	47
1007	Filip	Skowron	zawodnik	0	0	3	0	40
1054	Sebastian	Soból	zawodnik	26	21	7	0	47
1037	Adrian	Kaleta	zawodnik	0	0	4	13	65
1055	Dawid	Soból	zawodnik	12	0	6	0	47
186	Adam	Doniec	Zawodnik z pola	0	0	2	0	48
1062	Szymon	Kowalik	zawodnik	1	0	3	0	47
891	Łukasz	Paciorek	zawodnik	10	4	6	0	16
1058	Łukasz	Gdula	zawodnik	21	12	9	0	47
1025	Kuba	Krzak	zawodnik	0	0	1	0	40
1035	Robert	Zubek	zawodnik	2	0	4	0	30
1069	Bartosz	Wiśniowski	zawodnik	2	0	3	0	46
1064	Sebastian	Kowalik	zawodnik	2	0	2	0	47
1070	Darwin	Darwin	zawodnik	5	3	2	0	46
1073	Max	Holovko	zawodnik	0	0	2	0	46
1075	Patryk	Kostaś	zawodnik	1	0	2	0	46
1043	Serhi	Pylypchuka	zawodnik	1	0	4	0	70
1076	Piotr	Wysocki	zawodnik	0	0	1	0	46
1077	Stachu	Kiepura	zawodnik	0	0	1	0	46
1079	Adam	Konieczny	zawodnik	0	0	1	0	46
1080	Maciej	Adamczyk	zawodnik	0	0	1	0	46
1072	Maks	Satora	zawodnik	0	0	2	0	46
1060	Michał	Kromka	zawodnik	4	0	10	0	47
1009	Maciej	Ryskala	zawodnik	2	0	3	0	40
1067	Michał	Pustelnik	zawodnik	0	0	2	0	47
1031	Szymon	Sitarz	zawodnik	0	0	1	0	40
1061	Mateusz	Kowalik	zawodnik	0	0	2	0	47
1039	Maciej	Federowicz	zawodnik	10	0	4	0	66
1032	Łukasz	Klocek	zawodnik	0	0	2	0	40
1231	Łukasz	Błażowski	Player	5	0	3	0	53
1004	Eliasz	Mirosław	zawodnik	7	4	4	0	40
1033	Michał	Krenich	zawodnik	2	0	1	0	40
1010	Kuba	Król	zawodnik	0	0	1	9	40
1008	Alek	Rębacz	zawodnik	4	0	6	0	40
1013	Wojtek	Ślisz	zawodnik	0	0	1	0	40
1018	Bartek	Cebula	zawodnik	0	0	1	0	40
1017	Bartek	Ptak	zawodnik	2	2	5	0	40
1041	Matuesz	Kądzielewa	zawodnik	0	3	1	0	63
1161	Kacper	Kil	zawodnik	18	13	7	9	45
828	Kuba	Berkowicz	Zawodnik z pola	0	0	1	0	58
1090	Daniel	Glabian	Player	0	0	1	0	21
1099	Jakub	Tatara	zawodnik	0	0	0	0	54
1100	Mateusz	Guzowski	zawodnik	0	0	0	0	54
1103	Karol	Wilk	zawodnik	0	0	0	0	54
1110	Paweł	Jezioro	zawodnik	0	0	0	0	54
1232	Ignacy	Popławski	Player	3	0	1	0	53
1118	Tomek	Bigosiński	zawodnik	0	0	0	0	9
1123	Maksymialian	Mroczka	zawodnik	0	0	0	0	9
1142	Paweł	Bojar	zawodnik	0	0	1	0	30
1128	Marek	Pawlus	zawodnik	0	0	0	0	9
1132	Damonik	Marzec	zawodnik	0	0	0	0	9
1133	Paweł	Domszy	zawodnik	0	0	0	0	9
1136	Kuba	Bigosiński	zawodnik	0	0	0	0	9
1137	Kamil	Grabek	zawodnik	0	0	0	0	9
1139	Kamil	Sobecki	zawodnik	0	0	0	0	9
1101	Jerzy	Smalewski	zawodnik	4	1	7	0	54
1098	Michał	Tatara	zawodnik	1	0	2	0	54
1159	Aliaksei	Vishavaty	zawodnik	0	0	2	0	38
1097	Patryk	Kuc	zawodnik	34	24	8	0	54
1096	Daniel	Poprawa	zawodnik	2	0	6	0	54
1113	Mariusz	Skrzyszowski	zawodnik	0	0	2	9	54
1105	Kacper	Kawula	zawodnik	0	0	1	0	54
1109	Miłosz	Ziębacz	zawodnik	0	0	2	0	54
1114	Krzysztof	Olszewski	zawodnik	0	7	8	77	54
1095	Jan	Suberlak	zawodnik	11	6	8	0	54
1150	Krzysztof	Jasiński	zawodnik	0	0	0	0	16
1151	Damian	Michalec	zawodnik	0	0	0	0	32
1154	Mark	Planells	zawodnik	0	0	0	0	32
1157	Kuba	Wyporek	zawodnik	0	0	0	0	19
1106	Krzysztof	Baran	zawodnik	6	0	6	0	54
1147	Dominik	Kukieła	zawodnik	0	0	2	9	30
1138	Jan	Hołowacz	zawodnik	4	1	4	0	9
1126	Kacper	Ziółkowski	zawodnik	0	0	5	48	9
1125	Przemek	Kogut	zawodnik	1	0	2	0	9
1117	Grzegorz	Wojnarowski	zawodnik	19	1	9	0	9
1131	Andrii	Stroivans	zawodnik	20	11	8	0	9
1121	Paweł	Piwowarczyk	zawodnik	1	0	3	0	9
1127	Jakub	Nowak	zawodnik	1	0	4	0	9
1119	Marcin	Tomaszewski	zawodnik	0	5	6	53	9
1134	Carlos	Hernandez Frias	zawodnik	5	0	4	0	9
1092	Wojciech	Flis	Player	1	0	2	0	21
1094	Bartłomiej	Adamski	Player	7	6	2	0	21
1120	Przemek	Czubaj	zawodnik	40	11	9	0	9
27	Konrad	Kukułka	Zawodnik z pola	4	3	5	0	17
1143	Filip	Kusia	zawodnik	0	0	1	0	30
1160	Wiktor	Gaczoł	zawodnik	9	4	7	0	42
1145	Michał	Przęczek	zawodnik	0	0	1	0	30
1144	Kamil	Skałban	zawodnik	5	0	2	0	30
1082	Tomek	Korzkiewicz	zawodnik	0	0	1	0	46
1153	Kacper	Nagórzański	zawodnik	3	1	1	0	32
1149	Kamil	Grochal	zawodnik	4	0	2	0	16
1115	Paweł	Węgrzyn	kapitan	20	4	11	0	9
1116	Rafał	Cepik	zawodnik	5	0	6	0	9
1146	Jan	Kołodziejski	zawodnik	21	9	6	0	30
1140	Kamil	Baka	zawodnik	0	0	1	10	6
1158	Jędrek	Kotarba	zawodnik	0	0	0	0	19
1093	Jakub	Latała	Player	2	0	4	0	21
1122	Dawid	Lis	zawodnik	2	0	1	0	9
1130	Mateusz	Ziółko	zawodnik	2	0	1	0	9
1102	Mateusz	Klimek	zawodnik	7	0	7	0	54
1107	Mikołaj	Dyga	zawodnik	17	1	7	0	54
1112	Sebastian	Saładyga	zawodnik	3	0	2	0	54
1089	Krzysztof	Jaworski	Player	0	1	4	35	21
1152	Mateusz	Sajdak	zawodnik	2	0	1	0	32
1162	Mateusz	Więcław	zawodnik	22	10	7	0	45
1104	Michał	Kordylewski	zawodnik	1	7	6	0	54
1156	Maks	Żyłko	zawodnik	0	0	3	8	26
1135	Łukasz	Sternal	zawodnik	6	0	7	0	9
1148	Jakub	Żmuda	zawodnik	6	3	6	0	41
1083	Marcel	Odroń	zawodnik	0	0	1	0	46
1084	Kuba	Stopa	zawodnik	0	0	1	0	46
1085	Franciszek	Maniak	zawodnik	3	1	1	0	46
1086	Maciej	Nastałek	zawodnik	0	0	1	0	46
1087	Maciek	Kosydar	zawodnik	14	8	2	0	46
1091	Krzysztof	Szczurek	Player	0	0	1	0	21
597	Wojciech	Foks	Zawodnik z pola	5	6	8	0	44
1129	Dominik	Brózda	zawodnik	1	0	1	0	9
660	Marcin	Kłęczek	Zawodnik z pola	10	2	11	0	68
1163	Tomasz	Boroń	zawodnik	2	0	3	0	45
1155	Jakub	Olma	zawodnik	1	0	4	0	24
1088	Grzegorz	Latała	Captain	5	0	3	0	21
446	Daniel	Morozewicz	Zawodnik z pola	13	10	5	0	28
1173	Dawid	Biernat	Player	0	0	0	0	21
1174	Dominik	Kaczmarski	Player	0	0	0	0	21
1177	Kacper	Skruch	Player	0	0	0	0	21
1179	Szymon	Helicki	Player	0	0	0	0	21
1180	Dominik	Kasprzak	Player	0	0	0	0	21
1181	Adam	Kamyk	Player	0	0	0	0	21
1182	Robert	Poznański	Player	0	0	0	0	21
1184	Krystian	Król	Player	0	0	0	0	21
1188	Wojciech	Pozzi	Player	0	0	0	0	31
1189	Michał	Hyla	Player	0	0	0	0	31
1190	Adrian	Goliński	Player	0	0	0	0	31
1191	Filip	Węgiel	Player	0	0	0	0	31
1193	Kuba	Kukułka	Player	0	0	0	0	31
1194	Jan	Czerlunczakiewicz	Player	0	0	0	0	31
1195	Daniel	Wiśniewski	Player	0	0	0	0	31
1199	Konrad	Gaborek	Player	0	0	0	0	31
1201	Klaudiusz	Kowalczyk	Player	0	0	0	0	31
1204	Mateusz	Krztoń	Player	0	0	0	0	31
1205	Illya	Basiuk	Player	0	0	0	0	31
1207	Norbert	Rzeźnik	Player	0	0	0	0	31
1208	Przemek	Pawlik	Player	0	0	0	0	53
1209	Daniel	Derdaś	Player	0	0	0	0	53
1213	Kuba	Skórzak	Player	0	0	0	0	53
1214	Michał	Studziżba	Captain	0	0	0	0	53
1216	Piotr	Sucharski	Dwuzespolowiec	0	0	0	0	53
1218	Oskar	Worgacz	Player	0	0	0	0	53
1221	Stanisław	Magiera	Player	0	0	0	0	53
1224	Antoni	Karp	Player	0	0	0	0	53
1225	Szymon	Gaweł	Player	0	0	0	0	53
1227	Jakub	Bujas	Player	0	0	0	0	53
1171	Piotr	Turbasa	Player	2	0	4	0	21
1226	Michał	Nalepa	Player	9	5	5	10	53
1237	Tomek	Kowalik	Player	2	0	2	0	53
1172	Jakub	Pirowski	Player	0	3	1	0	21
1215	Mateusz	Studziżba	Dwuzespolowiec	17	26	8	0	53
1230	Filip	Heród	Player	6	1	4	0	53
1249	Antoni	Rams	Player	0	0	0	0	73
1250	Szymon	Bodek	Player	0	0	0	0	73
1251	Maks	Misiewicz	Player	0	0	0	0	73
1252	Igor	Kaźnica	Player	0	0	0	0	73
1241	Wiktor	Izotov	Player	4	3	4	0	38
1166	Adam	Arłamowski	Player	7	11	5	0	21
1183	Jan	Krajewski	Player	0	3	2	0	21
1178	Piotr	Bocwiński	Player	2	0	3	0	21
1169	Sebastian	Pawlikowski	Player	0	0	1	0	21
1176	Łukasz	Nawara	Player	1	0	2	0	21
1165	Andrzej	Szaroń	Zawodnik	5	0	2	0	66
1210	Sławek	Bożek	Player	1	0	1	0	53
1167	Mateusz	Nowak	Player	6	0	5	0	21
1185	Szymon	Szymczyk	Player	0	0	1	0	21
1203	Dariusz	Tarnopolski	Player	3	0	2	0	31
1206	Maksim	Fedarovich	Player	3	0	2	0	31
1200	Michał	Marszałek	Player	1	0	1	0	31
1202	Grzegorz	Góra	Player	0	0	1	9	31
1198	Konrad	Ciechanowicz	Player	0	5	1	8.5	31
1219	Kuba	Gorczyca	Player	3	0	1	0	53
10	Krystian	Percik	Br	0	12	6	59	15
1186	Jakub	Prostak	Player	14	2	6	0	15
1187	Andrei	Sianiuta	Player	0	0	1	0	31
1196	Mikołaj	Woda	Player	2	0	1	0	31
1223	Mateusz	Szopa	Player	7	0	2	0	53
1192	Filip	Despet	Captain	3	3	2	0	31
1244	Stanisław	Sierant	Player	0	0	1	0	73
1245	Victor	Sulik	Player	0	0	1	0	73
1246	Kuba	Suliński	Captain	1	0	1	0	73
1242	Mateusz	Niżnik	Player	0	3	1	7	73
1243	Aleks	Porada	Player	0	0	1	0	73
1247	Kajetan	Kos	Player	0	0	1	0	73
1248	Adam	Miroch	Player	0	0	1	0	73
1253	Kuba	Chabasiewicz	Player	1	0	1	0	73
1254	Martin	Bogdanov	Player	2	0	1	0	73
1170	Wiktor	Woźniak	Player	0	0	5	36	21
1222	Sebastian	Skowron	Player	3	0	1	0	53
48	Kewin	Cięciała	Zawodnik z pola	5	0	7	7	18
382	Wojciech	Furgała	Zawodnik z pola	24	1	8	0	34
1212	Wiktor	Surma	Player	0	1	2	18	53
1124	Misha	Jurijczuk	zawodnik	9	3	6	0	9
1164	Adrian	Grabowski	Zawodnik	0	0	2	14	66
1211	Krystian	Percik	Player	0	6	4	38	53
1220	Jakub	Matoń	Player	3	13	3	0	53
1175	Sławomir	Krzystanek	Player	0	0	1	0	21
49	Karol	Mętel	Zawodnik z pola	5	0	6	0	18
1239	Daniel	Sliż	Player	7	0	3	0	53
1217	Krzysztof	Łobaziewicz	Player	5	0	3	0	53
1255	Franek	Glodek	Player	0	0	0	0	73
1304	Franek	Simlat	zawodnik	1	0	5	0	42
1256	Paweł	Kulig	zawodnik	3	6	4	17	30
872	Jakub	Ptak	zawodnik	2	0	4	0	30
1264	Karol	Owsiniak	zawodnik	0	0	2	0	65
554	Marcin	Zagórny	Zawodnik z pola	1	0	1	0	20
1259	Jakub	Bryniak	zawodnik	0	0	0	0	57
1260	Antoni	Lelek	zawodnik	0	0	0	0	57
1261	Michał	Wermiński	Zawodnik	0	0	0	0	57
1266	Robert	Urban	zawodnik	0	0	0	0	18
1267	Tomasz	Puc	zawodnik	0	0	0	0	18
1268	Oskar	Tenninga	zawodnik	0	0	0	0	18
1273	Mateusz	Łabuś	zawodnik	15	8	5	0	71
1281	Joanna	Mikosińska	zawodnik	0	0	0	0	69
1315	Paweł	Lejczak	zawodnik	1	0	1	0	30
1275	Tomasz	Świderski	zawodnik	1	0	3	0	71
1278	Mateusz	Wojtas	zawodnik	5	5	3	0	71
1270	Michał	Węgrzyn	zawodnik	18	3	5	0	71
1277	Mateusz	Wrona	zawodnik	0	0	2	0	71
1309	Mateusz	Słota	Zawodnik	2	0	5	0	55
1282	Magda	Drab	zawodnik	0	0	0	0	68
1197	Marcin	Chojnacki	Player	3	0	2	0	31
1286	Dominik	Sobesto	zawodnik	0	0	0	0	70
1288	Krystian	Michalik	zawodnik	0	0	0	0	18
1292	Oskar	Niedźwiecki	zawodnik	0	0	0	0	18
1297	Nasrollah	Skim	zawodnik	0	0	0	0	5
1306	Kacper	Suder	zawodnik	0	0	0	0	72
1301	Kuba	Kulpiński	zawodnik	2	1	1	0	28
1263	Tobiasz	Wilczyński	zawodnik	38	11	7	0	65
414	Tomasz	Gola	Zawodnik z pola	4	0	4	0	19
1265	Piotr	Sierpiński	zawodnik	0	0	1	0	65
1141	Franciszek	Korzeniowski	zawodnik	11	3	6	0	30
1293	Karol	Dusik	zawodnik	5	1	3	0	18
1036	FIlip	Bojara	zawodnik	0	3	3	17	30
1285	Patryk	Kuc	zawodnik	0	0	1	0	70
1311	David	Sidorchuk	Zawodnik	5	9	3	0	9
1316	Kacper	Kalita	zawodnik	1	0	4	0	41
1274	Krzysztof	Filipczyk	zawodnik	0	0	1	0	71
1287	Dawid	Zajączkowski	zawodnik	4	0	3	0	70
1317	Szymon	Kończak	zawodnik	4	0	1	0	17
465	Grzegorz	Kulesza	Zawodnik z pola	15	0	13	7	55
1322	Jan	Zygmunt	zawodnik	4	2	4	0	10
1305	Szymon	Morga	zawodnik	7	0	3	0	53
1299	Karol	Kękol	zawodnik	0	0	1	0	15
1313	Michał	Ficek	Zawodnik	1	0	1	0	53
1318	Maciek	Stramek	zawodnik	3	0	2	0	19
1302	Łukasz	Żywczyk	zawodnik	0	0	1	0	28
1319	Arek	Majoch	zawodnik	0	0	0	0	19
1276	Piotr	Zieliński	zawodnik	2	0	1	0	71
1258	Maciej	Sudek	zawodnik	2	0	6	0	57
1294	Sebastian	Cebula	zawodnik	0	0	1	0	5
769	Szymon	Gałan	Zawodnik z pola	6	5	6	0	8
599	Ksawery	Konarski	Zawodnik z pola	21	17	9	0	44
105	Michał	Dykacz	Zawodnik z pola	10	5	3	0	26
1320	Mateusz	Sumera	zawodnik	1	0	1	0	19
1298	Krzysztof	Seweryn	zawodnik	2	0	1	0	15
715	Maciej	Miśkiewicz	Zawodnik z pola	23	25	8	0	62
1310	Seweryn	Kozłowski	Zawodnik	5	10	2	0	55
1279	Karol	Trela	zawodnik	10	1	2	0	71
1307	Szymon	Idzik	zawodnik	2	0	1	0	66
1314	Grzegorz	Papiż	Zawodnik	0	0	3	0	65
1303	Michał	Pawełka	zawodnik	3	0	2	8	40
1280	Konrad	Grabowski	zawodnik	0	5	1	10	69
1272	Sebastian	Socholik	zawodnik	2	6	5	33	71
1262	Dawid	Ochman	zawodnik	0	3	1	9	57
1321	Jakub	Chudyba	zawodnik	0	0	1	0	10
68	Szymon	Rączka	Zawodnik z pola	5	3	6	0	10
1289	Kacper	Chrobot	zawodnik	3	0	3	0	18
1269	Kamil	Tułacz	zawodnik	0	0	4	0	63
1312	Jakub	Jagłowski	Zawodnik	0	9	4	27	53
1308	Adam	Górski	Zawodnik	4	0	3	0	27
598	Kamil	Zieleniak	Zawodnik z pola	3	15	4	0	44
375	Patryk	Jackowicz	kapitan	7	0	12	0	34
1296	Odunayo	James Rodowa	zawodnik	0	0	1	0	5
988	Bartek	Podkowa	zawodnik	43	26	6	0	14
1291	Filip	Szymoniak	zawodnik	11	5	2	0	18
531	Grzegorz	Odrzywołek	Zawodnik z pola	42	32	9	0	57
1300	Roch	Robotycki	zawodnik	0	3	2	17	25
308	Miłosz	Karnia	Zawodnik z pola	12	11	6	0	45
1271	Jakub	Węgrzyn	zawodnik	4	1	3	0	71
1295	Krzysztof	Piskorz	zawodnik	5	6	3	0	5
1290	Olek	Ciarka	zawodnik	7	3	3	0	18
1325	Krzysztof	Sokołowski	zawodnik	0	0	0	0	53
1330	Piotr	Gralak	Zawodnik	0	0	0	0	64
1071	Maciek	Sylwestrowicz	zawodnik	0	0	1	0	46
1333	Łukasz	Chmielowski	zawodnik	0	0	0	0	19
1348	Antoni	Rożdżenski	zawodnik	1	0	1	0	54
1360	Adam	Wołowiec	zawodnik	0	0	2	9	30
1345	Dominik	Mika	zawodnik	2	0	2	0	39
1380	Illia	Goncharov	zawodnik	0	0	1	8	9
1331	Szymon	Kurzeja	Zawodnik	0	0	1	0	63
1340	Szymon	Figura	zawodnik	0	0	0	0	57
1341	Rafał	Madej	zawodnik	0	0	0	0	57
1343	Josh	Ernstzen	zawodnik	0	0	0	0	15
1344	Andrzej	Polachow	zawodnik	0	0	0	0	5
1349	Aleks	Paczka	zawodnik	0	0	0	0	54
1350	Norbert	Morek	zawodnik	0	0	0	0	53
1377	Paweł	Jerzyna	zawodnik	0	0	0	0	50
1324	Jakub	Morga	zawodnik	2	0	1	0	53
1353	Jakub	SIemanow	zawodnik	3	1	1	0	22
1354	Adam	Habas	Player	0	0	0	0	15
1346	Marcin	Rybak	zawodnik	0	0	2	0	39
1347	Przemek	Broś	zawodnik	0	3	2	8	39
1382	Patryk	Idzik	zawodnik	0	0	0	0	32
1383	Kajetan	Hawira	zawodnik	0	0	0	0	19
1358	Jan	Korczak	zawodnik	0	0	0	0	55
1342	Mateusz	Ryskala	zawodnik	4	5	1	0	15
1361	Patryk	Koszela	zawodnik	0	0	0	0	61
1364	Mikołaj	Mateja	zawodnik	0	0	0	0	61
1371	Bartosz	Wrzecionek	zawodnik	1	0	2	0	23
1359	Szymon	Biedrzycki	zawodnik	0	0	1	0	30
1366	Kiryl	Shashura	zawodnik	0	0	0	0	5
1368	Kuba	Polniak	zawodnik	2	0	1	0	18
1334	Szymon	Piątek	Zawodnik	0	1	9	79	34
165	Marcin	Ligas	Zawodnik z pola	12	15	3	0	27
569	Miłosz	Wyjadłowski	Zawodnik z pola	4	5	9	0	63
1387	Jonasz	Kluza	zawodnik	0	0	1	0	63
1356	Michał	Niedziela	zawodnik	0	0	1	9	55
1362	Bartosz	Pietrzyka	zawodnik	0	0	1	0	61
1363	Jakub	Kucharski	zawodnik	0	0	1	0	61
1373	Jan	Waniewski	zawodnik	0	0	2	0	23
1323	Karol	Kuczmier	zawodnik	5	2	2	0	18
779	Remigiusz	Mikosinski	kapitan	76	11	16	0	69
1337	Karol	Kielijan	zawodnik	1	0	1	0	57
1386	Oliwier	Kłyś	zawodnik	5	0	3	0	67
1327	Kacper	Suder	zawodnik	0	0	2	0	63
1339	Krzysztof	Nowakowski	zawodnik	2	0	4	0	57
1378	Egor	Kutilov	zawodnik	0	0	0	0	9
1379	Kuba	Łuc	zawodnik	0	0	0	0	9
1335	Mateusz	Kwiecień	Zawodnik	0	0	1	0	34
1332	Szymon	Sikora	zawodnik	10	6	3	0	35
1365	Krzysiek	Chromiec	zawodnik	6	0	4	0	9
1376	Kuba	Wojdyło	zawodnik	4	6	6	0	23
1384	Hubert	Suder	zawodnik	5	5	3	0	42
1388	Aleksander	Udała	zawodnik	0	0	1	0	52
1328	Damian	Dziemba	zawodnik	2	3	2	0	30
1390	Mateusz	Małek	zawodnik	0	0	1	0	52
1391	Jakub	Niedziela	zawodnik	0	0	0	0	35
1329	Marcin	Kanigowski	zawodnik	5	0	4	0	30
1336	Bruno	Sikorski	zawodnik	1	1	3	0	30
1392	Paweł	Pawlikowski	zawodnik	0	0	0	0	11
1396	Patryk	Kubański	zawodnik	0	0	0	0	19
1397	Jakub	Frączewski	zawodnik	0	0	0	0	22
1399	Wojciech	Olsza	zawodnik	0	0	0	0	66
1389	Konrad	Hajto	zawodnik	2	3	1	0	52
1352	Adam	Kubiena	Player	6	9	6	0	42
1395	Emil	Szałankiewicz	zawodnik	1	0	2	0	18
1355	Filip	Chłopek	Zawodnik	12	5	4	0	64
1381	Mateusz	Świerk	zawodnik	0	0	1	0	25
1168	Krzysztof	Woźniak	Dwuzespolowiec	6	0	4	0	21
1400	Hypolite	Drums	zawodnik	1	3	1	0	66
1393	Kacper	Okulski	zawodnik	2	0	1	0	16
1374	Michał	Wąsowicz	zawodnik	0	0	2	0	23
1394	Patryk	Gawin	zawodnik	11	2	4	0	18
1398	Olaf	Katarzyński	zawodnik	7	5	2	0	53
1370	Wojciech	Kociniak	zawodnik	4	5	2	0	32
1385	Dawid	Kubański	zawodnik	0	0	2	9	45
1372	Adam	Łakota	zawodnik	3	0	1	0	23
1351	Dominik	Kwaśnik	zawodnik	3	1	4	0	59
1375	Mikołaj	Liszka	zawodnik	2	0	2	0	23
1357	Kamil	Kolodziej	zawodnik	1	0	2	0	55
1326	Piotr	Kędziora	zawodnik	7	0	4	0	54
1338	Szymon	Filar	zawodnik	20	4	4	0	57
416	Patryk	Daniec	Zawodnik z pola	2	3	5	0	19
1367	Gracjan	Tronina	zawodnik	3	0	4	0	5
1401	Nicholas	Carta	zawodnik	0	0	0	0	66
340	Szymon	Żukrowski	Zawodnik z pola	12	3	8	0	42
1403	Tymon	Piotrowicz	zawodnik	2	0	1	0	60
1405	Arkadiusz	Baran	zawodnik	0	0	0	0	35
1406	Michał	Capik	zawodnik	0	0	0	0	35
1439	Dominik	Sikora	zawodnik	2	0	2	0	65
1409	Filip	Padyś	zawodnik	0	0	0	0	34
1410	Bartek	Zydek	zawodnik	0	0	0	0	6
1412	Max	Mrowiec	zawodnik	0	0	0	0	28
1413	Maciej	Wojtaszek	zawodnik	0	0	0	0	19
1414	Antoni	Ziajko	zawodnik	0	0	0	0	44
1416	Dominik	Wesołowski	zawodnik	0	0	0	0	42
1417	Jan	Olszewski	zawodnik	0	0	0	0	42
1419	Karol	Sałamaj	Player	3	0	1	0	53
1451	Dawid	Gruszkowski	zawodnik	0	0	0	0	14
1420	Filip	Leśniak	zawodnik	0	0	0	0	28
1421	Max	Mrowiec	zawodnik	0	0	0	0	28
1422	Emiliano	Uria	zawodnik	0	0	0	0	40
1423	Piotr	Porada	zawodnik	0	0	0	0	40
1424	Kamil	Szwed	zawodnik	0	0	0	0	40
1425	Kacper	Bonarek	zawodnik	0	0	0	0	40
1426	Maciek	Kopeć	zawodnik	0	0	0	0	40
1427	Martin	Tesio	zawodnik	0	0	0	0	40
1431	Szymon	Rewilak	zawodnik	0	0	0	0	71
1429	Szymon	Garus	zawodnik	0	0	1	6	55
1452	Igor	Chlebowski	zawodnik	0	0	0	0	34
1430	Kacper	Rodak	zawodnik	1	0	1	0	71
1428	Jacek	Kusiak	zawodnik	5	0	2	0	71
1402	Artur	Kowalik	Zawodnik	1	0	3	0	47
1415	Aleksander	Karagiannakos	zawodnik	0	0	1	0	41
1457	Marcin	Cieliński	zawodnik	0	0	1	0	70
1432	Maciej	Ziolowicz	zawodnik	0	0	0	0	67
1458	Mateo	Styrna	zawodnik	0	1	2	14	70
1444	Mikalai	Serebro	zawodnik	0	0	1	0	38
1445	Vitalii	Vozniak	zawodnik	2	0	1	0	38
351	Igor	Stadnicki	Zawodnik z pola	51	34	9	0	37
1418	Karol	Dusik	zawodnik	2	0	2	0	59
1435	Szymon	Zdebski	zawodnik	2	3	0	0	8
285	Badgo	Santana	Zawodnik z pola	0	0	1	3	49
1437	Damian	Anders	zawodnik	0	0	0	0	70
1456	Leszek	Zieliński	zawodnik	5	0	3	0	70
1443	Vladyslav	Yurchenko	zawodnik	0	0	0	0	20
1446	Dawid	Rybałtowski	zawodnik	0	0	0	0	45
1448	Dawid	Śmiech	zawodnik	0	0	0	0	69
1449	Igor	Wójcik	zawodnik	0	0	0	0	59
1453	Nikodem	Wszołek	zawodnik	0	0	0	0	64
1450	Dominik	Matuszczyk	zawodnik	8	0	3	0	14
1440	Filip	Szarka	zawodnik	0	5	1	0	65
1408	Kacper	Piech	Zawodnik	5	0	4	0	23
1442	Natan	Draus	zawodnik	0	0	1	0	20
1447	Aleksander	Stanula	zawodnik	0	0	1	0	65
1438	Michał	Matuszczyk	zawodnik	4	0	2	0	65
1459	Maciej	Jurkowski	zawodnik	0	0	0	0	70
1436	Maciej	Dzięgiel	zawodnik	0	5	3	30	47
314	Aleksander	Dziekański	Zawodnik z pola	1	0	11	101	41
1434	Arkadiusz	Grabowski	zawodnik	2	0	3	0	55
1454	Jan	Obrał	zawodnik	4	5	1	0	67
1407	Oskar	Podkowa	Zawodnik	3	5	2	0	68
1404	Kacper	Gil	zawodnik	0	0	2	0	68
1455	Odbayar	Oibadrakh	zawodnik	0	0	1	0	70
1441	Artur	Gruchała	zawodnik	2	0	1	0	19
1411	Filip	Leśniak	zawodnik	0	0	1	0	28
1433	Jakub	Sewioł	zawodnik	1	0	2	0	64
1460	Bartosz	Owczarek	Zawodnik	1	0	1	0	5
\.


--
-- Data for Name: main_team; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."main_team" ("id", "name", "points", "goalsScored", "goalsLost", "matches", "league_id") FROM stdin;
45	Sztywni Nieugięci	22	106	83	11	3
52	FootCanser	0	10	65	5	3
24	KS Kremerowianka	28	143	122	14	2
9	ELECTROSMART	30	164	83	13	1
47	Huragan Koniowały	28	123	52	12	3
41	OG Libertów	25	95	58	14	3
31	Rozbójnicy Rumcajsa	0	15	139	14	2
10	Zwyrole	18	74	54	9	1
5	Orzeł BTS	18	87	60	10	1
46	Alibaba FC	12	47	59	8	3
50	Kac Pisklaki	0	16	52	5	3
20	IKS Łucznik Kraków 1	21	123	104	13	2
35	FC Braziliana	12	94	105	10	2
55	Biuro Ochrony Stonoga	39	197	95	17	4
42	FC Jesiotry	9	81	122	11	3
12	AKS Wolni Strzelcy	0	0	130	13	1
69	Luźne Grajki	48	206	78	17	4
60	FC Agenci	12	91	111	11	4
36	FC 2+2	0	0	140	14	2
61	FC Curra Kieciurra	9	53	61	9	4
58	FC Imigranci	16	99	134	13	4
27	FC Sołtyse	19	63	67	12	2
26	Perła Sport	24	98	53	13	2
29	WKS Wawel	0	8	157	14	2
7	Odwiert	9	50	46	8	1
33	Błękitne Kasztany	0	3	145	14	2
22	Issa Sport	34	131	76	16	2
37	U-Diablo	33	130	75	15	3
54	TEAM Salvator	37	131	34	13	3
56	FC Cytadela	3	25	195	17	4
32	NieNajMłodsi	18	95	76	11	2
28	FC Obywatele	21	83	44	10	2
68	OIOM	33	130	58	16	4
71	AL-Kohol FC	15	83	96	11	4
23	Super Strikers	47	168	44	17	2
73	FC Bomby	0	4	43	3	3
53	AP Galaxy	37	158	70	17	3
48	Małopolskie ZHR	1	19	63	6	3
13	Strassenbande	3	10	120	13	1
67	FF Sao Paulo	34	152	96	16	4
40	Cracov Elite	10	69	79	9	3
38	Pogoń Kraków	3	21	51	6	3
57	Grzenkowianka Ego Topy	24	130	75	14	4
64	FC Pacynki	36	186	131	17	4
18	Rozbójnicy Pabiana	16	91	101	11	1
6	Deeks United	6	43	106	13	1
43	FC Kalecy	0	9	72	6	3
11	Sportowcy Nałogowcy	16	99	96	12	1
62	FC Szpytu	7	67	123	12	4
70	RB Karpiów	42	195	100	17	4
34	Najlepsi w Mieście	43	189	76	17	2
21	Iskra Kraków	15	81	69	12	2
16	Rosso Negri FC	15	85	83	11	1
63	IKS Łucznik Kraków 2	18	103	186	17	4
59	MKS Mistrzejowice	24	154	113	15	4
66	Partyzant Nowa Huta	6	62	112	12	4
72	Alimenciarze FC	0	13	179	17	4
25	TS Żelbeton Płaszów	42	163	63	17	2
19	KS Kondycja	18	108	107	14	2
39	Laga FC	6	53	81	8	3
65	Galacticos Kraków 2023	22	141	144	15	4
14	Hellas Ivvona	33	144	72	12	1
8	The Gunners Nowa Huta	30	114	69	13	1
15	Diablo Kraków	30	99	17	10	1
17	FC Promil Kraków	12	67	84	10	1
30	Sneak Peak	21	97	75	12	2
44	Gruzik Wieliczka	19	88	63	11	3
49	III LO Hooligans	0	14	52	4	3
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."auth_group_id_seq"', 1, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."auth_group_permissions_id_seq"', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."auth_permission_id_seq"', 56, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."auth_user_groups_id_seq"', 1, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."auth_user_id_seq"', 7, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."auth_user_user_permissions_id_seq"', 112, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."django_admin_log_id_seq"', 1890, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."django_content_type_id_seq"', 14, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."django_migrations_id_seq"', 27, true);


--
-- Name: main_league_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."main_league_id_seq"', 4, true);


--
-- Name: main_match_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."main_match_id_seq"', 536, true);


--
-- Name: main_participation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."main_participation_id_seq"', 4386, true);


--
-- Name: main_player_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."main_player_id_seq"', 1460, true);


--
-- Name: main_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."main_team_id_seq"', 73, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_group"
    ADD CONSTRAINT "auth_group_name_key" UNIQUE ("name");


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissions_group_id_permission_id_0cd325b0_uniq" UNIQUE ("group_id", "permission_id");


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_group"
    ADD CONSTRAINT "auth_group_pkey" PRIMARY KEY ("id");


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_permission"
    ADD CONSTRAINT "auth_permission_content_type_id_codename_01ab375a_uniq" UNIQUE ("content_type_id", "codename");


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_permission"
    ADD CONSTRAINT "auth_permission_pkey" PRIMARY KEY ("id");


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_groups"
    ADD CONSTRAINT "auth_user_groups_pkey" PRIMARY KEY ("id");


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_groups"
    ADD CONSTRAINT "auth_user_groups_user_id_group_id_94350c0c_uniq" UNIQUE ("user_id", "group_id");


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user"
    ADD CONSTRAINT "auth_user_pkey" PRIMARY KEY ("id");


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_user_permissions"
    ADD CONSTRAINT "auth_user_user_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_user_permissions"
    ADD CONSTRAINT "auth_user_user_permissions_user_id_permission_id_14a6b632_uniq" UNIQUE ("user_id", "permission_id");


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user"
    ADD CONSTRAINT "auth_user_username_key" UNIQUE ("username");


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."django_admin_log"
    ADD CONSTRAINT "django_admin_log_pkey" PRIMARY KEY ("id");


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."django_content_type"
    ADD CONSTRAINT "django_content_type_app_label_model_76bd3d3b_uniq" UNIQUE ("app_label", "model");


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."django_content_type"
    ADD CONSTRAINT "django_content_type_pkey" PRIMARY KEY ("id");


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."django_migrations"
    ADD CONSTRAINT "django_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."django_session"
    ADD CONSTRAINT "django_session_pkey" PRIMARY KEY ("session_key");


--
-- Name: main_league main_league_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_league"
    ADD CONSTRAINT "main_league_pkey" PRIMARY KEY ("id");


--
-- Name: main_match main_match_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_match"
    ADD CONSTRAINT "main_match_pkey" PRIMARY KEY ("id");


--
-- Name: main_participation main_participation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_participation"
    ADD CONSTRAINT "main_participation_pkey" PRIMARY KEY ("id");


--
-- Name: main_player main_player_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_player"
    ADD CONSTRAINT "main_player_pkey" PRIMARY KEY ("id");


--
-- Name: main_team main_team_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_team"
    ADD CONSTRAINT "main_team_pkey" PRIMARY KEY ("id");


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_group_name_a6ea08ec_like" ON "public"."auth_group" USING "btree" ("name" "varchar_pattern_ops");


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_group_permissions_group_id_b120cbf9" ON "public"."auth_group_permissions" USING "btree" ("group_id");


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_group_permissions_permission_id_84c5c92e" ON "public"."auth_group_permissions" USING "btree" ("permission_id");


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_permission_content_type_id_2f476e4b" ON "public"."auth_permission" USING "btree" ("content_type_id");


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_user_groups_group_id_97559544" ON "public"."auth_user_groups" USING "btree" ("group_id");


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_user_groups_user_id_6a12ed8b" ON "public"."auth_user_groups" USING "btree" ("user_id");


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_user_user_permissions_permission_id_1fbb5f2c" ON "public"."auth_user_user_permissions" USING "btree" ("permission_id");


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_user_user_permissions_user_id_a95ead1b" ON "public"."auth_user_user_permissions" USING "btree" ("user_id");


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_user_username_6821ab7c_like" ON "public"."auth_user" USING "btree" ("username" "varchar_pattern_ops");


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "django_admin_log_content_type_id_c4bce8eb" ON "public"."django_admin_log" USING "btree" ("content_type_id");


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "django_admin_log_user_id_c564eba6" ON "public"."django_admin_log" USING "btree" ("user_id");


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "django_session_expire_date_a5c62663" ON "public"."django_session" USING "btree" ("expire_date");


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "django_session_session_key_c0390e0f_like" ON "public"."django_session" USING "btree" ("session_key" "varchar_pattern_ops");


--
-- Name: main_match_team1_id_7c806ec6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "main_match_team1_id_7c806ec6" ON "public"."main_match" USING "btree" ("team1_id");


--
-- Name: main_match_team2_id_dac54b6b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "main_match_team2_id_dac54b6b" ON "public"."main_match" USING "btree" ("team2_id");


--
-- Name: main_participation_match_id_8c82cef9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "main_participation_match_id_8c82cef9" ON "public"."main_participation" USING "btree" ("match_id");


--
-- Name: main_participation_player_id_eec4aa8b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "main_participation_player_id_eec4aa8b" ON "public"."main_participation" USING "btree" ("player_id");


--
-- Name: main_player_team_id_7c700b6f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "main_player_team_id_7c700b6f" ON "public"."main_player" USING "btree" ("team_id");


--
-- Name: main_team_league_id_5b04d9d8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "main_team_league_id_5b04d9d8" ON "public"."main_team" USING "btree" ("league_id");


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissio_permission_id_84c5c92e_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "public"."auth_permission"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_group_permissions"
    ADD CONSTRAINT "auth_group_permissions_group_id_b120cbf9_fk_auth_group_id" FOREIGN KEY ("group_id") REFERENCES "public"."auth_group"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_permission"
    ADD CONSTRAINT "auth_permission_content_type_id_2f476e4b_fk_django_co" FOREIGN KEY ("content_type_id") REFERENCES "public"."django_content_type"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_groups"
    ADD CONSTRAINT "auth_user_groups_group_id_97559544_fk_auth_group_id" FOREIGN KEY ("group_id") REFERENCES "public"."auth_group"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_groups"
    ADD CONSTRAINT "auth_user_groups_user_id_6a12ed8b_fk_auth_user_id" FOREIGN KEY ("user_id") REFERENCES "public"."auth_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_user_permissions"
    ADD CONSTRAINT "auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm" FOREIGN KEY ("permission_id") REFERENCES "public"."auth_permission"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."auth_user_user_permissions"
    ADD CONSTRAINT "auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id" FOREIGN KEY ("user_id") REFERENCES "public"."auth_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."django_admin_log"
    ADD CONSTRAINT "django_admin_log_content_type_id_c4bce8eb_fk_django_co" FOREIGN KEY ("content_type_id") REFERENCES "public"."django_content_type"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."django_admin_log"
    ADD CONSTRAINT "django_admin_log_user_id_c564eba6_fk_auth_user_id" FOREIGN KEY ("user_id") REFERENCES "public"."auth_user"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_match main_match_team1_id_7c806ec6_fk_main_team_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_match"
    ADD CONSTRAINT "main_match_team1_id_7c806ec6_fk_main_team_id" FOREIGN KEY ("team1_id") REFERENCES "public"."main_team"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_match main_match_team2_id_dac54b6b_fk_main_team_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_match"
    ADD CONSTRAINT "main_match_team2_id_dac54b6b_fk_main_team_id" FOREIGN KEY ("team2_id") REFERENCES "public"."main_team"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_participation main_participation_match_id_8c82cef9_fk_main_match_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_participation"
    ADD CONSTRAINT "main_participation_match_id_8c82cef9_fk_main_match_id" FOREIGN KEY ("match_id") REFERENCES "public"."main_match"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_participation main_participation_player_id_eec4aa8b_fk_main_player_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_participation"
    ADD CONSTRAINT "main_participation_player_id_eec4aa8b_fk_main_player_id" FOREIGN KEY ("player_id") REFERENCES "public"."main_player"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_player main_player_team_id_7c700b6f_fk_main_team_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_player"
    ADD CONSTRAINT "main_player_team_id_7c700b6f_fk_main_team_id" FOREIGN KEY ("team_id") REFERENCES "public"."main_team"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_team main_team_league_id_5b04d9d8_fk_main_league_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."main_team"
    ADD CONSTRAINT "main_team_league_id_5b04d9d8_fk_main_league_id" FOREIGN KEY ("league_id") REFERENCES "public"."main_league"("id") DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

